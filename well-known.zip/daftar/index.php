<?php
session_start();

// --- 1. تنظیمات و PWA ---
if (isset($_GET['manifest'])) {
    header('Content-Type: application/json');
    echo json_encode([
        "name" => "دستیار وکالت", "short_name" => "وکیل‌یار", "start_url" => ".",
        "display" => "standalone", "background_color" => "#0A192F", "theme_color" => "#0A192F",
        "icons" => [["src" => "https://img.icons8.com/fluency/192/law.png", "sizes" => "192x192", "type" => "image/png"]]
    ]); exit;
}

header('Content-Type: text/html; charset=utf-8');
ini_set('session.cookie_httponly', 1);
$PASSWORD = "750920"; 
$DATA_FILE = __DIR__ . '/lawyer_schedule.dat'; 
date_default_timezone_set('Asia/Tehran');

// --- 2. توابع تاریخ ---
function gregorian_to_jalali($gy, $gm, $gd) {
    $g_d_m = array(0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334);
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053)));
    $days %= 12053;
    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) { $jy += (int)(($days - 1) / 365); $days = ($days - 1) % 365; }
    if ($days < 186) { $jm = 1 + (int)($days / 31); $jd = 1 + ($days % 31); } else { $jm = 7 + (int)(($days - 186) / 30); $jd = 1 + (($days - 186) % 30); }
    return array($jy, $jm, $jd);
}

function jalali_to_gregorian($jy, $jm, $jd) {
    $jy += 1595;
    $days = -355668 + (365 * $jy) + (((int)($jy / 33)) * 8) + ((int)((($jy % 33) + 3) / 4)) + $jd + (($jm < 7) ? ($jm - 1) * 31 : (($jm - 7) * 30) + 186);
    $gy = 400 * ((int)($days / 146097));
    $days %= 146097;
    if ($days > 36524) { $gy += 100 * ((int)(--$days / 36524)); $days %= 36524; if ($days >= 365) $days++; }
    $gy += 4 * ((int)($days / 1461));
    $days %= 1461;
    if ($days > 365) { $gy += (int)(($days - 1) / 365); $days = ($days - 1) % 365; }
    $gd = $days + 1;
    foreach(array(0, 31, (($gy % 4 == 0 and $gy % 100 != 0) or ($gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31) as $gm => $v) { if ($gd <= $v) break; $gd -= $v; }
    return array($gy, $gm, $gd);
}

function get_day_name_verbose($date_str) {
    $parts = explode('/', $date_str);
    if(count($parts) < 3) return '';
    $g = jalali_to_gregorian((int)$parts[0], (int)$parts[1], (int)$parts[2]);
    $ts = mktime(0, 0, 0, $g[1], $g[2], $g[0]);
    $days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنج‌شنبه', 'جمعه', 'شنبه'];
    return $days[date('w', $ts)];
}

function get_today_jalali_string() {
    $t = getdate(); $j = gregorian_to_jalali($t['year'], $t['mon'], $t['mday']);
    return sprintf('%04d/%02d/%02d', $j[0], $j[1], $j[2]);
}

function calculate_days_remaining($date_str) {
    $today_str = get_today_jalali_string();
    if ($date_str == $today_str) return ['text' => 'امروز', 'color' => 'text-red-500', 'raw' => 0];
    if ($date_str < $today_str) return ['text' => 'گذشته', 'color' => 'text-gray-400', 'raw' => -1];
    
    $parts = explode('/', $date_str);
    $g_target = jalali_to_gregorian((int)$parts[0], (int)$parts[1], (int)$parts[2]);
    $ts_target = mktime(0,0,0, $g_target[1], $g_target[2], $g_target[0]);
    
    $t_parts = explode('/', $today_str);
    $g_today = jalali_to_gregorian((int)$t_parts[0], (int)$t_parts[1], (int)$t_parts[2]);
    $ts_today = mktime(0,0,0, $g_today[1], $g_today[2], $g_today[0]);
    
    $diff = ($ts_target - $ts_today) / 86400;
    $days = round($diff);
    
    if($days == 1) return ['text' => 'فردا', 'color' => 'text-orange-500', 'raw' => 1];
    return ['text' => $days . ' روز مانده', 'color' => 'text-blue-500 dark:text-gold-accent', 'raw' => $days];
}

// --- 3. مدیریت داده ---
function load_schedule() {
    global $DATA_FILE;
    if (file_exists($DATA_FILE)) {
        $data = file_get_contents($DATA_FILE);
        return json_decode($data, true) ?: [];
    }
    return [];
}

function save_schedule($schedule) {
    global $DATA_FILE;
    file_put_contents($DATA_FILE, json_encode($schedule));
}

// --- 4. پردازش ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['password'])) {
        if ($_POST['password'] === $PASSWORD) {
            $_SESSION['authenticated'] = true;
            header('Location: ' . $_SERVER['PHP_SELF']); exit;
        }
    } 
    elseif (isset($_POST['action']) && $_SESSION['authenticated']) {
        $schedule = load_schedule();
        $date = $_POST['date'];
        
        if ($_POST['action'] == 'add') {
            $schedule[$date][] = [
                'time' => $_POST['time'], 'description' => $_POST['description'], 'client' => $_POST['client'],
                'label' => $_POST['label'] ?? '', 'result' => $_POST['result'] ?? '', 'is_done' => false,
                'created_at' => date('Y-m-d H:i:s')
            ];
            usort($schedule[$date], function($a, $b) { return strcmp($a['time'], $b['time']); });
        } elseif ($_POST['action'] == 'edit') {
            $idx = $_POST['index'];
            if (isset($schedule[$date][$idx])) {
                $item = $schedule[$date][$idx];
                $schedule[$date][$idx] = array_merge($item, [
                    'time' => $_POST['time'], 'description' => $_POST['description'], 'client' => $_POST['client'],
                    'label' => $_POST['label'] ?? '', 'result' => $_POST['result'] ?? '', 'updated_at' => date('Y-m-d H:i:s')
                ]);
            }
        } elseif ($_POST['action'] == 'delete') {
            array_splice($schedule[$date], $_POST['index'], 1);
            if (empty($schedule[$date])) unset($schedule[$date]);
        } elseif ($_POST['action'] == 'toggle_status') {
            $idx = $_POST['index'];
            if (isset($schedule[$date][$idx])) {
                $schedule[$date][$idx]['is_done'] = !($schedule[$date][$idx]['is_done'] ?? false);
            }
            save_schedule($schedule);
            echo json_encode(['status' => 'success']); exit;
        }
        save_schedule($schedule);
        header('Location: ' . $_SERVER['PHP_SELF']); exit;
    }
}

if (isset($_GET['logout'])) { session_destroy(); header('Location: ' . $_SERVER['PHP_SELF']); exit; }

$authenticated = isset($_SESSION['authenticated']) && $_SESSION['authenticated'];
$schedule = $authenticated ? load_schedule() : [];
$today_string = get_today_jalali_string();

$past_schedules = [];
$upcoming_schedules = [];
foreach ($schedule as $date => $items) {
    if ($date < $today_string) $past_schedules[$date] = $items;
    else $upcoming_schedules[$date] = $items;
}
ksort($upcoming_schedules);
krsort($past_schedules);

$stats = ['total' => 0, 'done' => 0];
foreach ($upcoming_schedules as $items) { foreach ($items as $item) { $stats['total']++; if (!empty($item['is_done'])) $stats['done']++; } }
?>

<!DOCTYPE html>
<html lang="fa" dir="rtl" class="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>دستیار وکالت</title>
    <link rel="manifest" href="?manifest=1">
    <meta name="theme-color" content="#0A192F"/>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: { sans: ['Vazirmatn', 'sans-serif'] },
                    colors: {
                        'dark-navy': '#0A192F', // سرمه ای تیره (سایت اصلی)
                        'gold-accent': '#D4AF37', // طلایی (سایت اصلی)
                        'slate-50': '#f8fafc', // سفید یخی (لایت مود اصلی)
                    }
                }
            }
        }
    </script>
    <style>
        /* Light Mode: Blue & White */
        body { background-color: #f8fafc; color: #1e293b; }
        .btn-primary { background-color: #2563eb; color: white; } /* Blue-600 */
        .btn-primary:hover { background-color: #1d4ed8; }
        
        /* Dark Mode: Navy & Gold */
        .dark body { background-color: #0A192F; color: #e2e8f0; }
        .dark .btn-primary { background-color: #D4AF37; color: #0A192F; font-weight: bold; }
        .dark .btn-primary:hover { background-color: #bfa13a; }
        .dark .card-bg { background-color: #172a45; border-color: #334155; }
        .dark input, .dark textarea, .dark select { background-color: #112240; border-color: #334155; color: white; }

        .checkbox-wrapper input:checked + div { background-color: #10B981; border-color: #10B981; }
        .checkbox-wrapper input:checked + div i { display: block; }
        .task-done .task-text { text-decoration: line-through; opacity: 0.5; }
        .task-done { background-color: #f0fdf4 !important; }
        .dark .task-done { background-color: #064e3b !important; }
        .upcoming-item.hidden-task { display: none; }
    </style>
</head>
<body class="transition-colors duration-300 pb-24">

<?php if (!$authenticated): ?>
    <div class="min-h-screen flex items-center justify-center p-4 bg-dark-navy">
        <div class="bg-white/5 backdrop-blur-md border border-white/10 p-8 rounded-3xl shadow-2xl w-full max-w-sm text-center">
            <div class="w-20 h-20 bg-gold-accent rounded-full mx-auto mb-6 flex items-center justify-center text-4xl shadow-lg border-4 border-dark-navy text-dark-navy">⚖️</div>
            <h1 class="text-2xl font-bold text-white mb-6">ورود به دفتر وکالت</h1>
            <form method="post" class="space-y-4">
                <input type="password" name="password" class="w-full px-5 py-4 rounded-xl bg-black/30 border border-white/10 text-white text-center text-lg focus:ring-2 focus:ring-gold-accent outline-none" placeholder="رمز عبور" required inputmode="numeric">
                <button class="w-full bg-gold-accent hover:bg-yellow-500 text-dark-navy font-bold py-4 rounded-xl shadow-lg transition transform active:scale-95">ورود</button>
            </form>
        </div>
    </div>
<?php else: ?>

    <!-- Header -->
    <div class="sticky top-0 z-40 bg-white dark:bg-dark-navy shadow-lg border-b dark:border-gray-700">
        <div class="max-w-2xl mx-auto px-4 h-16 flex justify-between items-center">
            <div class="flex items-center gap-2">
                <i class="fa-solid fa-gavel text-blue-600 dark:text-gold-accent text-xl"></i>
                <span class="font-bold text-lg text-slate-800 dark:text-white">داشبورد وکالت</span>
            </div>
            <div class="flex gap-3">
                <button onclick="toggleTheme()" class="w-8 h-8 rounded-full bg-gray-100 dark:bg-white/10 flex items-center justify-center text-blue-600 dark:text-gold-accent hover:bg-gray-200 transition"><i class="fa-solid fa-moon"></i></button>
                <a href="?logout=1" class="text-red-500 font-bold text-sm flex items-center"><i class="fa-solid fa-power-off mr-1"></i></a>
            </div>
        </div>
        
        <!-- Search Bar -->
        <div class="max-w-2xl mx-auto px-4 pb-4">
            <div class="relative">
                <input type="text" id="searchInput" placeholder="جستجو در پرونده‌ها..." class="w-full pl-4 pr-10 py-3 rounded-xl bg-gray-100 dark:bg-white/10 text-slate-800 dark:text-white placeholder-gray-500 dark:placeholder-gray-400 border border-transparent focus:ring-2 focus:ring-blue-500 dark:focus:ring-gold-accent outline-none text-sm">
                <i class="fa-solid fa-search absolute right-3 top-3.5 text-gray-400"></i>
            </div>
        </div>
    </div>

    <!-- Main Content -->
    <main class="max-w-2xl mx-auto px-4 py-6 space-y-6">
        
        <!-- Floating Add Button -->
        <button onclick="openModal('add')" class="fixed bottom-6 left-6 w-16 h-16 btn-primary rounded-full shadow-2xl flex items-center justify-center text-2xl z-50 transition transform hover:scale-110 active:scale-90 shadow-black/30">
            <i class="fa-solid fa-plus"></i>
        </button>

        <!-- Upcoming Section -->
        <div id="upcomingSection">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-base font-bold text-slate-700 dark:text-gold-accent flex items-center gap-2">
                    <i class="fa-solid fa-calendar-days"></i> برنامه جاری و آینده
                </h2>
                <span class="text-xs bg-blue-100 text-blue-800 dark:bg-gold-accent/20 dark:text-gold-accent px-2 py-1 rounded-full font-bold"><?php echo $stats['total']; ?> مورد</span>
            </div>
            
            <?php if(empty($upcoming_schedules)): ?>
                <div class="text-center py-12 opacity-50 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-2xl">
                    <i class="fa-regular fa-calendar-check text-4xl mb-2 text-gray-400"></i>
                    <p>هیچ برنامه آینده‌ای ندارید</p>
                </div>
            <?php endif; ?>

            <div id="scheduleList">
            <?php 
            $counter = 0;
            foreach ($upcoming_schedules as $date => $items): 
                $days_info = calculate_days_remaining($date);
                $day_name = get_day_name_verbose($date);
                $is_today = ($date == $today_string);
                $hidden_class = ($counter >= 30) ? 'hidden-task' : '';
                $counter++;
            ?>
            <div class="mb-4 upcoming-item <?php echo $hidden_class; ?>">
                <div class="flex items-center justify-between mb-2 px-1">
                    <div class="flex items-center gap-2">
                        <span class="font-black text-lg <?php echo $is_today ? 'text-blue-600 dark:text-blue-400' : 'text-slate-700 dark:text-slate-300'; ?>"><?php echo $date; ?></span>
                        <span class="text-sm text-gray-500 dark:text-gray-400">(<?php echo $day_name; ?>)</span>
                        <span class="text-xs font-bold <?php echo $days_info['color']; ?> bg-gray-100 dark:bg-white/5 px-2 py-0.5 rounded border dark:border-gray-700">
                            <?php echo $days_info['text']; ?>
                        </span>
                    </div>
                </div>

                <div class="space-y-3">
                    <?php foreach ($items as $idx => $item): 
                        $done_cls = !empty($item['is_done']) ? 'task-done' : '';
                        $checked = !empty($item['is_done']) ? 'checked' : '';
                    ?>
                    <div class="bg-white dark:bg-dark-navy rounded-xl p-4 shadow-sm border border-gray-200 dark:border-gray-700 flex gap-4 transition-all <?php echo $done_cls; ?>" id="card-<?php echo $date.'-'.$idx; ?>">
                        
                        <!-- Checkbox -->
                        <label class="checkbox-wrapper cursor-pointer mt-1">
                            <input type="checkbox" class="hidden" onchange="toggleTask('<?php echo $date; ?>', <?php echo $idx; ?>, this)" <?php echo $checked; ?>>
                            <div class="w-6 h-6 border-2 border-gray-300 dark:border-gray-500 rounded-full flex items-center justify-center transition-colors bg-white dark:bg-transparent">
                                <i class="fa-solid fa-check text-white text-xs hidden"></i>
                            </div>
                        </label>

                        <div class="flex-1 min-w-0 cursor-pointer task-content" onclick="editItem('<?php echo $date; ?>', <?php echo $idx; ?>)">
                            <div class="flex justify-between items-start mb-1">
                                <h3 class="font-bold text-slate-900 dark:text-white task-text text-base"><?php echo $item['client'] ?: 'بدون نام'; ?></h3>
                                <span class="font-mono text-xs font-bold text-blue-700 bg-blue-100 dark:bg-blue-900/50 dark:text-blue-200 px-2 py-0.5 rounded"><?php echo $item['time']; ?></span>
                            </div>
                            
                            <p class="text-sm text-slate-600 dark:text-slate-400 task-text leading-relaxed mb-2 line-clamp-2"><?php echo nl2br($item['description']); ?></p>

                            <div class="flex flex-wrap gap-2 items-center">
                                <?php if(!empty($item['label'])): ?>
                                    <span class="text-[10px] px-2 py-0.5 rounded bg-gray-100 dark:bg-white/10 text-gray-500 dark:text-gray-300 border dark:border-gray-600">
                                        <i class="fa-solid fa-tag mr-1"></i><?php echo $item['label']; ?>
                                    </span>
                                <?php endif; ?>
                                <?php if(!empty($item['result'])): ?>
                                    <div class="w-full sm:w-auto text-xs bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 px-2 py-1 rounded border border-green-100 dark:border-green-800 flex items-center gap-1">
                                        <i class="fa-solid fa-check-double"></i> <?php echo $item['result']; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                        <button onclick="deleteItem('<?php echo $date; ?>', <?php echo $idx; ?>)" class="text-gray-300 hover:text-red-500 self-start p-1 transition">
                            <i class="fa-solid fa-trash"></i>
                        </button>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
            </div>

            <?php if ($counter > 30): ?>
                <button id="loadMoreBtn" onclick="loadMore()" class="w-full py-3 mt-4 bg-white dark:bg-dark-navy text-blue-600 dark:text-gold-accent border border-gray-200 dark:border-gray-700 rounded-xl font-bold shadow-sm hover:bg-gray-50 transition">
                    نمایش ۳۰ روز بعدی 👇
                </button>
            <?php endif; ?>
        </div>

        <!-- Archive Section -->
        <div class="pt-8 border-t border-gray-200 dark:border-gray-700">
            <button onclick="document.getElementById('archiveList').classList.toggle('hidden')" class="w-full py-3 bg-gray-200 dark:bg-white/5 text-gray-600 dark:text-gray-400 rounded-xl font-bold flex items-center justify-center gap-2 transition hover:bg-gray-300">
                <i class="fa-solid fa-box-archive"></i> مشاهده بایگانی گذشته
                <span class="text-xs bg-white dark:bg-black/30 px-2 rounded-full"><?php echo count($past_schedules); ?> روز</span>
            </button>
            
            <div id="archiveList" class="hidden mt-6 space-y-6 opacity-75 grayscale hover:grayscale-0 transition duration-500">
                <?php foreach ($past_schedules as $date => $items): 
                     $day_name = get_day_name_verbose($date);
                ?>
                <div>
                    <div class="flex items-center gap-2 mb-2 px-1">
                        <span class="font-bold text-gray-500"><?php echo $date; ?></span>
                        <span class="text-sm text-gray-400">(<?php echo $day_name; ?>)</span>
                        <span class="text-xs bg-gray-100 dark:bg-white/5 text-gray-400 px-2 rounded">گذشته</span>
                    </div>
                    <div class="space-y-2">
                        <?php foreach ($items as $idx => $item): ?>
                        <div class="bg-white dark:bg-dark-navy p-3 rounded-lg border border-gray-100 dark:border-gray-700 flex justify-between items-center">
                            <div>
                                <span class="text-sm font-bold text-gray-700 dark:text-gray-300"><?php echo $item['client']; ?></span>
                                <span class="text-xs text-gray-400 mr-2 font-mono"><?php echo $item['time']; ?></span>
                                <p class="text-xs text-gray-500 mt-1 truncate max-w-[200px]"><?php echo $item['description']; ?></p>
                                <?php if(!empty($item['result'])): ?><div class="text-xs text-green-600 mt-1">✔ <?php echo $item['result']; ?></div><?php endif; ?>
                            </div>
                            <div class="flex gap-2">
                                <button onclick="editItem('<?php echo $date; ?>', <?php echo $idx; ?>)" class="text-blue-400 text-sm"><i class="fa-solid fa-eye"></i></button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

    </main>

    <!-- Modal -->
    <div id="scheduleModal" class="fixed inset-0 bg-black/60 backdrop-blur-sm hidden z-[60] flex items-end sm:items-center justify-center p-0 sm:p-4">
        <div class="bg-white dark:bg-dark-navy w-full sm:max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl p-6 max-h-[90vh] overflow-y-auto border dark:border-gray-700">
            <div class="flex justify-between items-center mb-6 border-b border-gray-100 dark:border-gray-700 pb-4">
                <h3 id="modalTitle" class="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2">
                    <i class="fa-solid fa-pen-to-square text-blue-600 dark:text-gold-accent"></i> <span>برنامه جدید</span>
                </h3>
                <button onclick="closeModal()" class="w-8 h-8 rounded-full bg-gray-100 dark:bg-white/10 flex items-center justify-center text-gray-500 dark:text-white hover:bg-red-500 hover:text-white transition">&times;</button>
            </div>
            
            <form method="post" id="scheduleForm" class="space-y-5">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="index" id="formIndex" value="">
                
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1 block">تاریخ</label>
                        <input type="text" name="date" id="formDate" value="<?php echo $today_string; ?>" class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-gray-700 dark:text-white text-center focus:border-blue-500 dark:focus:border-gold-accent focus:ring-0 outline-none" dir="ltr" required>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1 block">ساعت</label>
                        <input type="time" name="time" id="formTime" class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-gray-700 dark:text-white text-center focus:border-blue-500 dark:focus:border-gold-accent focus:ring-0 outline-none" required>
                    </div>
                </div>

                <div>
                    <label class="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1 block">موکل / طرف حساب</label>
                    <div class="relative">
                        <i class="fa-solid fa-user absolute right-4 top-3.5 text-gray-400"></i>
                        <input type="text" name="client" id="formClient" class="w-full pr-10 pl-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-gray-700 dark:text-white focus:border-blue-500 dark:focus:border-gold-accent focus:ring-0 outline-none" placeholder="نام شخص...">
                    </div>
                </div>

                <div>
                    <label class="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1 block">شرح کار</label>
                    <textarea name="description" id="formDesc" rows="3" class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-gray-700 dark:text-white focus:border-blue-500 dark:focus:border-gold-accent focus:ring-0 outline-none" placeholder="جزئیات..."></textarea>
                </div>

                <div class="pt-4 border-t border-gray-100 dark:border-gray-700">
                    <label class="text-xs font-bold text-green-600 block mb-1">📝 نتیجه (پر کردن بعد از انجام)</label>
                    <textarea name="result" id="formResult" rows="2" class="w-full px-4 py-3 rounded-xl bg-green-50 dark:bg-green-900/10 border border-green-200 dark:border-green-800/30 focus:border-green-500 focus:ring-0 outline-none dark:text-white" placeholder="نتیجه نهایی چه شد؟"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4 pt-2">
                    <select name="label" id="formLabel" class="w-full px-4 py-3 rounded-xl bg-gray-50 dark:bg-black/20 border border-gray-200 dark:border-gray-700 dark:text-white outline-none">
                        <option value="">عادی</option>
                        <option value="جلسه">جلسه</option>
                        <option value="دادگاه">دادگاه</option>
                        <option value="پیگیری">پیگیری</option>
                    </select>
                    <button class="w-full btn-primary rounded-xl shadow-lg transform active:scale-95 transition">ذخیره</button>
                </div>
            </form>
        </div>
    </div>

    <form id="deleteForm" method="post" class="hidden"><input type="hidden" name="action" value="delete"><input type="hidden" name="date" id="delDate"><input type="hidden" name="index" id="delIndex"></form>

    <script>
        // Data pass from PHP to JS safely
        const scheduleData = <?php echo json_encode($schedule); ?>;

        function toggleTheme() {
            document.documentElement.classList.toggle('dark');
            localStorage.setItem('theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light');
        }
        if(localStorage.getItem('theme') === 'dark') document.documentElement.classList.add('dark');

        function toggleTask(date, index, checkbox) {
            const card = document.getElementById(`card-${date}-${index}`);
            if(checkbox.checked) card.classList.add('task-done'); else card.classList.remove('task-done');
            const fd = new FormData(); fd.append('action', 'toggle_status'); fd.append('date', date); fd.append('index', index);
            fetch('', { method: 'POST', body: fd });
        }

        // Load More Logic
        function loadMore() {
            const hiddenItems = document.querySelectorAll('.upcoming-item.hidden-task');
            for(let i=0; i<30 && i<hiddenItems.length; i++) {
                hiddenItems[i].classList.remove('hidden-task');
            }
            if(document.querySelectorAll('.upcoming-item.hidden-task').length === 0) {
                document.getElementById('loadMoreBtn').style.display = 'none';
            }
        }

        // Search Logic
        document.getElementById('searchInput').addEventListener('keyup', function() {
            const val = this.value.toLowerCase();
            const items = document.querySelectorAll('.upcoming-item, #archiveList > div');
            items.forEach(el => {
                const text = el.innerText.toLowerCase();
                el.style.display = text.includes(val) ? 'block' : 'none';
            });
            if(val === '') { location.reload(); }
        });

        function openModal(mode, date='', index='', time='', client='', desc='', label='', result='') {
            document.getElementById('formAction').value = mode;
            document.getElementById('modalTitle').innerText = mode==='add'?'برنامه جدید':'ویرایش پرونده';
            if(date) document.getElementById('formDate').value = date;
            document.getElementById('formIndex').value = index;
            document.getElementById('formTime').value = time;
            document.getElementById('formClient').value = client;
            document.getElementById('formDesc').value = desc;
            document.getElementById('formLabel').value = label;
            document.getElementById('formResult').value = result;
            document.getElementById('scheduleModal').classList.remove('hidden');
        }
        
        function closeModal() { document.getElementById('scheduleModal').classList.add('hidden'); }

        // Fixed Edit Function using JS Object
        function editItem(date, index) {
            if (scheduleData[date] && scheduleData[date][index]) {
                const item = scheduleData[date][index];
                openModal('edit', date, index, item.time, item.client, item.description, item.label, item.result || '');
            }
        }

        function deleteItem(date, index) {
            if(confirm('آیا از حذف این پرونده مطمئن هستید؟')) {
                document.getElementById('delDate').value = date;
                document.getElementById('delIndex').value = index;
                document.getElementById('deleteForm').submit();
            }
        }
        document.getElementById('scheduleModal').addEventListener('click', (e) => { if (e.target.id === 'scheduleModal') closeModal(); });

        // Notification Check
        if ("Notification" in window) {
            if (Notification.permission === "default") { Notification.requestPermission(); }
            const todayCount = <?php echo isset($upcoming_schedules[$today_string]) ? count($upcoming_schedules[$today_string]) : 0; ?>;
            if (Notification.permission === "granted" && todayCount > 0) {
                new Notification("یادآوری وکالت", { body: `شما امروز ${todayCount} برنامه دارید.`, icon: "https://img.icons8.com/fluency/96/law.png" });
            }
        }
    </script>
<?php endif; ?>
</body>
</html>