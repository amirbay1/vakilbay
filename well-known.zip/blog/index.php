<?php
// PHP/Markdown Blog Reader - ORIGINAL STYLE RESTORED
$post_dir = 'posts/';

// 1. Helper: Reading Time
function estimate_reading_time($text) {
    $word_count = str_word_count(strip_tags($text));
    $minutes = floor($word_count / 200);
    return max(1, $minutes);
}

// 2. YAML Parser
function parse_yaml_front_matter($content) {
    if (preg_match('/^---\s*$(.*?)^---\s*$/ms', $content, $match)) {
        $yaml_string = trim($match[1]);
        $yaml_data = [];
        foreach (explode("\n", $yaml_string) as $line) {
            if (strpos($line, ':') !== false) {
                list($key, $value) = explode(':', $line, 2);
                $yaml_data[trim($key)] = trim($value);
            }
        }
        $markdown_content = str_replace($match[0], '', $content);
        $defaults = ['description' => '', 'keywords' => '', 'title' => '', 'image' => '', 'category' => ''];
        return ['meta' => array_merge($defaults, $yaml_data), 'content' => $markdown_content];
    }
    return ['meta' => ['description' => '', 'keywords' => '', 'title' => '', 'image' => '', 'category' => ''], 'content' => $content];
}

// 3. Get Post Data
function get_post_data($filepath) {
    if (!file_exists($filepath)) {
         return ['content' => "متأسفانه محتوایی با این آدرس یافت نشد.", 'title' => '404 - خطا', 'description' => 'صفحه مورد نظر یافت نشد.', 'keywords' => '', 'error' => true];
    }
    $raw_content = file_get_contents($filepath);
    $parsed = parse_yaml_front_matter($raw_content);
    $text = $parsed['content'];
    $meta = $parsed['meta'];
    
    $read_time = estimate_reading_time($text);

    $content_lines = explode("\n", trim($text));
    array_shift($content_lines); 
    $text_to_render = implode("\n", $content_lines);
    $title = isset($meta['title']) ? $meta['title'] : 'پست بدون عنوان';
    
    $content = $text_to_render;
    // Formatting
    $content = preg_replace('/!\[(.*?)\]\((.*?)\)/', '<p class="image-wrapper"><img src="$2" alt="$1"></p>', $content);
    $content = preg_replace('/\[(.*?)\]\((.*?)\)/', '<a href="$2" target="_blank">$1</a>', $content);
    $content = preg_replace('/^## (.*)$/m', '<h2>$1</h2>', $content);
    $content = preg_replace('/^### (.*)$/m', '<h3>$1</h3>', $content);
    $content = preg_replace('/\*\*(.*)\*\*/U', '<strong>$1</strong>', $content);
    $content = preg_replace('/_(.*?)_/U', '<em>$1</em>', $content);
    $content = preg_replace('/^> (.*)$/m', '<blockquote><p>$1</p></blockquote>', $content);
    $content = preg_replace('/^\s*[-_*]{3,}\s*$/m', '<hr>', $content);
    $content = preg_replace('/^\* (.*)$/m', '<li>$1</li>', $content);
    $content = str_replace("</li>\n<li>", "</li><li>", $content);
    if (strpos($content, '<li>') !== false) {
        $content = preg_replace('/(<li>.*<\/li>)/s', '<ul>$1</ul>', $content, 1);
        $content = str_replace("</ul><ul>", "", $content);
    }
    $content = nl2br($content);
    
    $content = preg_replace('/(<h2>|<br \/>\s*<h2>)/', '<h2>', $content);
    $content = preg_replace('/(<\/h2>|<\/h2><br \/>)/', '</h2>', $content);
    $content = preg_replace('/(<h3>|<br \/>\s*<h3>)/', '<h3>', $content);
    $content = preg_replace('/(<\/h3>|<\/h3><br \/>)/', '</h3>', $content);
    $content = preg_replace('/(<blockquote>|<br \/>\s*<blockquote>)/', '<blockquote>', $content);
    $content = preg_replace('/(<\/blockquote>|<\/blockquote><br \/>)/', '</blockquote>', $content);
    
    return [ 
        'content' => $content, 
        'title' => $title, 
        'description' => isset($meta['description']) ? $meta['description'] : '', 
        'keywords' => isset($meta['keywords']) ? $meta['keywords'] : '', 
        'image' => isset($meta['image']) ? $meta['image'] : '', 
        'error' => false, 
        'published_at' => date("Y-m-d", filemtime($filepath)),
        'read_time' => $read_time
    ];
}

// 4. Listing Logic (FIXED FOR MAIN SITE SLIDER)
function get_post_html($search_query, $random_count = 0) {
    global $post_dir;
    $all_posts = [];
    $files = glob($post_dir . '*.md');
    if ($files) {
        rsort($files);
        foreach ($files as $file) {
            $raw_content = file_get_contents($file);
            $parsed = parse_yaml_front_matter($raw_content);
            $title = isset($parsed['meta']['title']) ? $parsed['meta']['title'] : 'پست بدون عنوان';
            $slug = basename($file, '.md');
            $image_url = isset($parsed['meta']['image']) ? $parsed['meta']['image'] : '';
            $categories = isset($parsed['meta']['category']) ? array_map('trim', explode(',', $parsed['meta']['category'])) : [];
            $post_item = [ 'title' => $title, 'slug' => $slug, 'image_url' => $image_url, 'categories' => $categories, 'raw_content' => $raw_content ];
            
            $match_search = true;
            if ($search_query) {
                $search_lower = mb_strtolower($search_query, 'UTF-8');
                $content_lower = mb_strtolower($raw_content . $title, 'UTF-8');
                if (mb_strpos($content_lower, $search_lower, 0, 'UTF-8') === false) { $match_search = false; }
            }
            if ($match_search) { $all_posts[] = $post_item; }
        }
    }
    if ($random_count > 0 && count($all_posts) > 0) {
        if (count($all_posts) > $random_count) {
            shuffle($all_posts);
            $all_posts = array_slice($all_posts, 0, $random_count);
        }
    }
    
    $output = '';
    if ($all_posts) {
        $output .= '<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 items-stretch">';
        foreach ($all_posts as $post) {
            $image_src = !empty($post['image_url']) ? htmlspecialchars($post['image_url']) : '../img/placeholder.webp';
            $category_html = !empty($post['categories']) ? htmlspecialchars(implode(' / ', $post['categories'])) : 'حقوقی';
            
            // نکته مهم: کلاس post-card اینجا اضافه شد تا جاوااسکریپت سایت اصلی کار کند
            $output .= '<div class="post-card bg-white dark:bg-slate-800 rounded-xl overflow-hidden shadow-lg hover:shadow-2xl dark:shadow-black/20 transition-all duration-300 transform hover:-translate-y-2 border-t-4 border-blue-600 dark:border-gold-accent flex flex-col h-full group">';
            
           // Image (Class: card-image-wrapper)
// تغییر: اضافه کردن style="height: 200px;" و حذف h-[200px]
$output .= '<a href="../blog/index.php?p=' . urlencode($post['slug']) . '" style="height: 300px;" class="card-image-wrapper block w-full overflow-hidden bg-slate-200 dark:bg-slate-700 relative shrink-0">';
$output .= '<img src="' . $image_src . '" alt="' . htmlspecialchars($post['title']) . '" class="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105">';
$output .= '</a>';
            
            // Content (Class: card-content اضافه شد)
            $output .= '<div class="card-content p-6 flex flex-col flex-grow">';
            
            // Category (Class: card-category اضافه شد)
            $output .= '<span class="card-category text-xs font-bold text-green-600 dark:text-green-400 mb-2 block">' . $category_html . '</span>';
            
            // ویرایش: اضافه کردن style="min-height: 85px;" برای رزرو جای ۳ خط متن
$output .= '<h3 class="card-title text-xl font-bold text-slate-900 dark:text-white mb-4 leading-snug" style="min-height: 85px; display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden;">' . htmlspecialchars($post['title']) . '</h3>';
            // Button
            $output .= '<a href="../blog/index.php?p=' . urlencode($post['slug']) . '" class="card-link mt-auto block w-full text-center bg-blue-600 hover:bg-blue-700 dark:bg-gold-accent dark:hover:opacity-90 dark:text-dark-navy text-white font-bold py-2 px-4 rounded-lg transition-colors shadow-md">مشاهده مطلب</a>';
            $output .= '</div></div>';
        }
        $output .= '</div>';
    } else {
        $output .= '<p class="text-center text-red-500 py-8">مطلبی یافت نشد.</p>';
    }
    return $output;
}

// 5. AJAX Handler
$random_count = isset($_GET['random']) ? (int)$_GET['random'] : 0;
$search_query = isset($_GET['s']) ? $_GET['s'] : '';
if ($random_count > 0 || (isset($_GET['s']) && !isset($_GET['p']))) {
    header('Content-Type: text/html; charset=utf-8');
    echo get_post_html($search_query, $random_count);
    exit;
}

// 6. Meta & Config
$current_page = isset($_GET['p']) ? $_GET['p'] : null;
$base_url_scheme = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http");
$base_url_host = $_SERVER['HTTP_HOST'] ?? 'bayvakil.ir';
$base_url_path = $_SERVER['PHP_SELF'] ?? '/blog/index.php';
$base_url = $base_url_scheme . "://" . $base_url_host . $base_url_path;
$canonical_url = $base_url;
$meta_title = 'وبلاگ حقوقی وکیل امیرحسین بای';
$meta_description = 'مقالات تخصصی و کاربردی حقوقی، کیفری، ملکی و خانواده توسط وکیل پایه یک دادگستری.';
$meta_keywords = 'حقوقی, وکیل, ملکی, کیفری, خانواده';
$post_data = ['content' => '', 'title' => '', 'description' => '', 'keywords' => '', 'error' => false];

if ($current_page) {
    $filepath = $post_dir . basename($current_page) . '.md';
    $post_data = get_post_data($filepath);
    if ($post_data['error'] === true) { http_response_code(404); }
    else {
        $canonical_url = $base_url . '?p=' . urlencode($current_page);
        $meta_title = $post_data['title'] . ' - وکیل امیرحسین بای';
        $meta_description = $post_data['description'];
        $meta_keywords = $post_data['keywords'];
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($meta_title); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($meta_description); ?>">
    <meta name="keywords" content="<?php echo htmlspecialchars($meta_keywords); ?>">
    <link rel="canonical" href="<?php echo htmlspecialchars($canonical_url); ?>">
    <link rel="icon" href="../favicon.ico" type="image/x-icon">
    <link rel="preload" href="/fonts/Vazirmatn.woff2" as="font" type="font/woff2" crossorigin fetchpriority="high">

    <style>
    @font-face { font-family: 'Vazirmatn'; src: url('/fonts/Vazirmatn.woff2') format('woff2-variations'), url('/fonts/Vazirmatn.woff2') format('woff2'); font-weight: 100 900; font-style: normal; font-display: swap; }
    body { font-family: 'Vazirmatn', sans-serif; }
    </style>

    <link rel="stylesheet" href="../css/style1.css">
    
    <script>
        if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>

    <!-- Schema Markup -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@graph": [
        {
          "@type": "LegalService",
          "@id": "https://bayvakil.ir/#organization",
          "name": "وکیل امیرحسین بای",
          "url": "https://bayvakil.ir/",
          "logo": "https://bayvakil.ir/favicon.ico",
          "image": "https://bayvakil.ir/img/logo.webp",
          "telephone": "+989113797376",
          "address": { "@type": "PostalAddress", "addressLocality": "گنبد کاووس", "addressRegion": "گلستان", "addressCountry": "IR" }
        },
        {
          "@type": "Person",
          "@id": "https://bayvakil.ir/#person",
          "name": "امیرحسین بای",
          "url": "https://bayvakil.ir/",
          "sameAs": ["https://www.instagram.com/vakilbay"]
        }
        <?php if ($current_page && !$post_data['error']): ?>
        ,{
          "@type": "BlogPosting",
          "headline": "<?php echo addslashes($post_data['title']); ?>",
          "description": "<?php echo addslashes($post_data['description']); ?>",
          "image": "<?php echo !empty($post_data['image']) ? addslashes($post_data['image']) : 'https://bayvakil.ir/img/logo.webp'; ?>",
          "author": { "@id": "https://bayvakil.ir/#person" },
          "publisher": { "@id": "https://bayvakil.ir/#organization" },
          "datePublished": "<?php echo $post_data['published_at']; ?>",
          "mainEntityOfPage": { "@type": "WebPage", "@id": "<?php echo $canonical_url; ?>" }
        }
        <?php else: ?>
        ,{
          "@type": "Blog",
          "name": "وبلاگ حقوقی وکیل بای",
          "publisher": { "@id": "https://bayvakil.ir/#organization" }
        }
        <?php endif; ?>
      ]
    }
    </script>
    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <!-- Custom Styles -->
    <style>
        article p {
            text-align: justify;
            text-justify: inter-word;
            line-height: 2.2;
            margin-bottom: 1.5rem;
            font-size: 1.1rem;
        }
        
        article h1 {
            font-size: 2.2rem;
            font-weight: 800;
            margin-bottom: 1.5rem;
            color: #1e293b;
            border-bottom: 3px solid #004085;
            padding-bottom: 10px;
            line-height: 1.4;
        }
        html.dark article h1 { color: #f1f5f9; border-bottom-color: #D4AF37; }
        
        article h2 {
            font-size: 1.7rem;
            font-weight: 700;
            margin-top: 2.5rem;
            margin-bottom: 1rem;
            color: #334155;
            position: relative;
            padding-right: 15px;
        }
        article h2::before {
            content: '';
            position: absolute;
            right: 0;
            top: 10%;
            height: 80%;
            width: 4px;
            background-color: #004085;
            border-radius: 2px;
        }
        html.dark article h2 { color: #e2e8f0; }
        html.dark article h2::before { background-color: #D4AF37; }

        article h3 {
            font-size: 1.4rem;
            font-weight: 700;
            margin-top: 2rem;
            margin-bottom: 0.8rem;
            color: #475569;
        }
        html.dark article h3 { color: #cbd5e1; }
        
        article strong { color: #0f172a; font-weight: 800; }
        html.dark article strong { color: #fff; }

        article ul, article ol { padding-right: 1.5rem; margin-bottom: 1.5rem; list-style-type: disc; }
        article li { margin-bottom: 0.8rem; text-align: justify; }

        article blockquote {
            border-right: 5px solid #004085;
            background: #f1f5f9;
            padding: 1.5rem;
            margin: 2rem 0;
            border-radius: 0 8px 8px 0;
            font-style: italic;
            color: #334155;
            font-weight: 500;
        }
        html.dark article blockquote {
            border-right-color: #D4AF37;
            background: #1e293b;
            color: #cbd5e1;
        }
        
        article a { color: #2563eb; text-decoration: none; border-bottom: 1px dotted #2563eb; }
        html.dark article a { color: #60a5fa; border-color: #60a5fa; }
        article a:hover { opacity: 0.8; }
    </style>
</head>
<body class="bg-slate-50 dark:bg-dark-navy text-slate-800 dark:text-slate-200 transition-colors duration-500">

    <!-- HEADER -->
    <header class="sticky top-0 z-50 bg-white/80 dark:bg-dark-navy/80 backdrop-blur-sm shadow-md dark:shadow-black/20">
        <div class="container mx-auto px-6 py-3 flex justify-between items-center">
            <div>
                <a href="../" class="cursor-pointer">
                    <h1 class="text-xl md:text-2xl font-bold text-slate-800 dark:text-slate-100">وکیل امیرحسین بای</h1>
                    <p class="text-xs text-blue-600 dark:text-gold-accent font-semibold">متعهد به دفاع از حقوق شما</p>
                </a>
            </div>
            <div class="flex items-center gap-4">
                <nav class="hidden md:flex items-center space-x-6 space-x-reverse" id="desktop-menu">
                    <a href="../" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">خانه</a>
                    <a href="../blog" class="text-blue-600 dark:text-gold-accent font-bold transition-colors duration-300">مقالات</a>
                    <a href="../#services" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">خدمات</a>
                    <a href="../#about" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">درباره</a>
                    <a href="../#contact" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">تماس</a>
                </nav>
                 <button id="theme-toggle" class="p-2 rounded-full text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
                    <svg id="theme-toggle-sun-icon" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-amber-500 hidden" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                    <svg id="theme-toggle-moon-icon" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gold-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path></svg>
                </button>
                <div class="hidden md:block">
                    <div class="text-xs text-center text-slate-500 dark:text-slate-400 w-40">
                        <div id="date-display-desktop"></div>
                        <div id="time-display-desktop" class="font-sans text-xs" dir="ltr"></div>
                    </div>
                </div>
                <div class="md:hidden">
                    <button id="hamburger-button" class="text-slate-800 dark:text-slate-200 focus:outline-none">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
                    </button>
                </div>
            </div>
        </div>
        <div id="mobile-menu" class="hidden md:hidden bg-white/95 dark:bg-dark-navy/95 backdrop-blur-sm">
            <nav class="flex flex-col items-center p-4 space-y-4">
                 <a href="../" class="text-slate-600 dark:text-slate-300">خانه</a>
                 <a href="../blog" class="text-blue-600 dark:text-gold-accent font-bold">مقالات</a>
                 <a href="../#contact" class="text-slate-600 dark:text-slate-300">تماس</a>
                 <div class="pt-4 border-t border-slate-200 dark:border-slate-700 w-full text-center">
                    <div class="text-xs text-slate-500 dark:text-slate-400">
                        <div id="date-display-mobile"></div>
                        <div id="time-display-mobile" class="font-sans mt-1" dir="ltr"></div>
                    </div>
                 </div>
            </nav>
        </div>
    </header>

    <main class="container mx-auto p-4 min-h-screen">
        <?php if ($current_page) {
            // === SINGLE POST VIEW ===
            echo '<article class="bg-white dark:bg-slate-800 p-6 md:p-10 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 max-w-4xl mx-auto transition-colors duration-300">';
            
            // Breadcrumbs & Reading Time
            echo '<div class="flex flex-wrap items-center text-sm text-slate-500 dark:text-slate-400 mb-6 gap-2">';
            echo '<a href="../" class="hover:text-blue-600">خانه</a> <span>/</span>';
            echo '<a href="../blog" class="hover:text-blue-600">مقالات</a> <span>/</span>';
            echo '<span class="text-slate-800 dark:text-slate-200 font-semibold truncate max-w-[150px] md:max-w-none">' . htmlspecialchars($post_data['title']) . '</span>';
            echo '<span class="mr-auto flex items-center gap-1 text-xs bg-slate-100 dark:bg-slate-700 px-2 py-1 rounded"> زمان مطالعه: '.$post_data['read_time'].' دقیقه</span>';
            echo '</div>';

            // Title
            echo '<h1>' . htmlspecialchars($post_data['title']) . '</h1>';
            
            // Image
            if (!empty($post_data['image'])) {
                echo '<img src="'.htmlspecialchars($post_data['image']).'" alt="'.htmlspecialchars($post_data['title']).'" class="w-full h-auto rounded-xl mb-8 shadow-md border border-slate-100 dark:border-slate-700">';
            }
            
            // Content
            echo '<div class="prose dark:prose-invert max-w-none">';
            echo $post_data['content'];
            echo '</div>';

            // Tags
            if (!empty($post_data['keywords'])) {
                echo '<div class="mt-12 pt-6 border-t border-slate-200 dark:border-slate-700">';
                echo '<h4 class="font-bold text-lg mb-3 text-slate-800 dark:text-slate-100">برچسب‌ها:</h4>';
                $keywords = explode(',', $post_data['keywords']);
                echo '<div class="flex flex-wrap gap-3">';
                foreach ($keywords as $keyword) {
                    $tag = trim($keyword);
                    if (!empty($tag)) {
                        echo '<span class="bg-slate-100 dark:bg-slate-700 text-slate-600 dark:text-slate-300 text-sm py-1 px-3 rounded-full transition-colors hover:bg-slate-200 dark:hover:bg-slate-600">' . htmlspecialchars($tag) . '</span>';
                    }
                }
                echo '</div></div>';
            }

            // === SHARE BUTTONS ===
            $page_url = "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
            echo '<div class="mt-8 pt-6 border-t border-slate-200 dark:border-slate-700">';
            echo '<h4 class="font-bold text-lg mb-4 text-slate-800 dark:text-slate-100">اشتراک‌گذاری این مطلب:</h4>';
            echo '<div class="flex flex-wrap gap-4">';
            
            // Telegram
            echo '<a href="https://t.me/share/url?url='.urlencode($page_url).'&text='.urlencode($post_data['title']).'" target="_blank" style="background-color: #229ED9; color: white;" class="flex items-center gap-2 px-5 py-3 rounded-lg font-bold shadow-md transition-transform hover:scale-105">';
            echo '<svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg>';
            echo 'تلگرام</a>';

            // WhatsApp
            echo '<a href="https://wa.me/?text='.urlencode($post_data['title'] . "\n" . $page_url).'" target="_blank" style="background-color: #25D366; color: white;" class="flex items-center gap-2 px-5 py-3 rounded-lg font-bold shadow-md transition-transform hover:scale-105">';
            echo '<svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/></svg>';
            echo 'واتساپ</a>';
            
            // Copy Link
            echo '<button onclick="navigator.clipboard.writeText(\''.$page_url.'\'); alert(\'لینک کپی شد!\');" style="background-color: #64748b; color: white;" class="flex items-center gap-2 px-5 py-3 rounded-lg font-bold shadow-md transition-transform hover:scale-105">';
            echo '<svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>';
            echo 'کپی لینک</button>';
            
            echo '</div></div>';
            
            echo '<div class="mt-8 pt-4 border-t border-slate-200 dark:border-slate-700 flex justify-between items-center flex-wrap gap-4">';
            echo '<div class="text-slate-500 dark:text-slate-400 font-semibold text-sm">وکیل امیرحسین بای - 09113797376</div>';
            echo '<a href="../blog" class="text-blue-600 dark:text-gold-accent hover:underline font-bold">→ بازگشت به لیست مقالات</a>';
            echo '</div>';
            echo '</article>';
            
        } else {
            // === ARCHIVE VIEW ===
            echo '<div class="text-center mb-8 pt-8">';
            echo '<h2 class="text-3xl md:text-4xl font-extrabold text-slate-900 dark:text-white mb-4">آخرین مطالب حقوقی</h2>';
            echo '<p class="text-slate-600 dark:text-slate-400 mb-8 text-lg">جستجو در بانک مقالات و دانستنی‌های حقوقی</p>';
            echo '<div class="max-w-xl mx-auto relative mb-12">'; 
            echo '<input type="text" id="live-search-input" placeholder="مثلا: طلاق، چک، مهریه..." class="w-full px-5 py-3 rounded-lg border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-blue-500 dark:focus:ring-gold-accent outline-none transition-all shadow-sm">';
            echo '</div>';
            echo '</div>';
            
            echo '<div id="search-results-container">';
            echo get_post_html('');
            echo '</div>';
        } ?>
    </main>

    <footer class="bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-t border-slate-200 dark:border-slate-700 mt-12">
        <div class="container mx-auto px-6 py-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p>© 1404 وکیل امیرحسین بای. تمامی حقوق محفوظ است.</p>
            <div class="text-sm flex items-center gap-2">
                <span>تلفن:</span>
                <a href="tel:09113797376" dir="ltr" class="hover:text-blue-600 dark:hover:text-gold-accent font-sans font-bold">0911-379-7376</a>
            </div>
        </div>
    </footer>

    <script>
        // Live Search
        $(document).ready(function() {
            var searchInput = $('#live-search-input');
            var resultsContainer = $('#search-results-container');
            var timeout = null;
            if (searchInput.length && resultsContainer.length) {
                searchInput.on('keyup', function() {
                    clearTimeout(timeout);
                    timeout = setTimeout(function() {
                        var query = searchInput.val().trim();
                        resultsContainer.html('<p class="text-center text-slate-500 py-8">در حال جستجو...</p>');
                        $.ajax({
                            url: '../blog/index.php', type: 'GET', data: { s: query },
                            success: function(response) { resultsContainer.html(response); },
                            error: function() { resultsContainer.html('<p class="text-center text-red-500">خطا در جستجو.</p>'); }
                        });
                    }, 300);
                });
            }
        });

        // Main JS Logic
        document.addEventListener('DOMContentLoaded', () => {
            const hamburgerBtn = document.getElementById('hamburger-button');
            const mobileMenu = document.getElementById('mobile-menu');
            if (hamburgerBtn && mobileMenu) {
                hamburgerBtn.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));
            }

            const themeToggle = document.getElementById('theme-toggle');
            const sunIcon = document.getElementById('theme-toggle-sun-icon');
            const moonIcon = document.getElementById('theme-toggle-moon-icon');
            
            function updateThemeIcons() {
                if (document.documentElement.classList.contains('dark')) {
                    sunIcon.classList.add('hidden');
                    moonIcon.classList.remove('hidden');
                } else {
                    sunIcon.classList.remove('hidden');
                    moonIcon.classList.add('hidden');
                }
            }
            updateThemeIcons();

            themeToggle.addEventListener('click', () => {
                document.documentElement.classList.toggle('dark');
                if (document.documentElement.classList.contains('dark')) {
                    localStorage.setItem('color-theme', 'dark');
                } else {
                    localStorage.setItem('color-theme', 'light');
                }
                updateThemeIcons();
            });

            const dateElements = { desktop: document.getElementById('date-display-desktop'), mobile: document.getElementById('date-display-mobile') };
            const timeElements = { desktop: document.getElementById('time-display-desktop'), mobile: document.getElementById('time-display-mobile') };
            
            function updateDateTime() { 
                const now = new Date(); 
                const weekday = now.toLocaleDateString('fa-IR', { weekday: 'long' });
                const day = now.toLocaleDateString('fa-IR', { day: 'numeric' });
                const month = now.toLocaleDateString('fa-IR', { month: 'long' });
                const year = now.toLocaleDateString('fa-IR', { year: 'numeric' });
                const formattedDate = `${weekday}، ${day} ${month} ${year}`;
                
                const formattedTime = now.toLocaleTimeString('fa-IR', { 
                    hour: '2-digit', minute: '2-digit', second: '2-digit' 
                }); 
                
                if(dateElements.desktop) dateElements.desktop.textContent = formattedDate; 
                if(dateElements.mobile) dateElements.mobile.textContent = formattedDate; 
                
                if(timeElements.desktop) {
                    timeElements.desktop.textContent = formattedTime;
                    timeElements.desktop.classList.remove('font-mono', 'tracking-wider');
                    timeElements.desktop.removeAttribute('dir');
                }
                if(timeElements.mobile) {
                    timeElements.mobile.textContent = formattedTime;
                    timeElements.mobile.classList.remove('font-mono', 'tracking-wider');
                    timeElements.mobile.removeAttribute('dir');
                }
            }
            updateDateTime();
            setInterval(updateDateTime, 1000);
        });
    </script>
</body>
</html>