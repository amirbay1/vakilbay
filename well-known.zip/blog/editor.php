<?php
// --- VAKIL BAY PROFESSIONAL CMS - FIXED DARK MODE ---

// 1. CONFIGURATION
error_reporting(0);
header('Content-Type: text/html; charset=utf-8');

// Security & Paths
$auth_hash      = '$2y$10$sFeT4tZNztXH1ZzTvjooA.dZosJ2aHg6tGs9CXUmp3c291NHTlJCS'; // Pass: Amirbay@1750920
$base_path      = '../blog/';
$post_dir       = $base_path . 'posts/';
$uploads_dir    = $base_path . 'uploads/';
$uploads_rel    = 'uploads/'; 

if (!is_dir($post_dir)) mkdir($post_dir, 0755, true);
if (!is_dir($uploads_dir)) mkdir($uploads_dir, 0755, true);

// 2. AUTHENTICATION
session_start();
if (isset($_GET['logout'])) { session_destroy(); header('Location: '.basename(__FILE__)); exit; }
if ($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['auth_pass'])) {
    if (password_verify($_POST['auth_pass'], $auth_hash)) $_SESSION['auth'] = true;
    else $error = "رمز عبور اشتباه است";
}
if (!isset($_SESSION['auth'])) {
    // Login Page
    ?>
    <!DOCTYPE html><html lang="fa" dir="rtl" class="dark"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>ورود به پنل</title>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root { --bg: #0A192F; --text: #cbd5e1; --gold: #D4AF37; --border: #334155; --card: #1e293b; }
        body { font-family:'Vazirmatn',sans-serif; background: var(--bg); color: var(--text); height: 100vh; display: flex; align-items: center; justify-content: center; margin: 0; }
        .login-card { background: var(--card); padding: 2rem; border-radius: 1rem; border: 1px solid var(--border); width: 100%; max-width: 350px; text-align: center; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.5); }
        .logo { width: 80px; height: 80px; margin: 0 auto 1rem; border-radius: 50%; border: 3px solid var(--gold); overflow: hidden; }
        .logo img { width: 100%; height: 100%; object-fit: cover; }
        input { width: 100%; padding: 12px; margin: 1rem 0; border-radius: 0.5rem; border: 1px solid var(--border); background: var(--bg); color: white; font-family: inherit; box-sizing: border-box; outline: none; transition: 0.3s; }
        input:focus { border-color: var(--gold); }
        button { width: 100%; padding: 12px; border-radius: 0.5rem; border: none; background: var(--gold); color: #0A192F; font-weight: bold; cursor: pointer; font-family: inherit; transition: 0.3s; }
        button:hover { background: #e6c55c; transform: translateY(-2px); }
        .error { color: #ef4444; margin-bottom: 1rem; font-size: 0.9rem; }
    </style>
    </head><body>
    <div class="login-card">
        <div class="logo"><img src="../img/logo.webp" alt="Logo"></div>
        <h2 style="margin-bottom: 0.5rem; color:white;">پنل مدیریت</h2>
        <p style="color: #94a3b8; margin-top: 0;">وکیل امیرحسین بای</p>
        <form method="POST">
            <?php if(isset($error)) echo "<div class='error'>$error</div>"; ?>
            <input type="password" name="auth_pass" placeholder="رمز عبور..." required autofocus>
            <button type="submit">ورود به سیستم</button>
        </form>
    </div>
    </body></html>
    <?php exit;
}

// 3. AJAX HANDLER
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $res = ['ok' => false, 'msg' => 'Error'];
    
    if ($_POST['action'] === 'save') {
        $slug = preg_replace('/[^\p{L}\p{N}\s\-_]/u', '', basename($_POST['filename']));
        $slug = trim(str_replace(' ', '-', $slug));
        
        if (!$slug) $res['msg'] = 'عنوان نامعتبر است';
        else {
            $meta = [
                'title' => $_POST['title'],
                'description' => $_POST['description'],
                'keywords' => $_POST['keywords'],
                'image' => $_POST['image'],
                'category' => $_POST['category'],
                'status' => $_POST['status'] ?? 'published',
                'publish_date' => date('Y-m-d H:i')
            ];
            
            $yaml = "---\n";
            foreach($meta as $k=>$v) if($v) $yaml .= "$k: $v\n";
            $yaml .= "---\n" . $_POST['content'];
            
            if (file_put_contents($post_dir . $slug . '.md', $yaml)) {
                $res = ['ok' => true, 'msg' => 'ذخیره شد', 'slug' => $slug];
            }
        }
    }
    elseif ($_POST['action'] === 'upload') {
        if ($_FILES['file']['error'] === 0) {
            $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
            $name = time() . '_' . rand(100,999) . '.' . $ext;
            if (move_uploaded_file($_FILES['file']['tmp_name'], $uploads_dir . $name)) {
                $res = ['ok' => true, 'url' => $uploads_rel . $name]; 
            }
        }
    }
    elseif ($_POST['action'] === 'delete') {
        $file = $post_dir . basename($_POST['file']) . '.md';
        if (file_exists($file) && unlink($file)) $res = ['ok' => true];
    }
    
    echo json_encode($res); exit;
}

// 4. EDITOR SETUP
$edit_slug = $_GET['edit'] ?? null;
$content = ''; 
$meta = ['title'=>'', 'description'=>'', 'keywords'=>'', 'image'=>'', 'category'=>''];
$is_new = true;

if ($edit_slug && file_exists($post_dir . $edit_slug . '.md')) {
    $raw = file_get_contents($post_dir . $edit_slug . '.md');
    if (preg_match('/^---\s*$(.*?)^---\s*$/ms', $raw, $m)) {
        $content = str_replace($m[0], '', $raw);
        foreach(explode("\n", trim($m[1])) as $l) {
            if (strpos($l, ':')!==false) {
                list($k, $v) = explode(':', $l, 2);
                $meta[trim($k)] = trim($v);
            }
        }
    } else { $content = $raw; }
    $is_new = false;
}

$posts = [];
foreach(glob($post_dir.'*.md') as $f) {
    $posts[basename($f,'.md')] = filemtime($f);
}
arsort($posts);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl" class="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت وبلاگ</title>
    <!-- ToastUI Editor -->
    <link rel="stylesheet" href="https://uicdn.toast.com/editor/latest/toastui-editor.min.css" />
    <link rel="stylesheet" href="https://uicdn.toast.com/editor/latest/theme/toastui-editor-dark.min.css" />
    <link rel="preload" href="../fonts/Vazirmatn.woff2" as="font" type="font/woff2" crossorigin>
    <style>
        @font-face { font-family: 'Vazirmatn'; src: url('../fonts/Vazirmatn.woff2') format('woff2'); font-weight: 100 900; display: swap; }
        
        /* --- 1. THEME VARIABLES (Corrected) --- */
        :root {
            /* Dark Theme (Default) */
            --bg: #0A192F;
            --sidebar: #112240;
            --header: #112240;
            --text: #cbd5e1;
            --border: #233554;
            --input-bg: #0A192F;
            --gold: #D4AF37;
            --success: #10b981;
            --danger: #ef4444;
            --hover-bg: rgba(212, 175, 55, 0.1);
        }
        
        /* Light Theme Override */
        html.light {
            --bg: #f8fafc;
            --sidebar: #ffffff;
            --header: #ffffff;
            --text: #1e293b;
            --border: #e2e8f0;
            --input-bg: #f1f5f9;
            --gold: #004085; /* Blue for light mode to match main site */
            --hover-bg: rgba(0, 64, 133, 0.05);
        }

        * { box-sizing: border-box; outline: none; }
        body { margin: 0; font-family: 'Vazirmatn', sans-serif; background: var(--bg); color: var(--text); display: flex; height: 100vh; overflow: hidden; transition: background 0.3s, color 0.3s; }
        
        /* Sidebar */
        aside { width: 280px; background: var(--sidebar); border-left: 1px solid var(--border); display: flex; flex-direction: column; padding: 20px; z-index: 10; transition: 0.3s; }
        .brand { font-size: 1.2rem; font-weight: 800; color: var(--gold); text-align: center; padding-bottom: 20px; border-bottom: 1px solid var(--border); margin-bottom: 20px; }
        .post-list { flex: 1; overflow-y: auto; }
        .post-link { display: block; padding: 12px; border-radius: 8px; color: var(--text); text-decoration: none; margin-bottom: 5px; transition: 0.2s; border-right: 3px solid transparent; }
        .post-link:hover { background: var(--hover-bg); }
        .post-link.active { background: var(--hover-bg); border-right-color: var(--gold); font-weight: bold; }
        .post-date { font-size: 0.75rem; opacity: 0.6; margin-top: 4px; display: block; }

        /* Main */
        main { flex: 1; display: flex; flex-direction: column; min-width: 0; }
        header { height: 60px; background: var(--header); border-bottom: 1px solid var(--border); display: flex; align-items: center; justify-content: space-between; padding: 0 20px; transition: 0.3s; }
        
        .btn { padding: 8px 16px; border-radius: 6px; border: none; cursor: pointer; font-family: inherit; font-weight: bold; transition: 0.2s; display: inline-flex; align-items: center; gap: 5px; text-decoration: none; font-size: 0.9rem; }
        .btn-primary { background: var(--gold); color: html.light ? white : #0A192F; }
        html.dark .btn-primary { color: #0A192F; }
        html.light .btn-primary { color: white; }
        
        .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
        .btn-danger { background: rgba(239, 68, 68, 0.1); color: var(--danger); }
        .btn-danger:hover { background: var(--danger); color: white; }
        .btn-icon { background: transparent; color: var(--text); font-size: 1.2rem; padding: 5px; border-radius: 5px; cursor: pointer; border: none; }
        .btn-icon:hover { background: var(--border); }

        /* Editor Form */
        .content-area { flex: 1; overflow-y: auto; padding: 30px; }
        .input-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: bold; font-size: 0.9rem; color: var(--gold); }
        input[type="text"], textarea { width: 100%; padding: 12px; background: var(--input-bg); border: 1px solid var(--border); color: var(--text); border-radius: 8px; font-family: inherit; transition: 0.3s; }
        input:focus, textarea:focus { border-color: var(--gold); box-shadow: 0 0 0 2px rgba(212, 175, 55, 0.2); }
        
        details { background: var(--sidebar); border: 1px solid var(--border); border-radius: 8px; margin-bottom: 15px; }
        summary { padding: 15px; cursor: pointer; font-weight: bold; list-style: none; display: flex; align-items: center; justify-content: space-between; color: var(--text); }
        summary::after { content: '+'; color: var(--gold); font-size: 1.2rem; }
        details[open] summary::after { content: '-'; }
        .details-body { padding: 20px; border-top: 1px solid var(--border); }

        .drop-zone { border: 2px dashed var(--border); padding: 20px; text-align: center; border-radius: 8px; cursor: pointer; transition: 0.3s; color: var(--text); }
        .drop-zone:hover { border-color: var(--gold); background: var(--hover-bg); }
        .preview-img { max-width: 100%; max-height: 200px; margin-top: 10px; border-radius: 8px; display: none; border: 1px solid var(--border); }

        /* Mobile */
        @media(max-width: 768px) {
            aside { position: fixed; right: -100%; height: 100%; z-index: 50; }
            aside.open { right: 0; box-shadow: -5px 0 20px rgba(0,0,0,0.5); }
            .menu-toggle { display: block !important; }
        }
        .menu-toggle { display: none; }
        
        /* Fix ToastUI Colors */
        .toastui-editor-defaultUI { font-family: 'Vazirmatn', sans-serif !important; border-color: var(--border) !important; }
        .toastui-editor-defaultUI .toastui-editor-ww-container, .toastui-editor-defaultUI .toastui-editor-md-container { background-color: var(--input-bg) !important; }
        
        html.light .toastui-editor-mode-switch { background: #f1f5f9; border-top: 1px solid #e2e8f0; }
        html.light .toastui-editor-defaultUI .toastui-editor-md-container { color: #333; }
    </style>
</head>
<body>

<aside id="sidebar">
    <div class="brand">وکیل بای - مدیریت</div>
    <a href="?edit=new" class="btn btn-primary" style="display:block; text-align:center; margin-bottom:15px;">+ پست جدید</a>
    <div class="post-list">
        <?php foreach($posts as $slug=>$time): ?>
            <a href="?edit=<?= $slug ?>" class="post-link <?= ($edit_slug===$slug)?'active':'' ?>">
                <?= urldecode(str_replace('-', ' ', $slug)) ?>
                <span class="post-date"><?= date('Y/m/d', $time) ?></span>
            </a>
        <?php endforeach; ?>
    </div>
</aside>

<main>
    <header>
        <div style="display:flex; align-items:center; gap:15px;">
            <button class="btn-icon menu-toggle" onclick="document.getElementById('sidebar').classList.toggle('open')">☰</button>
            <h2 style="margin:0; font-size:1.1rem; color:var(--text);">
                <?= $is_new ? '📝 ایجاد مطلب' : '✏️ ویرایش مطلب' ?>
            </h2>
        </div>
        <div style="display:flex; align-items:center; gap:10px;">
            <button class="btn-icon" id="theme-btn" title="تغییر تم">🌗</button>
            <a href="../blog/" target="_blank" class="btn-icon" title="مشاهده وبلاگ">👁️</a>
            <a href="?logout=1" class="btn-icon" title="خروج" style="color:var(--danger);">✕</a>
        </div>
    </header>

    <div class="content-area">
        <form id="editor-form">
            <div class="input-group">
                <input type="text" id="title" placeholder="عنوان جذاب مقاله خود را اینجا بنویسید..." value="<?= htmlspecialchars($meta['title']) ?>" style="font-size:1.2rem; font-weight:bold;" required>
            </div>

            <!-- Editor Container -->
            <div id="editor" style="margin-bottom:30px;"></div>

            <details open>
                <summary>اطلاعات سئو و دسته‌بندی</summary>
                <div class="details-body">
                    <div class="input-group">
                        <label>توضیحات متا (Description)</label>
                        <textarea id="description" rows="2" placeholder="خلاصه‌ای برای گوگل..."><?= htmlspecialchars($meta['description']) ?></textarea>
                        <div style="text-align:left; font-size:0.8rem; color:var(--text); opacity:0.7;" id="char-count">0 / 160</div>
                    </div>
                    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px;">
                        <div class="input-group">
                            <label>کلمات کلیدی (با کاما جدا کنید)</label>
                            <input type="text" id="keywords" value="<?= htmlspecialchars($meta['keywords']) ?>" placeholder="وکیل, طلاق, چک...">
                        </div>
                        <div class="input-group">
                            <label>دسته‌بندی</label>
                            <input type="text" id="category" value="<?= htmlspecialchars($meta['category']) ?>" placeholder="مثلا: حقوقی">
                        </div>
                    </div>
                </div>
            </details>

            <details>
                <summary>تصویر شاخص</summary>
                <div class="details-body">
                    <div class="drop-zone" id="drop-zone">
                        <p>تصویر را اینجا رها کنید یا کلیک کنید</p>
                        <input type="file" id="file-input" hidden accept="image/*">
                    </div>
                    <input type="text" id="image" value="<?= htmlspecialchars($meta['image']) ?>" placeholder="آدرس تصویر..." style="margin-top:10px; direction:ltr;">
                    <img id="preview" class="preview-img" src="<?= htmlspecialchars($meta['image']) ?>" style="display:<?= $meta['image']?'block':'none' ?>">
                </div>
            </details>

            <div style="display:flex; justify-content:space-between; border-top:1px solid var(--border); padding-top:20px;">
                <button type="submit" class="btn btn-primary" id="save-btn">ذخیره تغییرات</button>
                <?php if(!$is_new): ?>
                    <button type="button" class="btn btn-danger" onclick="deletePost()">حذف این پست</button>
                <?php endif; ?>
            </div>
        </form>
    </div>
</main>

<script src="https://uicdn.toast.com/editor/latest/toastui-editor-all.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', () => {
    const html = document.documentElement;
    const themeBtn = document.getElementById('theme-btn');

    // 1. Theme Logic (Fixed)
    // Check local storage or system preference
    if (localStorage.getItem('theme') === 'light') {
        html.classList.remove('dark'); html.classList.add('light');
    } else {
        html.classList.remove('light'); html.classList.add('dark');
    }

    themeBtn.onclick = () => {
        if (html.classList.contains('dark')) {
            html.classList.replace('dark', 'light');
            localStorage.setItem('theme', 'light');
            // Reload editor to apply light theme if needed (ToastUI requires re-init for full theme switch, but CSS override handles most)
        } else {
            html.classList.replace('light', 'dark');
            localStorage.setItem('theme', 'dark');
        }
    };

    // 2. Editor Init
    const editor = new toastui.Editor({
        el: document.querySelector('#editor'),
        height: '500px',
        initialEditType: 'wysiwyg',
        previewStyle: 'vertical',
        initialValue: `<?= str_replace('`', '\`', $content) ?>`,
        language: 'fa-IR',
        // We allow CSS variables to handle coloring, but 'dark' theme class helps toastui load dark base styles
        theme: 'dark', 
        toolbarItems: [
            ['heading', 'bold', 'italic', 'strike'],
            ['hr', 'quote'],
            ['ul', 'ol', 'task', 'indent', 'outdent'],
            ['table', 'image', 'link'],
            ['code', 'codeblock']
        ]
    });

    // 3. Image Upload Logic
    const dropZone = document.getElementById('drop-zone');
    const fileInput = document.getElementById('file-input');
    const imageInput = document.getElementById('image');
    const preview = document.getElementById('preview');

    dropZone.onclick = () => fileInput.click();
    
    const handleUpload = (file) => {
        const fd = new FormData();
        fd.append('action', 'upload');
        fd.append('file', file);
        
        dropZone.innerText = 'در حال آپلود...';
        
        fetch('', { method:'POST', body:fd })
        .then(r=>r.json())
        .then(d => {
            if(d.ok) {
                imageInput.value = d.url;
                // Fix preview path for admin panel context
                preview.src = '../blog/' + d.url; 
                preview.style.display = 'block';
                dropZone.innerText = 'آپلود شد! (تغییر مجدد)';
            } else {
                alert('خطا در آپلود');
                dropZone.innerText = 'خطا. دوباره تلاش کنید';
            }
        });
    };

    fileInput.onchange = () => { if(fileInput.files[0]) handleUpload(fileInput.files[0]); };
    dropZone.ondragover = e => { e.preventDefault(); dropZone.style.borderColor = 'var(--gold)'; };
    dropZone.ondragleave = e => { dropZone.style.borderColor = 'var(--border)'; };
    dropZone.ondrop = e => {
        e.preventDefault();
        if(e.dataTransfer.files[0]) handleUpload(e.dataTransfer.files[0]);
    };

    // 4. SEO Counter
    const desc = document.getElementById('description');
    const count = document.getElementById('char-count');
    
    const updateCount = () => {
        count.innerText = desc.value.length + ' / 160';
        count.style.color = desc.value.length > 160 ? 'var(--danger)' : 'var(--text)';
    };
    desc.oninput = updateCount;
    updateCount(); // Init

    // 5. Form Submit
    document.getElementById('editor-form').onsubmit = e => {
        e.preventDefault();
        const btn = document.getElementById('save-btn');
        const oldText = btn.innerText;
        btn.innerText = 'در حال ذخیره...';
        btn.disabled = true;

        const fd = new FormData();
        fd.append('action', 'save');
        fd.append('filename', '<?= $edit_slug ?>' || document.getElementById('title').value);
        fd.append('title', document.getElementById('title').value);
        fd.append('content', editor.getMarkdown());
        fd.append('description', document.getElementById('description').value);
        fd.append('keywords', document.getElementById('keywords').value);
        fd.append('category', document.getElementById('category').value);
        fd.append('image', document.getElementById('image').value);

        fetch('', { method:'POST', body:fd })
        .then(r=>r.json())
        .then(d => {
            if(d.ok) {
                alert('✅ پست با موفقیت ذخیره شد');
                if(!'<?= $edit_slug ?>') window.location.href = '?edit=' + d.slug;
            } else {
                alert('❌ ' + d.msg);
            }
            btn.innerText = oldText;
            btn.disabled = false;
        });
    };

    // 6. Delete Post
    window.deletePost = () => {
        if(confirm('آیا مطمئن هستید؟ این عمل غیرقابل بازگشت است.')) {
            const fd = new FormData();
            fd.append('action', 'delete');
            fd.append('file', '<?= $edit_slug ?>');
            fetch('', { method:'POST', body:fd }).then(()=> window.location.href='?');
        }
    };
});
</script>
</body>
</html>