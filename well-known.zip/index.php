<!DOCTYPE html>
<html lang="fa" dir="rtl" class="">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- SEO Tags -->
<title>وکیل امیرحسین بای | وکیل پایه یک دادگستری گنبد کاووس</title>
<meta name="robots" content="index, follow">
<meta name="description" content="مشاوره حقوقی فوری با وکیل امیرحسین بای در گنبد کاووس. قبول وکالت تخصصی در دعاوی ملکی، خانواده، کیفری و دیه. تماس مستقیم: ۰۹۱۱۳۷۹۷۳۷۶">
<script>
    // بررسی تم قبل از لود شدن کامل صفحه برای جلوگیری از پرش رنگ
    if (localStorage.getItem('color-theme') === 'dark' || (!('color-theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
        document.documentElement.classList.add('dark');
    } else {
        document.documentElement.classList.remove('dark');
    }
</script>
<meta name="keywords" content="وکیل امیرحسین بای, امیرحسین بای, وکیل پایه یک دادگستری, وکیل گنبد کاووس, وکیل در استان گلستان, بهترین وکیل گنبد, مشاوره حقوقی تلفنی, وکیل ملکی, وکیل خانواده و طلاق, وکیل کیفری, وصول مطالبات و چک, تنظیم قرارداد, Lawyer Gonbad, Vakil Bay, Amirhossein Bay, Vakil Gonbad Kavus, Gorgan Lawyer, Iranian Lawyer, مشاوره رایگان واتساپ">
    <meta name="author" content="وکیل امیرحسین بای">
    <!-- 2. Open Graph / Social Media (WhatsApp, Telegram, LinkedIn) -->
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://bayvakil.ir/">
    <meta property="og:title" content="وکیل امیرحسین بای - وکیل پایه یک دادگستری">
    <meta property="og:description" content="مشاوره حقوقی تخصصی و قبول وکالت در کلیه دعاوی حقوقی، کیفری و خانواده در گنبد کاووس و استان گلستان.">
    <meta property="og:image" content="/img/logo.webp">
    <meta property="og:image:width" content="500">
    <meta property="og:image:height" content="500">
    <meta property="og:image:alt" content="لوگوی وکیل امیرحسین بای">
    <meta property="og:locale" content="fa_IR">
    <meta property="og:site_name" content="وکیل امیرحسین بای">
<meta name="thumbnail" content="/img/logo.webp">
<link rel="canonical" href="<?php echo 'https://' . $_SERVER['HTTP_HOST'] . strtok($_SERVER['REQUEST_URI'], '?'); ?>">

<meta name="application-name" content="وکیل امیرحسین بای">
<meta name="apple-mobile-web-app-title" content="وکیل امیرحسین بای">

    <link rel="icon" href="/favicon.ico" type="image/x-icon" sizes="48x48">

<link rel="apple-touch-icon" href="/img/logo.webp">
<!-- 3. Twitter Card (For Twitter/X) -->
    <meta name="twitter:card" content="summary">
    <meta name="twitter:title" content="وکیل امیرحسین بای | وکیل گنبد کاووس">
    <meta name="twitter:description" content="مشاوره حقوقی تخصصی در دعاوی ملکی، کیفری و خانواده.">
    <meta name="twitter:image" content="https://bayvakil.ir/img/logo.webp">
    
    <!-- Styles and Fonts -->
<link rel="stylesheet" href="/css/style1.css">

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebSite",
      "@id": "https://bayvakil.ir/#website",
      "url": "https://bayvakil.ir/",
      "name": "وکیل امیرحسین بای",
      "alternateName": [
        "وکیل بای",
        "Amirhossein Bay",
        "Vakil Bay",
        "Vakil Amirhossein Bay",
        "Mr. Bay Lawyer"
      ],
      "description": "وکیل پایه یک دادگستری در گنبد کاووس، مشاوره حقوقی، کیفری و خانواده.",
      "publisher": {
        "@id": "https://bayvakil.ir/#organization"
      },
      "inLanguage": "fa-IR"
    },
    {
      "@type": "Person",
      "@id": "https://bayvakil.ir/#person",
      "name": "امیرحسین بای",
      "alternateName": [
        "وکیل بای",
        "Amirhossein Bay",
        "Vakil Bay",
        "Vakil Amirhossein Bay",
        "Mr. Bay Lawyer"
      ],
      "image": {
        "@type": "ImageObject",
        "url": "https://bayvakil.ir/img/logo.webp",
        "width": 1200,
        "height": 1200,
        "caption": "امیرحسین بای - وکیل دادگستری"
      },
      "jobTitle": "وکیل پایه یک دادگستری",
      "url": "https://bayvakil.ir/",
      "sameAs": [
        "https://www.instagram.com/vakilbay",
        "https://t.me/bayvakikl",
        "https://wa.me/989113797376"
      ],
      "worksFor": {
        "@id": "https://bayvakil.ir/#organization"
      }
    },
    {
      "@type": "LegalService",
      "@id": "https://bayvakil.ir/#organization",
      "name": "دفتر وکالت امیرحسین بای",
      "alternateName": [
        "وکیل بای",
        "Amirhossein Bay",
        "Vakil Bay",
        "Vakil Amirhossein Bay",
        "Mr. Bay Lawyer"
      ],
      "url": "https://bayvakil.ir/",
      "logo": "https://bayvakil.ir/favicon.ico",
      "image": "https://bayvakil.ir/img/logo.webp",
      "description": "قبول وکالت در دعاوی حقوقی، کیفری، ملکی و خانواده در گنبد کاووس و استان گلستان.",
      "telephone": "+989113797376",
      "priceRange": "$$",
      "address": {
        "@type": "PostalAddress",
        "streetAddress": "خیابان دارایی، مجتمع بردی پور، طبقه دوم، واحد 4",
        "addressLocality": "گنبد کاووس",
        "addressRegion": "گلستان",
        "postalCode": "4971844551",
        "addressCountry": "IR"
      },
      "geo": {
        "@type": "GeoCoordinates",
        "latitude": 37.253311,
        "longitude": 55.165675
      },
      "hasMap": "https://maps.google.com/maps?q=37.25331174361873,55.165675084415156",
      "openingHoursSpecification": [
        {
          "@type": "OpeningHoursSpecification",
          "dayOfWeek": [
            "Saturday",
            "Sunday",
            "Monday",
            "Tuesday",
            "Wednesday"
          ],
          "opens": "17:00",
          "closes": "21:00"
        }
      ],
      "founder": {
        "@id": "https://bayvakil.ir/#person"
      },
      "serviceArea": {
        "@type": "AdministrativeArea",
        "name": "گلستان"
      },
      "serviceType": [
        "مشاوره حقوقی",
        "دعاوی کیفری",
        "دعاوی خانواده",
        "دعاوی ملکی"
      ]
    }
  ]
}
</script>


    <!-- فونت متغیر Vazirmatn (محلی) -->
<link rel="preload" href="/fonts/Vazirmatn.woff2" as="font" type="font/woff2" crossorigin fetchpriority="high">

<style>
@font-face {
  font-family: 'Vazirmatn';
  src: url('/fonts/Vazirmatn.woff2') format('woff2-variations'),
       url('/fonts/Vazirmatn.woff2') format('woff2');
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}

/* فونت پیش‌فرض برای کل سایت */
body {
  font-family: 'Vazirmatn', sans-serif;
}
</style>


    
    <style>
        :root { 
            scroll-behavior: smooth; 
            /* Light Mode Colors from chos.css */
            --text-color: #333333;
            --primary-color: #004085;
            --card-bg-color: #ffffff;
            --shadow-color: rgba(0, 0, 0, 0.08);
            --border-color: #e0e0e0;
            --category-color: #28a745;
        }

        html.dark {
            /* Dark Mode Colors from chos.css */
            --text-color: #e0e0e0;
            --primary-color: #475569; /* slate-600 */
            --card-bg-color: #0A192F; /* dark-navy */
            --shadow-color: rgba(0, 0, 0, 0.3);
            --border-color: #444444;
            --category-color: #66bb6a;
        }

        body { font-family: 'Vazirmatn', sans-serif; }
        .max-h-0 { max-height: 0; }
        .max-h-screen { max-height: 100vh; }

        /* === کدهای نهایی و بهینه شده برای اسلایدر === */
        #slider-wrapper { 
            position: relative; 
            /* تغییر: افزایش عرض برای استفاده بهتر از فضا در دسکتاپ */
            max-width: 900px; 
            margin: 0 auto; 
        }
        #slider-container { 
            position: relative; 
            width: 100%; 
            max-width: 320px; 
            /* تغییر: افزایش ارتفاع برای زیبایی بیشتر */
            height: 480px; 
            margin: 0 auto; 
            /* تغییر: بهبود پرسپکتیو */
            perspective: 1500px; 
        }

        .slider-card-wrapper {
            position: absolute !important;
            top: 0; left: 0; right: 0;
            margin: 0 auto !important;
            width: 100% !important;
            height: 100% !important;
            transition: transform 0.6s ease, opacity 0.6s ease;
            opacity: 0;
            transform-style: preserve-3d;
            backface-visibility: hidden;
        }
        
        #articles .post-card { 
            background: var(--card-bg-color); 
            border-radius: 12px; 
            overflow: hidden; 
            box-shadow: 0 4px 15px var(--shadow-color); 
            border: 1px solid var(--border-color);
            display: flex; 
            flex-direction: column;
            width: 100%;
            height: 100%;
        }
        #articles .card-image-wrapper { height: 200px; overflow: hidden; background-color: var(--border-color); display: flex; justify-content: center; align-items: center; }
        #articles .card-image-wrapper img { width: 100%; height: 100%; object-fit: cover; transition: transform 0.5s; }
        #articles .post-card:hover .card-image-wrapper img { transform: scale(1.05); }
        #articles .card-content { padding: 20px; flex-grow: 1; display: flex; flex-direction: column; }
        #articles .card-category { font-size: 0.85em; color: var(--category-color); font-weight: 600; margin-bottom: 5px; display: block;}
        #articles .card-title { font-size: 1.4em; color: var(--text-color); margin: 0 0 10px 0; line-height: 1.4; font-weight: 700;}
        #articles .card-link { display: block; background-color: var(--primary-color); color: white; padding: 10px 15px; text-align: center; border-radius: 8px; text-decoration: none; font-weight: 600; margin-top: auto; transition: background-color 0.3s;}
        #articles .card-link:hover { background-color: #0056b3; color: white;}

        /* حالت های مختلف غلاف ها در اسلایدر */
        .slider-card-wrapper.is-active { transform: translateZ(0) scale(1); opacity: 1; z-index: 3;}
        /* تغییر: کارت های کناری بزرگتر و دورتر برای پر کردن فضا */
        .slider-card-wrapper.is-next { transform: translateX(-60%) translateZ(-250px) scale(0.9); opacity: 0.6; z-index: 2;}
        .slider-card-wrapper.is-prev { transform: translateX(60%) translateZ(-250px) scale(0.9); opacity: 0.6; z-index: 2;}
        
        /* حذف شد: دیگر نیازی به مخفی کردن کارت ها در موبایل نیست */
.success { 
            display: none;
        }
.success:target {
            display: flex;
            padding-top: 30px;
    
        }
        
        
        
    </style>
    <!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-PRWDJY7T1N"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'G-PRWDJY7T1N');
</script>
</head>
<body class="bg-slate-50 dark:bg-dark-navy transition-colors duration-500">

    <!-- Header and other sections -->
    <header class="sticky top-0 z-50 bg-white/80 dark:bg-dark-navy/80 backdrop-blur-sm shadow-md dark:shadow-black/20">
        <div class="container mx-auto px-6 py-3 flex justify-between items-center">
            <div>
                <a href="#home" class="cursor-pointer">
                    <h1 class="text-xl md:text-2xl font-bold text-slate-800 dark:text-slate-100">وکیل امیرحسین بای</h1>
                    <p class="text-xs text-blue-600 dark:text-gold-accent font-semibold">متعهد به دفاع از حقوق شما</p>
                </a>
            </div>
            <div class="flex items-center gap-4">
                <nav class="hidden md:flex items-center space-x-6 space-x-reverse" id="desktop-menu">
                    <a href="#home" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">خانه</a>
                    <a href="/blog" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">مقالات</a>
                    <a href="#services" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">خدمات</a>
                    <a href="#about" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">درباره</a>
                    <a href="#faq" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">سوالات متداول</a>
                    <a href="#contact" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">تماس</a>
                </nav>
                 <button id="theme-toggle" class="p-2 rounded-full text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors" aria-label="Toggle dark mode">
                    <svg id="theme-toggle-sun-icon" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                    <svg id="theme-toggle-moon-icon" xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gold-accent hidden" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z"></path></svg>
                </button>
                <div class="hidden md:block">
                    <div class="text-xs text-center text-slate-500 dark:text-slate-400 w-40">
                        <div id="date-display-desktop"></div>
                        <div id="time-display-desktop" class="font-mono tracking-wider" dir="ltr"></div>
                    </div>
                </div>
                <div class="md:hidden">
                    <button id="hamburger-button" class="text-slate-800 dark:text-slate-200 focus:outline-none" aria-label="Toggle menu">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path></svg>
                    </button>
                </div>
            </div>
        </div>
        <div id="mobile-menu" class="hidden md:hidden bg-white/95 dark:bg-dark-navy/95 backdrop-blur-sm">
            <nav class="flex flex-col items-center p-4 space-y-4">
                 <a href="#home" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold">خانه</a>
                 <a href="/blog" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold">مقالات</a>
                 <a href="#services" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold">خدمات</a>
                 <a href="#about" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold">درباره</a>
                 <a href="#faq" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold">سوالات متداول</a>
                 <a href="#contact" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold">تماس</a>
                 <div class="pt-4 border-t border-slate-200 dark:border-slate-700 w-full text-center">
                    <div class="text-xs text-slate-500 dark:text-slate-400">
                        <div id="date-display-mobile"></div>
                        <div id="time-display-mobile" class="font-mono tracking-wider mt-1" dir="ltr"></div>
                    </div>
                 </div>
            </nav>
        </div>
    </header>

    <main>
        <!-- Home, Services, About sections are unchanged -->
        <section id="home" class="bg-slate-100 dark:bg-slate-800 py-20 md:py-32">
            <div class="container mx-auto px-6">
                <div class="flex flex-col-reverse md:flex-row items-center gap-12">
                    <div class="md:w-1/2 text-center md:text-right">
                        <h2 class="text-3xl md:text-5xl font-extrabold text-slate-900 dark:text-white leading-tight">
                            <span class="text-blue-600 dark:text-gold-accent">وکیل امیرحسین بای</span>
                        </h2>
                        <p class="mt-4 text-lg text-slate-600 dark:text-slate-300">ارائه خدمات وکالت و مشاوره حقوقی تخصصی. وکیل پایه‌یک دادگستری، متعهد به احقاق حق شما.</p>
                        <div class="mt-8 flex flex-wrap gap-4 justify-center md:justify-start">
                            <a href="tel:09113797376" class="flex items-center justify-center gap-2 px-6 py-3 bg-blue-600 hover:bg-blue-700 dark:bg-gold-accent dark:hover:opacity-90 dark:text-dark-navy text-white font-bold rounded-lg shadow-lg transition-all transform hover:scale-105">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg>
                                <span>تماس تلفنی</span>
                            </a>
                            <a href="https://wa.me/989113797376" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center gap-2 px-6 py-3 bg-slate-700 hover:bg-slate-600 text-white font-bold rounded-lg shadow-lg transition-transform transform hover:scale-105">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.886-.001 2.269.655 4.505 1.905 6.344l-1.196 4.359 4.493-1.182z"></path></svg>
                                <span>مشاوره واتساپ</span>
                            </a>
                            <a href="https://instagram.com/vakilbay" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-purple-500 via-pink-500 to-red-500 hover:opacity-90 text-white font-bold rounded-lg shadow-lg transition-transform transform hover:scale-105">
                                <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.85s.012-3.584.07-4.85c.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.85-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948s.014 3.667.072 4.947c.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072s3.667-.014 4.947-.072c4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.947s-.014-3.667-.072-4.947c-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.689-.073-4.948-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.162 6.162 6.162 6.162-2.759 6.162-6.162-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.79 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44 1.441-.645 1.441-1.44-.645-1.44-1.441-1.44z"></path></svg>
                                <span>اینستاگرام</span>
                            </a>
                        </div>
                        <p class="mt-4 text-sm text-green-600 dark:text-green-400 font-semibold text-center md:text-right">مشاوره اولیه از طریق واتساپ همیشه رایگان است.</p>
                    </div>
                    <div class="md:w-1/2 flex justify-center">
                        <div class="w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden shadow-2xl border-4 border-blue-600 dark:border-gold-accent">
                            <img fetchpriority="high" alt="امیرحسین بای، وکیل پایه‌یک دادگستری" class="w-full h-full object-cover" src="https://bayvakil.ir/img/logo.webp">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section id="services" class="py-20 bg-white dark:bg-dark-navy">
            <div class="container mx-auto px-6">
                <div class="text-center mb-16">
                    <h2 class="text-4xl font-extrabold text-slate-900 dark:text-white">حوزه‌های فعالیت</h2>
                    <p class="mt-4 text-lg text-slate-600 dark:text-slate-300">ارائه خدمات حقوقی جامع و تخصصی در زمینه‌های گوناگون</p>
                    <div class="mt-4 w-24 h-1 bg-blue-600 dark:bg-gold-accent mx-auto rounded"></div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                    <div class="bg-slate-50 dark:bg-slate-800 p-8 rounded-xl shadow-lg hover:shadow-2xl dark:shadow-black/20 transition-all duration-300 transform hover:-translate-y-2 border-t-4 border-blue-600 dark:border-gold-accent">
                        <div class="mb-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-12 h-12 text-blue-600 dark:text-gold-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg></div>
                        <h3 class="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-3">دعاوی حقوقی</h3><p class="text-slate-600 dark:text-slate-300 leading-relaxed">تنظیم و بررسی قراردادها، مطالبه وجه، چک، سفته، الزام به تنظیم سند.</p>
                    </div>
                    <div class="bg-slate-50 dark:bg-slate-800 p-8 rounded-xl shadow-lg hover:shadow-2xl dark:shadow-black/20 transition-all duration-300 transform hover:-translate-y-2 border-t-4 border-blue-600 dark:border-gold-accent">
                        <div class="mb-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-12 h-12 text-blue-600 dark:text-gold-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H9v-2a4 4 0 014-4h0a4 4 0 014 4v2zm-6 0h12"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 11c-2.485 0-4.5 2.015-4.5 4.5V19h9v-3.5c0-2.485-2.015-4.5-4.5-4.5zM3 21h18M5 21a2 2 0 104 0M15 21a2 2 0 104 0"></path></svg></div>
                        <h3 class="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-3">دعاوی خانواده</h3><p class="text-slate-600 dark:text-slate-300 leading-relaxed">طلاق، مهریه، نفقه، حضانت، استرداد جهیزیه و سایر اختلافات خانوادگی.</p>
                    </div>
                    <div class="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-lg hover:shadow-2xl dark:shadow-black/20 transition-all duration-300 transform hover:-translate-y-2 border-t-4 border-slate-300 dark:border-slate-600">
                        <div class="mb-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-12 h-12 text-blue-600 dark:text-gold-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 11c.052.27.09.546.09.833 0 2.21-1.79 4-4 4-1.598 0-2.969-.933-3.578-2.25M21 12c0 4.418-4.03 8-9 8s-9-3.582-9-8 4.03-8 9-8c.345 0 .684.02.998.058M17 9l-3 3-3-3"></path></svg></div>
                        <h3 class="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-3">دعاوی کیفری</h3><p class="text-slate-600 dark:text-slate-300 leading-relaxed">کلاهبرداری، سرقت، خیانت در امانت، ضرب و جرح، توهین و افترا.</p>
                    </div>
                    <div class="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-lg hover:shadow-2xl dark:shadow-black/20 transition-all duration-300 transform hover:-translate-y-2 border-t-4 border-slate-300 dark:border-slate-600">
                        <div class="mb-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-12 h-12 text-blue-600 dark:text-gold-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg></div>
                        <h3 class="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-3">دعاوی ملکی</h3><p class="text-slate-600 dark:text-slate-300 leading-relaxed">تخلیه ید، خلع ید، تصرف عدوانی، تقسیم و افراز املاک مشاع.</p>
                    </div>
                    <div class="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-lg hover:shadow-2xl dark:shadow-black/20 transition-all duration-300 transform hover:-translate-y-2 border-t-4 border-slate-300 dark:border-slate-600">
                        <div class="mb-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-12 h-12 text-blue-600 dark:text-gold-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M10 21h7a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v11m0 5l4.879-4.879m0 0a3 3 0 104.243-4.242 3 3 0 00-4.243 4.242z"></path></svg></div>
                        <h3 class="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-3">دعاوی ثبتی و اداری</h3><p class="text-slate-600 dark:text-slate-300 leading-relaxed">امور مربوط به ثبت اسناد و املاک، دعاوی علیه ادارات و نهادهای دولتی.</p>
                    </div>
                    <div class="bg-white dark:bg-slate-800 p-8 rounded-xl shadow-lg hover:shadow-2xl dark:shadow-black/20 transition-all duration-300 transform hover:-translate-y-2 border-t-4 border-slate-300 dark:border-slate-600">
                        <div class="mb-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-12 h-12 text-blue-600 dark:text-gold-accent" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2"><path stroke-linecap="round" stroke-linejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"></path></svg></div>
                        <h3 class="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-3">مشاوره حقوقی</h3><p class="text-slate-600 dark:text-slate-300 leading-relaxed">ارائه مشاوره تخصصی حضوری و غیرحضوری در کلیه زمینه‌های حقوقی.</p>
                    </div>
                </div>
            </div>
        </section>
		<section id="about" class="bg-slate-100 dark:bg-slate-800 py-20">
             <div class="container mx-auto px-6 flex justify-center">
                <div class="lg:w-2/3 text-center">
                    <h2 class="text-4xl font-extrabold text-slate-900 dark:text-white">درباره من</h2>
                    <div class="mt-4 w-24 h-1 bg-blue-600 dark:bg-gold-accent mx-auto rounded"></div>
                    <p class="mt-6 text-lg text-slate-600 dark:text-slate-300 leading-loose">امیرحسین بای، وکیل پایه‌یک دادگستری و مشاور حقوقی، با اتکا به دانش حقوقی و تجربه در رسیدگی به پرونده‌های متعدد، همواره کوشیده‌ام تا بهترین مسیر را برای دستیابی به حقوق قانونی موکلینم فراهم آورم. رویکرد من مبتنی بر صداقت، شفافیت و پیگیری مستمر است و باور دارم که دفاع شایسته، حق مسلم هر فردی در برابر قانون است.</p>
                </div>
            </div>
        </section>
        <section class="py-20 bg-white dark:bg-dark-navy">
             <div class="container mx-auto px-6 text-center">
                <h2 class="text-4xl font-extrabold text-slate-900 dark:text-white">نظریه حقوقی روز</h2>
                <div class="mt-4 w-24 h-1 bg-blue-600 dark:bg-gold-accent mx-auto rounded"></div>
                <div class="max-w-3xl mx-auto min-h-[150px] flex items-center justify-center">
                    <p id="legal-theory" class="text-lg text-slate-600 dark:text-slate-300 leading-loose italic transition-opacity duration-500 ">"در حال بارگذاری نظریه حقوقی..."</p>
                </div>
            </div>
        </section>

        <!-- === بخش مقالات با ساختار نهایی === -->
        <section id="articles" class="py-20 bg-slate-100 dark:bg-slate-800 overflow-hidden">
            <div class="container mx-auto px-6">
                <div class="text-center mb-16">
                    <h2 class="text-4xl font-extrabold text-slate-900 dark:text-white">مطالب منتخب</h2>
                    <p class="mt-4 text-lg text-slate-600 dark:text-slate-300">جدیدترین و کاربردی‌ترین مقالات حقوقی</p>
                    <div class="mt-4 w-24 h-1 bg-blue-600 dark:bg-gold-accent mx-auto rounded"></div>
                </div>
                
                <div id="slider-wrapper">
                    <button id="prev-btn" class="absolute top-1/2 -translate-y-1/2 z-20 bg-white/80 dark:bg-slate-700/80 p-2 rounded-full shadow-md hover:bg-white dark:hover:bg-slate-600 transition-all right-0 md:-right-4" aria-label="Previous Slide">
                        <svg class="w-6 h-6 text-slate-800 dark:text-slate-100" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"></path></svg>
                    </button>
                    <button id="next-btn" class="absolute top-1/2 -translate-y-1/2 z-20 bg-white/80 dark:bg-slate-700/80 p-2 rounded-full shadow-md hover:bg-white dark:hover:bg-slate-600 transition-all left-0 md:-left-4" aria-label="Next Slide">
                        <svg class="w-6 h-6 text-slate-800 dark:text-slate-100" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path></svg>
                    </button>
                    
                    <div id="slider-container">
                        <!-- Skeleton Loader -->
                        <div class="post-card"><div class="card-image-wrapper bg-slate-300 dark:bg-slate-700 animate-pulse"></div><div class="card-content"><div class="h-4 bg-slate-300 dark:bg-slate-700 rounded w-3/4 mb-4 animate-pulse"></div><div class="h-3 bg-slate-300 dark:bg-slate-700 rounded w-full animate-pulse"></div></div></div>
                    </div>
                </div>
                <a href="/blog" class="block text-center mt-8 text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent font-semibold transition-colors duration-300">مشاهده ی تمام مقالات</a>
            </div>
        </section>

		<section id="faq" class="bg-white dark:bg-dark-navy py-20">
            <div class="container mx-auto px-6">
                <div class="text-center mb-16">
                    <h2 class="text-4xl font-extrabold text-slate-900 dark:text-white">سوالات متداول</h2>
                    <p class="mt-4 text-lg text-slate-600 dark:text-slate-300">پاسخ به برخی از پرسش‌های رایج حقوقی شما</p>
                    <div class="mt-4 w-24 h-1 bg-blue-600 dark:bg-gold-accent mx-auto rounded"></div>
                </div>
                <div class="max-w-3xl mx-auto bg-white dark:bg-slate-900 p-6 rounded-xl shadow-lg" id="faq-accordion">
                    <div class="border-b border-slate-200 dark:border-slate-700"><h3><button class="flex justify-between items-center w-full py-5 text-right font-semibold text-slate-800 dark:text-slate-100" aria-expanded="false"><span>چگونه می‌توانم مشاوره حقوقی دریافت کنم؟</span><svg class="w-4 h-4 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button></h3><div class="overflow-hidden transition-all duration-500 ease-in-out max-h-0"><div class="pb-5 pr-4"><p class="text-slate-600 dark:text-slate-300 leading-relaxed">شما می‌توانید از طریق تماس با شماره ۰۹۱۱۳۷۹۷۳۷۶ یا ارسال پیام در واتساپ، سوالات خود را مطرح نمایید. مشاوره اولیه از طریق واتساپ همیشه رایگان است. برای مشاوره حضوری، لطفاً در ساعات کاری تماس گرفته و وقت قبلی رزرو کنید.</p></div></div></div>
                    <div class="border-b border-slate-200 dark:border-slate-700"><h3><button class="flex justify-between items-center w-full py-5 text-right font-semibold text-slate-800 dark:text-slate-100" aria-expanded="false"><span>ساعت کاری دفتر شما به چه صورت است؟</span><svg class="w-4 h-4 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button></h3><div class="overflow-hidden transition-all duration-500 ease-in-out max-h-0"><div class="pb-5 pr-4"><p class="text-slate-600 dark:text-slate-300 leading-relaxed">دفتر وکالت از روز شنبه تا چهارشنبه، از ساعت ۱۷:۰۰ الی ۲۱:۰۰ برای مراجعه حضوری (با هماهنگی قبلی) باز است. در خارج از این ساعات، می‌توانید از طریق واتساپ پیام خود را ارسال فرمایید.</p></div></div></div>
                    <div class="border-b border-slate-200 dark:border-slate-700"><h3><button class="flex justify-between items-center w-full py-5 text-right font-semibold text-slate-800 dark:text-slate-100" aria-expanded="false"><span>آدرس دقیق دفتر وکالت کجاست؟</span><svg class="w-4 h-4 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button></h3><div class="overflow-hidden transition-all duration-500 ease-in-out max-h-0"><div class="pb-5 pr-4"><p class="text-slate-600 dark:text-slate-300 leading-relaxed">دفتر ما در استان گلستان، شهر گنبد کاووس، خیابان دارایی، مجتمع بردی‌پور، واحد ۴ واقع شده است. شما می‌توانید موقعیت دقیق دفتر را بر روی نقشه در بخش «تماس با ما» مشاهده کنید.</p></div></div></div>
                    <div class="border-b border-slate-200 dark:border-slate-700"><h3><button class="flex justify-between items-center w-full py-5 text-right font-semibold text-slate-800 dark:text-slate-100" aria-expanded="false"><span>آیا قبول پرونده به صورت تضمینی انجام می‌دهید؟</span><svg class="w-4 h-4 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button></h3><div class="overflow-hidden transition-all duration-500 ease-in-out max-h-0"><div class="pb-5 pr-4"><p class="text-slate-600 dark:text-slate-300 leading-relaxed">خیر. دادن هرگونه تضمین در خصوص نتیجه پرونده از سوی وکیل، خلاف مقررات و سوگند وکالت است. اما ما به شما اطمینان می‌دهیم که با استفاده از تمام دانش و تجربه خود، تمام تلاشمان را برای دستیابی به بهترین نتیجه ممکن و دفاع از حقوق شما به کار خواهیم گرفت.</p></div></div></div>
                    <div class="border-b-0 border-slate-200 dark:border-slate-700"><h3><button class="flex justify-between items-center w-full py-5 text-right font-semibold text-slate-800 dark:text-slate-100" aria-expanded="false"><span>هزینه‌های وکالت چگونه محاسبه می‌شود؟</span><svg class="w-4 h-4 transform transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg></button></h3><div class="overflow-hidden transition-all duration-500 ease-in-out max-h-0"><div class="pb-5 pr-4"><p class="text-slate-600 dark:text-slate-300 leading-relaxed">حق‌الوکاله بر اساس تعرفه مصوب کانون وکلای دادگستری و با توجه به پیچیدگی، نوع پرونده و میزان کار مورد نیاز تعیین می‌شود. در جلسه مشاوره اولیه، کلیه جزئیات مالی به صورت شفاف به شما توضیح داده خواهد شد.</p></div></div></div>
                </div>
            </div>
        </section>
        <section id="contact" class="bg-slate-50 dark:bg-slate-800 py-20">
            <div class="container mx-auto px-6">
                <div class="text-center mb-16"><h2 class="text-4xl font-extrabold text-slate-900 dark:text-white">ارتباط با ما</h2><p class="mt-4 text-lg text-slate-600 dark:text-slate-300">برای مشاوره حقوقی یا تعیین وقت حضوری، از راه‌های زیر با ما در تماس باشید.</p><div class="mt-4 w-24 h-1 bg-blue-600 dark:bg-gold-accent mx-auto rounded"></div></div>
                <div class="flex flex-col lg:flex-row gap-12">
                    <div class="lg:w-1/2 bg-white dark:bg-slate-900 p-8 rounded-xl shadow-lg">
                        <h3 class="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-6">اطلاعات تماس</h3>
                        <div class="space-y-6">
                            <div class="flex items-start gap-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 text-blue-600 dark:text-gold-accent mt-1 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg><div><h4 class="font-semibold text-slate-700 dark:text-slate-200">آدرس دفتر</h4><p class="text-slate-600 dark:text-slate-300">گنبد کاووس، خیابان دارایی، مجتمع بردی‌پور، واحد ۴</p></div></div>
                            <div class="flex items-start gap-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 text-blue-600 dark:text-gold-accent mt-1 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg><div><h4 class="font-semibold text-slate-700 dark:text-slate-200">ساعت کاری</h4><p class="text-slate-600 dark:text-slate-300">شنبه تا چهارشنبه از ساعت ۱۷:۰۰ الی ۲۱:۰۰</p><p class="text-sm text-green-600 dark:text-green-400 mt-1">مشاوره از طریق واتساپ همیشه رایگان است.</p></div></div>
                            <div class="flex items-start gap-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 text-blue-600 dark:text-gold-accent mt-1 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"></path></svg><div><h4 class="font-semibold text-slate-700 dark:text-slate-200">تلفن تماس</h4><a href="tel:09113797376" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent transition-colors" dir="ltr">0911 379 7376</a></div></div>
                            <div class="flex items-start gap-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 text-blue-600 dark:text-gold-accent mt-1 flex-shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946.003-6.556 5.338-11.891 11.893-11.891 3.181.001 6.167 1.24 8.413 3.488 2.245 2.248 3.481 5.236 3.48 8.414-.003 6.557-5.338 11.892-11.893 11.892-1.99-.001-3.951-.5-5.688-1.448l-6.305 1.654zm6.597-3.807c1.676.995 3.276 1.591 5.392 1.592 5.448 0 9.886-4.434 9.889-9.885.002-5.462-4.415-9.89-9.881-9.892-5.452 0-9.887 4.434-9.889 9.886-.001 2.269.655 4.505 1.905 6.344l-1.196 4.359 4.493-1.182z"></path></svg><div><h4 class="font-semibold text-slate-700 dark:text-slate-200">واتساپ</h4><a href="https://wa.me/989113797376" target="_blank" rel="noopener noreferrer" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent transition-colors" dir="ltr">0911 379 7376</a></div></div>
                            <div class="flex items-start gap-4"><svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 text-blue-600 dark:text-gold-accent mt-1 flex-shrink-0" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.85s.012-3.584.07-4.85c.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.85-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948s.014 3.667.072 4.947c.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072s3.667-.014 4.947-.072c4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.947s-.014-3.667-.072-4.947c-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.689-.073-4.948-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.162 6.162 6.162 6.162-2.759 6.162-6.162-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.79 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44 1.441-.645 1.441-1.44-.645-1.44-1.441-1.44z"></path></svg><div><h4 class="font-semibold text-slate-700 dark:text-slate-200">اینستاگرام</h4><a href="https://instagram.com/vakilbay" target="_blank" rel="noopener noreferrer" class="text-slate-600 dark:text-slate-300 hover:text-blue-600 dark:hover:text-gold-accent transition-colors" dir="ltr">@vakilbay</a></div></div>
                        </div>
                        <div class="mt-8"><iframe src="https://maps.google.com/maps?q=37.25331174361873,55.165675084415156&amp;t=&amp;z=17&amp;ie=UTF8&amp;iwloc=&amp;output=embed" width="100%" height="250" loading="lazy" referrerpolicy="no-referrer-when-downgrade" class="rounded-lg grayscale-[50%] hover:grayscale-0 dark:grayscale-[70%] dark:hover:grayscale-[50%] transition-all duration-300" title="موقعیت دفتر وکالت امیرحسین بای" style="border: 0px;"></iframe></div>
                    </div>
                    <div class="lg:w-1/2 bg-white dark:bg-slate-900 p-8 rounded-xl shadow-lg">
                        <h3 class="text-2xl font-bold text-slate-800 dark:text-slate-100 mb-6">ارسال پیام</h3>
                        <form action="/send_smtp_email.php" method="POST" class="space-y-6">
                            <div><label for="name" class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">نام کامل</label><input id="name" required="" class="w-full px-4 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md text-slate-800 dark:text-slate-200 focus:ring-blue-500 focus:border-blue-500 dark:focus:ring-gold-accent dark:focus:border-gold-accent transition" type="text" name="name"></div>
                            <div><label for="phone" class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">شماره تماس</label><input id="phone" required="" class="w-full px-4 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md text-slate-800 dark:text-slate-200 focus:ring-blue-500 focus:border-blue-500 dark:focus:ring-gold-accent dark:focus:border-gold-accent transition" type="tel" name="phone"></div>
                            <div><label for="message" class="block text-sm font-semibold text-slate-700 dark:text-slate-300 mb-2">پیام شما</label><textarea id="message" name="message" rows="5" required="" class="w-full px-4 py-2 bg-white dark:bg-slate-700 border border-slate-300 dark:border-slate-600 rounded-md text-slate-800 dark:text-slate-200 focus:ring-blue-500 focus:border-blue-500 dark:focus:ring-gold-accent dark:focus:border-gold-accent transition"></textarea></div>
                            <div><button type="submit" class="w-full px-8 py-3 bg-blue-600 hover:bg-blue-700 dark:bg-gold-accent dark:hover:opacity-90 dark:text-dark-navy text-white font-bold rounded-lg shadow-lg transition-transform transform hover:scale-105">ارسال</button>
                           <br><p id="success" class="success mt-4 text-sm text-green-600 dark:text-green-400 font-semibold text-center md:text-center items-center justify-center">
    پیام شما با موفقیت ارسال شد
   
<img id="done" src="/img/done.gif" alt="با موفقیت ارسال شد - وکیل بای" class="size-12 ml-2 flex"> </p>  </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>
    
    <footer class="bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-300">
        <div class="container mx-auto px-6 py-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8 text-center md:text-right">
                <div class="md:col-span-2"><h3 class="text-xl font-bold text-slate-900 dark:text-white mb-4">وکیل امیرحسین بای</h3><p class="text-sm dark:text-slate-400">متعهد به دفاع از حقوق شما با دانش و تجربه.</p><div class="flex justify-center md:justify-start mt-4"><a href="https://instagram.com/vakilbay" target="_blank" rel="noopener noreferrer" aria-label="اینستاگرام" class="text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-gold-accent"><svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.85s-.011 3.584-.069 4.85c-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07s-3.584-.012-4.85-.07c-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.85s.012-3.584.07-4.85c.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.85-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948s.014 3.667.072 4.947c.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072s3.667-.014 4.947-.072c4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.947s-.014-3.667-.072-4.947c-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.689-.073-4.948-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.162 6.162 6.162 6.162-2.759 6.162-6.162-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4s1.791-4 4-4 4 1.79 4 4-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44 1.441-.645 1.441-1.44-.645-1.44-1.441-1.44z"></path></svg></a></div></div>
                <div>
<h3 class="text-xl font-bold text-slate-900 dark:text-white mb-4">لینک‌های مفید</h3>
<ul class="space-y-2 text-sm">
<li><a href="/ghavanin" class="hover:text-blue-600 dark:hover:text-gold-accent transition-colors">سامانه قوانین</a></li>
<li><a href="/mavaed" class="hover:text-blue-600 dark:hover:text-gold-accent transition-colors">محاسبه ی مواعد</a></li>
<li><a href="/hesab" class="hover:text-blue-600 dark:hover:text-gold-accent transition-colors">محاسبه ی حق الوکاله</a></li>
<li><a href="/blog" class="hover:text-blue-600 dark:hover:text-gold-accent transition-colors">وبلاگ حقوقی</a></li>
<li><a href="https://hub.23055.ir/lawyer-profile?public_lawyer_id=81381" class="hover:text-blue-600 dark:hover:text-gold-accent transition-colors">استعلام وکیل</a></li>
</ul>
</div>                <div><h3 class="text-xl font-bold text-slate-900 dark:text-white mb-4">تماس با ما</h3><p class="text-sm dark:text-slate-400">آدرس: گنبد کاووس، خ دارایی، مجتمع بردی‌پور، واحد ۴</p>

<div class="text-sm mt-2 flex items-center justify-center md:justify-start gap-2">
    <span>تلفن:</span>
    <a href="tel:09113797376" dir="ltr" class="hover:text-blue-600 dark:hover:text-gold-accent font-sans">0911-379-7376</a>
</div>

</div>
            </div>
            <div class="mt-8 pt-8 border-t border-slate-200 dark:border-slate-700 flex flex-col sm:flex-row justify-between items-center"><p class="text-sm text-slate-500 dark:text-slate-400">© 2025 وکیل امیرحسین بای – کلیه حقوق محفوظ است.</p></div>
        </div>
    </footer>

 <script>
document.addEventListener('DOMContentLoaded', function () {
    
    // ==========================================
    // 1. تنظیمات دکمه دارک مود (Dark Mode Toggle)
    // ==========================================
    const themeToggleBtn = document.getElementById('theme-toggle');
    const sunIcon = document.getElementById('theme-toggle-sun-icon');
    const moonIcon = document.getElementById('theme-toggle-moon-icon');

    // بررسی وضعیت فعلی و تنظیم آیکون مناسب
    if (document.documentElement.classList.contains('dark')) {
        sunIcon.classList.add('hidden');
        moonIcon.classList.remove('hidden');
    } else {
        sunIcon.classList.remove('hidden');
        moonIcon.classList.add('hidden');
    }

    // رویداد کلیک روی دکمه
    themeToggleBtn.addEventListener('click', () => {
        document.documentElement.classList.toggle('dark');
        
        if (document.documentElement.classList.contains('dark')) {
            localStorage.setItem('color-theme', 'dark');
            sunIcon.classList.add('hidden');
            moonIcon.classList.remove('hidden');
        } else {
            localStorage.setItem('color-theme', 'light');
            sunIcon.classList.remove('hidden');
            moonIcon.classList.add('hidden');
        }
    });

    // ==========================================
    // 2. نمایش تاریخ و ساعت (اصلاح شده: فارسی و زنده)
    // ==========================================
    const dateElements = { desktop: document.getElementById('date-display-desktop'), mobile: document.getElementById('date-display-mobile') };
    const timeElements = { desktop: document.getElementById('time-display-desktop'), mobile: document.getElementById('time-display-mobile') };
    
    function updateDateTime() { 
        const now = new Date(); 
        
        // 1. ساخت تاریخ سفارشی: پنجشنبه ،۲۹ آبان ۱۴۰۴
        const weekday = now.toLocaleDateString('fa-IR', { weekday: 'long' });
        const day = now.toLocaleDateString('fa-IR', { day: 'numeric' });
        const month = now.toLocaleDateString('fa-IR', { month: 'long' });
        const year = now.toLocaleDateString('fa-IR', { year: 'numeric' });
        
        // چسباندن تکه‌ها به ترتیب دلخواه شما
        const formattedDate = `${weekday}، ${day} ${month} ${year}`;
        
        // 2. ساعت زنده با اعداد فارسی (همراه با ثانیه)
        const formattedTime = now.toLocaleTimeString('fa-IR', { 
            hour: '2-digit', 
            minute: '2-digit', 
            second: '2-digit' // نمایش ثانیه برای زنده بودن
        }); 
        
        // نمایش در سایت
        if(dateElements.desktop) dateElements.desktop.textContent = formattedDate; 
        if(dateElements.mobile) dateElements.mobile.textContent = formattedDate; 
        
        if(timeElements.desktop) {
            timeElements.desktop.textContent = formattedTime;
            // حذف استایل‌های انگلیسی (چون اعداد فارسی با فونت وزیر زیباترند)
            timeElements.desktop.classList.remove('font-mono', 'tracking-wider');
            timeElements.desktop.removeAttribute('dir'); // حذف جهت چپ‌چین
        }
        if(timeElements.mobile) {
            timeElements.mobile.textContent = formattedTime;
            timeElements.mobile.classList.remove('font-mono', 'tracking-wider');
            timeElements.mobile.removeAttribute('dir');
        }
    }
    
    updateDateTime();
    // تغییر مهم: آپدیت هر ۱۰۰۰ میلی‌ثانیه (۱ ثانیه) برای نمایش ساعت زنده
    setInterval(updateDateTime, 1000);
    
    // ==========================================
    // 3. منوی موبایل (Mobile Menu)
    // ==========================================
    const hamburgerBtn = document.getElementById('hamburger-button');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if(hamburgerBtn && mobileMenu) {
        hamburgerBtn.addEventListener('click', () => mobileMenu.classList.toggle('hidden'));
        mobileMenu.querySelectorAll('a').forEach(link => link.addEventListener('click', () => mobileMenu.classList.add('hidden')));
    }

    // ==========================================
    // 4. اسلایدر مقالات (Slider Logic)
    // ==========================================
    const sliderContainer = document.getElementById('slider-container');
    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');

    function setupSlider(wrappers) {
        if (wrappers.length < 2) {
            if(wrappers.length > 0) wrappers[0].classList.add('is-active');
            if(prevBtn) prevBtn.style.display = 'none';
            if(nextBtn) nextBtn.style.display = 'none';
            return;
        } else {
            if(prevBtn) prevBtn.style.display = 'block';
            if(nextBtn) nextBtn.style.display = 'block';
        }

        let currentIndex = 0;

        function updateSliderClasses() {
            wrappers.forEach((wrapper) => {
                wrapper.classList.remove('is-active', 'is-next', 'is-prev');
            });
            
            const prevIndex = (currentIndex - 1 + wrappers.length) % wrappers.length;
            const nextIndex = (currentIndex + 1) % wrappers.length;

            if (wrappers[prevIndex]) wrappers[prevIndex].classList.add('is-prev');
            if (wrappers[nextIndex]) wrappers[nextIndex].classList.add('is-next');
            if (wrappers[currentIndex]) wrappers[currentIndex].classList.add('is-active');
        }

        if(nextBtn) nextBtn.addEventListener('click', () => {
            currentIndex = (currentIndex + 1) % wrappers.length;
            updateSliderClasses();
        });

        if(prevBtn) prevBtn.addEventListener('click', () => {
            currentIndex = (currentIndex - 1 + wrappers.length) % wrappers.length;
            updateSliderClasses();
        });

        updateSliderClasses();
    }

    async function loadRandomPosts() {
        if(!sliderContainer) return;
        
        const postCount = window.innerWidth < 768 ? 3 : 6;
        // فرض بر اینکه فایل php شما در پوشه blog است
        const blogURL = `/blog/index.php?random=${postCount}`; 

        try {
            const response = await fetch(blogURL);
            // اگر خطای شبکه نبود اما فایل پیدا نشد یا ارور داد
            if (!response.ok) {
                 console.warn('Blog API not available');
                 return; 
            }
            
            const html = await response.text();
            
            if (html.trim()) {
                const tempDiv = document.createElement('div');
                tempDiv.innerHTML = html;
                const loadedCards = tempDiv.querySelectorAll('.post-card');
                
                sliderContainer.innerHTML = '';
                
                const wrappers = [];
                loadedCards.forEach(card => {
                    const wrapper = document.createElement('div');
                    wrapper.className = 'slider-card-wrapper';
                    wrapper.appendChild(card);
                    sliderContainer.appendChild(wrapper);
                    wrappers.push(wrapper);
                });
                
                setupSlider(wrappers);
            }
        } catch (error) {
            console.error('Error fetching posts:', error);
            sliderContainer.innerHTML = `<p class="text-center text-slate-500 w-full text-sm">مقالات فعلاً در دسترس نیستند.</p>`;
        }
    }
    
    loadRandomPosts();

    // ==========================================
    // 5. سوالات متداول (FAQ Accordion)
    // ==========================================
    const faqAccordion = document.getElementById('faq-accordion');
    if(faqAccordion) { 
        const buttons = faqAccordion.querySelectorAll('h3 > button'); 
        buttons.forEach(button => { 
            button.addEventListener('click', () => { 
                const content = button.parentElement.nextElementSibling; 
                const isExpanded = button.getAttribute('aria-expanded') === 'true'; 
                
                buttons.forEach(btn => { 
                    if (btn !== button) { 
                        btn.setAttribute('aria-expanded', 'false'); 
                        btn.parentElement.nextElementSibling.classList.add('max-h-0'); 
                        btn.parentElement.nextElementSibling.classList.remove('max-h-screen'); 
                        btn.querySelector('svg').classList.remove('rotate-180'); 
                    } 
                }); 
                
                if (!isExpanded) { 
                    button.setAttribute('aria-expanded', 'true'); 
                    content.classList.remove('max-h-0'); 
                    content.classList.add('max-h-screen'); 
                    button.querySelector('svg').classList.add('rotate-180'); 
                } else { 
                    button.setAttribute('aria-expanded', 'false'); 
                    content.classList.add('max-h-0'); 
                    content.classList.remove('max-h-screen'); 
                    button.querySelector('svg').classList.remove('rotate-180'); 
                } 
            }); 
        }); 
        if(buttons.length) buttons[0].click(); 
    }

    // ==========================================
    // 6. نظریه حقوقی (Legal Theory Fetch)
    // ==========================================
    const legalTheoryElement = document.getElementById('legal-theory');
    if(legalTheoryElement) {
        fetch('nazarie.xml')
            .then(response => response.ok ? response.text() : Promise.reject('File not found'))
            .then(str => (new window.DOMParser()).parseFromString(str, "text/xml"))
            .then(data => { 
                const theories = data.querySelectorAll("theory"); 
                if (theories.length === 0) throw new Error('No theories found.'); 
                const randomTheory = theories[Math.floor(Math.random() * theories.length)].textContent; 
                legalTheoryElement.style.opacity = 0; 
                setTimeout(() => { 
                    legalTheoryElement.textContent = `"${randomTheory.trim()}"`; 
                    legalTheoryElement.style.opacity = 1; 
                }, 300); 
            })
            .catch(error => { 
                console.error("Error loading theory:", error); 
                legalTheoryElement.textContent = '"عدالت، برترین فضیلت است."'; 
            });
    }

    // ==========================================
    // 7. فرم تماس پیشرفته (AJAX Contact Form) 🚀
    // ==========================================
    const contactForm = document.querySelector('form[action="/send_smtp_email.php"]');
    
    if (contactForm) {
        const submitBtn = contactForm.querySelector('button[type="submit"]');
        const successMsg = document.getElementById('success');
        const gifImage = document.getElementById('done');

        contactForm.addEventListener('submit', async function(e) {
            e.preventDefault(); // جلوگیری از رفرش صفحه

            // تغییر دکمه به حالت لودینگ
            const originalBtnText = submitBtn.innerText;
            submitBtn.innerText = "در حال ارسال...";
            submitBtn.disabled = true;
            submitBtn.classList.add('opacity-75', 'cursor-not-allowed');

            const formData = new FormData(contactForm);

            try {
                const response = await fetch(contactForm.action, {
                    method: 'POST',
                    body: formData
                });

                // فرض بر این است که فایل php شما در صورت موفقیت کدی برمی‌گرداند
                // اگر فایل php ریدایرکت می‌کند، ممکن است response.ok کافی باشد
                if (response.ok) {
                    contactForm.reset(); // خالی کردن فیلدها
                    
                    // نمایش پیام سبز
                    successMsg.style.display = 'flex';
                    successMsg.scrollIntoView({ behavior: 'smooth', block: 'center' });

                    // پخش گیف و تبدیل به عکس ثابت
                    if(gifImage) {
                        gifImage.src = "/img/done.gif?t=" + new Date().getTime(); 
                        setTimeout(function() {
                            gifImage.src = "/img/done.png";
                        }, 1500); // بعد از 1.5 ثانیه ثابت شود
                    }
                } else {
                    alert("خطا در ارسال پیام. لطفا اتصال اینترنت را بررسی کنید.");
                }
            } catch (error) {
                console.error('Error:', error);
                alert("مشکلی در ارتباط با سرور پیش آمد.");
            } finally {
                // برگرداندن دکمه به حالت اول
                submitBtn.innerText = originalBtnText;
                submitBtn.disabled = false;
                submitBtn.classList.remove('opacity-75', 'cursor-not-allowed');
            }
        });
    }
});
</script>
    
    
</body>
</html>