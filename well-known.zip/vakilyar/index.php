<?php
session_start();
define('SECURE_ACCESS', true);
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");

// PWA Manifest
if (isset($_GET['manifest'])) {
    header('Content-Type: application/json');
    echo json_encode([
        "name" => "وکیل‌یار",
        "short_name" => "وکیل‌یار", 
        "start_url" => ".",
        "display" => "standalone",
        "background_color" => "#f8fafc",
        "theme_color" => "#2563eb",
        "icons" => [[
            "src" => "https://img.icons8.com/fluency/192/law.png",
            "sizes" => "192x192",
            "type" => "image/png"
        ]]
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>وکیل‌یار | سیستم مدیریت دفتر وکالت</title>
    <link rel="manifest" href="?manifest=1">
    <meta name="theme-color" content="#2563eb">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            200: '#bfdbfe',
                            300: '#93c5fd',
                            400: '#60a5fa',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            800: '#1e40af',
                            900: '#1e3a8a',
                        },
                        gold: {
                            400: '#facc15',
                            500: '#eab308',
                            600: '#ca8a04',
                        },
                        dark: {
                            800: '#1e293b',
                            900: '#0f172a',
                            950: '#020617',
                        }
                    },
                    fontFamily: {
                        sans: ['Vazirmatn', 'system-ui', 'sans-serif'],
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.3s ease-out',
                        'slide-up': 'slideUp 0.3s ease-out',
                        'scale-in': 'scaleIn 0.2s ease-out',
                    }
                }
            }
        }
    </script>
    
    <!-- Fonts & Icons -->
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes scaleIn {
            from { opacity: 0; transform: scale(0.95); }
            to { opacity: 1; transform: scale(1); }
        }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 3px; }
        .dark ::-webkit-scrollbar-thumb { background: #475569; }
        
        /* Glass Effect */
        .glass {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .dark .glass {
            background: rgba(15, 23, 42, 0.8);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        /* Input Focus */
       .input-primary {
    width: 100%;
    padding: 0.75rem 1rem;
    border-radius: 0.75rem;
    border: 1px solid #e5e7eb;
    background: white;
    outline: none;
    transition: all 0.2s ease;
}
.input-primary:focus {
    border-color: #3b82f6;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}
.dark .input-primary {
    background: #1e293b;
    border-color: #1e293b;
    color: white;
}
        
        /* Cards */
        .card {
    background: white;
    border-radius: 1rem;
    border: 1px solid #f1f5f9;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
    transition: all 0.3s ease;
}
.card:hover {
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}
.dark .card {
    background: #1e293b;
    border-color: #1e293b;
}
        
        /* Buttons */
      .btn-primary {
    padding: 0.75rem 1.5rem;
    background: #2563eb;
    color: white;
    border-radius: 0.75rem;
    font-weight: 500;
    transition: all 0.2s ease;
    box-shadow: 0 4px 14px rgba(37, 99, 235, 0.25);
}
.btn-primary:hover {
    background: #1d4ed8;
}
.btn-primary:active {
    transform: scale(0.95);
}
.dark .btn-primary {
    background: #eab308;
    color: #0f172a;
    box-shadow: 0 4px 14px rgba(234, 179, 8, 0.25);
}
.dark .btn-primary:hover {
    background: #facc15;
}
        
        /* Sidebar */
       .sidebar-item {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 0.75rem 1rem;
    border-radius: 0.75rem;
    color: #4b5563;
    cursor: pointer;
    transition: all 0.2s ease;
}
.sidebar-item:hover {
    background: #f3f4f6;
}
.sidebar-item.active {
    background: #eff6ff;
    color: #2563eb;
    font-weight: 500;
}
.dark .sidebar-item {
    color: #9ca3af;
}
.dark .sidebar-item:hover {
    background: #1e293b;
}
.dark .sidebar-item.active {
    background: rgba(234, 179, 8, 0.1);
    color: #eab308;
}
        
        /* Tags */
        .tag {
    display: inline-flex;
    align-items: center;
    padding: 0.25rem 0.625rem;
    border-radius: 0.5rem;
    font-size: 0.75rem;
    font-weight: 500;
    background: #f3f4f6;
    color: #4b5563;
}
.dark .tag {
    background: #1e293b;
    color: #9ca3af;
}
        
       /* Status Badges */
.badge-success { background: #d1fae5; color: #047857; }
.badge-warning { background: #fef3c7; color: #b45309; }
.badge-danger { background: #fee2e2; color: #b91c1c; }
.badge-info { background: #dbeafe; color: #1d4ed8; }
.dark .badge-success { background: rgba(16, 185, 129, 0.2); color: #34d399; }
.dark .badge-warning { background: rgba(245, 158, 11, 0.2); color: #fbbf24; }
.dark .badge-danger { background: rgba(239, 68, 68, 0.2); color: #f87171; }
.dark .badge-info { background: rgba(59, 130, 246, 0.2); color: #60a5fa; }
        
       /* Modal */
.modal-overlay {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.5);
    backdrop-filter: blur(4px);
    z-index: 50;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding-top: 2.5rem;
    padding-bottom: 2.5rem;
    overflow-y: auto;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}
.modal-overlay.active {
    opacity: 1;
    visibility: visible;
}
.modal-content {
    background: white;
    border-radius: 1rem;
    box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
    width: 100%;
    max-width: 32rem;
    margin-left: 1rem;
    margin-right: 1rem;
    transform: scale(0.95);
    transition: all 0.3s ease;
}
.modal-overlay.active .modal-content {
    transform: scale(1);
}
.dark .modal-content {
    background: #0f172a;
    border: 1px solid #1e293b;
}
        
        /* Table */
        .table-row:hover {
    background: #f9fafb;
    transition: background 0.15s ease;
}
.dark .table-row:hover {
    background: #1e293b;
}
        
        /* Hide scrollbar but allow scroll */
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        
        .line-clamp-2 {
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-950 text-gray-800 dark:text-gray-200 min-h-screen">

<?php if (!isset($_SESSION['logged_in'])): ?>
<!-- ═══════════════════ صفحه ورود ═══════════════════ -->
<div class="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary-600 to-primary-900 dark:from-dark-900 dark:to-dark-950">
    <div class="w-full max-w-md animate-fade-in">
        <!-- Logo -->
        <div class="text-center mb-8">
            <div class="w-20 h-20 bg-white dark:bg-gold-500 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-2xl">
                <i class="fas fa-scale-balanced text-3xl text-primary-600 dark:text-dark-900"></i>
            </div>
            <h1 class="text-2xl font-bold text-white">وکیل‌یار</h1>
            <p class="text-primary-200 dark:text-gray-400 text-sm mt-1">سیستم هوشمند مدیریت دفتر وکالت</p>
        </div>
        
        <!-- Login Form -->
        <div class="card p-8">
            <form id="loginForm" onsubmit="handleLogin(event)">
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">
                        <i class="fas fa-lock ml-1"></i> رمز عبور
                    </label>
                    <input 
                        type="password" 
                        id="loginPassword"
                        class="input-primary text-center text-lg tracking-widest"
                        placeholder="••••••••"
                        autocomplete="current-password"
                        required
                    >
                </div>
                <button type="submit" class="btn-primary w-full">
                    <i class="fas fa-sign-in-alt ml-2"></i>
                    ورود به سیستم
                </button>
            </form>
        </div>
        
        <p class="text-center text-primary-200 dark:text-gray-500 text-xs mt-6">
            نسخه ۲.۰ | طراحی شده با ❤️
        </p>
    </div>
</div>

<script>
async function handleLogin(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin ml-2"></i> در حال ورود...';
    
    try {
        const fd = new FormData();
        fd.append('action', 'login');
        fd.append('password', document.getElementById('loginPassword').value);
        
        const res = await fetch('api.php', { method: 'POST', body: fd });
        const data = await res.json();
        
        if (data.success) {
            location.reload();
        } else {
            Swal.fire({
                icon: 'error',
                title: 'خطا',
                text: data.message,
                confirmButtonText: 'باشه'
            });
        }
    } catch (err) {
        Swal.fire({
            icon: 'error',
            title: 'خطای سرور',
            text: 'لطفاً دوباره تلاش کنید',
            confirmButtonText: 'باشه'
        });
    }
    
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-sign-in-alt ml-2"></i> ورود به سیستم';
}

// Check dark mode
if (localStorage.getItem('theme') === 'dark') {
    document.documentElement.classList.add('dark');
}
</script>

<?php else: ?>
<!-- ═══════════════════ اپلیکیشن اصلی ═══════════════════ -->
<div class="flex h-screen overflow-hidden">
    
    <!-- Sidebar Overlay (Mobile) -->
    <div id="sidebarOverlay" class="fixed inset-0 bg-black/50 z-40 lg:hidden hidden" onclick="toggleSidebar()"></div>
    
    <!-- ═══════ Sidebar ═══════ -->
    <aside id="sidebar" class="fixed lg:static inset-y-0 right-0 w-72 bg-white dark:bg-dark-900 border-l border-gray-200 dark:border-dark-800 z-50 transform translate-x-full lg:translate-x-0 transition-transform duration-300 flex flex-col">
        
        <!-- Logo -->
        <div class="h-16 flex items-center gap-3 px-6 border-b border-gray-100 dark:border-dark-800">
            <div class="w-10 h-10 bg-primary-600 dark:bg-gold-500 rounded-xl flex items-center justify-center">
                <i class="fas fa-scale-balanced text-white dark:text-dark-900"></i>
            </div>
            <div>
                <h1 class="font-bold text-gray-800 dark:text-white">وکیل‌یار</h1>
                <span class="text-[10px] text-gray-400 uppercase tracking-wider">Pro Edition</span>
            </div>
        </div>
        
        <!-- Navigation -->
        <nav class="flex-1 p-4 space-y-1 overflow-y-auto">
            <div class="sidebar-item active" onclick="setView('dashboard', this)">
                <i class="fas fa-home w-5"></i>
                <span>داشبورد</span>
            </div>
            <div class="sidebar-item" onclick="setView('cases', this)">
                <i class="fas fa-folder-open w-5"></i>
                <span>پرونده‌ها</span>
            </div>
            <div class="sidebar-item" onclick="setView('schedule', this)">
                <i class="fas fa-calendar-alt w-5"></i>
                <span>تقویم کاری</span>
            </div>
            <div class="sidebar-item" onclick="setView('finance', this)">
                <i class="fas fa-wallet w-5"></i>
                <span>امور مالی</span>
            </div>
            <div class="sidebar-item" onclick="setView('library', this)">
                <i class="fas fa-book w-5"></i>
                <span>بانک لوایح</span>
            </div>
            
            <div class="pt-4 mt-4 border-t border-gray-100 dark:border-dark-800">
                <p class="text-xs text-gray-400 px-4 mb-2">تنظیمات</p>
                <div class="sidebar-item" onclick="toggleTheme()">
                    <i class="fas fa-moon w-5"></i>
                    <span>حالت شب</span>
                </div>
                <div class="sidebar-item" onclick="testGoogleSheetConnection()">
    <i class="fas fa-cloud w-5"></i>
    <span>تست اتصال شیت</span>
</div>
                <div class="sidebar-item text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20" onclick="logout()">
                    <i class="fas fa-sign-out-alt w-5"></i>
                    <span>خروج</span>
                </div>
            </div>
        </nav>
        
        <!-- User Info -->
        <div class="p-4 border-t border-gray-100 dark:border-dark-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-primary-100 dark:bg-gold-500/20 rounded-full flex items-center justify-center">
                   <img src="../img/logo.webp" style="border-radius: 100%;">
                </div>
                <div>
<p class="text-sm font-medium text-gray-700 dark:text-gray-300">امیرحسین بای</p>                    <p class="text-xs text-gray-400">آنلاین</p>
                </div>
            </div>
        </div>
    </aside>
    
    <!-- ═══════ Main Content ═══════ -->
    <main class="flex-1 flex flex-col overflow-hidden">
        
        <!-- Header -->
        <header class="h-16 bg-white dark:bg-dark-900 border-b border-gray-200 dark:border-dark-800 flex items-center justify-between px-4 lg:px-6 shrink-0">
            <div class="flex items-center gap-4">
                <button onclick="toggleSidebar()" class="lg:hidden p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                    <i class="fas fa-bars text-gray-600 dark:text-gray-400"></i>
                </button>
                <h2 id="pageTitle" class="text-lg font-bold text-gray-800 dark:text-white">داشبورد</h2>
            </div>
            
            <div class="flex items-center gap-3">
                <!-- Sync Status -->
                <div id="syncStatus" class="hidden items-center gap-2 text-xs text-gray-400">
                    <i class="fas fa-cloud text-emerald-500"></i>
                    <span>سینک شده</span>
                </div>
                
                <!-- Date -->
                <div class="hidden md:flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                    <i class="fas fa-calendar-day"></i>
                    <span id="todayDate"></span>
                </div>
                
                <!-- Quick Add -->
                <button onclick="openQuickAdd()" class="p-2 bg-primary-600 dark:bg-gold-500 text-white dark:text-dark-900 rounded-lg hover:opacity-90 transition">
                    <i class="fas fa-plus"></i>
                </button>
            </div>
        </header>
                <!-- ═══════ Content Area ═══════ -->
        <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
            
            <!-- ══════════════════════════════════════════════════════════════ -->
            <!-- داشبورد -->
            <!-- ══════════════════════════════════════════════════════════════ -->
            <div id="view-dashboard" class="page-view animate-fade-in">
                
                <!-- Stats Cards -->
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <!-- پرونده‌های فعال -->
                    <div class="card p-5">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">پرونده‌های فعال</p>
                                <p id="stat-cases" class="text-3xl font-black text-gray-800 dark:text-white">0</p>
                            </div>
                            <div class="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-folder-open text-primary-600 dark:text-primary-400 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-3 flex items-center gap-1 text-xs">
                            <span class="text-emerald-600"><i class="fas fa-arrow-up"></i> 12%</span>
                            <span class="text-gray-400">نسبت به ماه قبل</span>
                        </div>
                    </div>
                    
                    <!-- جلسات امروز -->
                    <div class="card p-5">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">جلسات امروز</p>
                                <p id="stat-today" class="text-3xl font-black text-gray-800 dark:text-white">0</p>
                            </div>
                            <div class="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-calendar-check text-amber-600 dark:text-amber-400 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-3 flex items-center gap-1 text-xs">
                            <span class="text-gray-400">برنامه روز جاری</span>
                        </div>
                    </div>
                    
                    <!-- درآمد ماه -->
                    <div class="card p-5">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">درآمد ماه</p>
                                <p id="stat-income" class="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono" dir="ltr">0</p>
                            </div>
                            <div class="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-arrow-trend-up text-emerald-600 dark:text-emerald-400 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-3 flex items-center gap-1 text-xs text-gray-400">
                            <span>تومان</span>
                        </div>
                    </div>
                    
                    <!-- تراز مالی -->
                    <div class="card p-5">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">تراز مالی</p>
                                <p id="stat-balance" class="text-2xl font-black text-gray-800 dark:text-white font-mono" dir="ltr">0</p>
                            </div>
                            <div class="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-coins text-purple-600 dark:text-purple-400 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-3 flex items-center gap-1 text-xs text-gray-400">
                            <span>مجموع دریافت - هزینه</span>
                        </div>
                    </div>
                </div>
                
                <!-- Charts Row -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <!-- نمودار وضعیت پرونده‌ها -->
                    <div class="card p-6">
                        <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                            <i class="fas fa-chart-pie text-primary-500"></i>
                            وضعیت پرونده‌ها
                        </h3>
                        <div class="h-64 flex items-center justify-center">
                            <canvas id="casesChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- نمودار مالی -->
                    <div class="card p-6">
                        <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                            <i class="fas fa-chart-line text-emerald-500"></i>
                            روند مالی
                        </h3>
                        <div class="h-64">
                            <canvas id="financeChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- Lists Row -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- جلسات آینده -->
                    <div class="card p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-gray-800 dark:text-white flex items-center gap-2">
                                <i class="fas fa-clock text-amber-500"></i>
                                جلسات آینده
                            </h3>
                            <button onclick="setView('schedule')" class="text-xs text-primary-600 dark:text-gold-500 hover:underline">
                                مشاهده همه
                            </button>
                        </div>
                        <div id="upcomingList" class="space-y-3">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                    
                    <!-- پرونده‌های اخیر -->
                    <div class="card p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-gray-800 dark:text-white flex items-center gap-2">
                                <i class="fas fa-folder text-primary-500"></i>
                                پرونده‌های اخیر
                            </h3>
                            <button onclick="setView('cases')" class="text-xs text-primary-600 dark:text-gold-500 hover:underline">
                                مشاهده همه
                            </button>
                        </div>
                        <div id="recentCasesList" class="space-y-3">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                    
                    <!-- تراکنش‌های اخیر -->
                    <div class="card p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-gray-800 dark:text-white flex items-center gap-2">
                                <i class="fas fa-receipt text-emerald-500"></i>
                                تراکنش‌های اخیر
                            </h3>
                            <button onclick="setView('finance')" class="text-xs text-primary-600 dark:text-gold-500 hover:underline">
                                مشاهده همه
                            </button>
                        </div>
                        <div id="recentFinanceList" class="space-y-3">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                </div>
            </div>
                        <!-- ══════════════════════════════════════════════════════════════ -->
            <!-- پرونده‌ها -->
            <!-- ══════════════════════════════════════════════════════════════ -->
            <div id="view-cases" class="page-view hidden animate-fade-in h-full flex flex-col">
                
                <!-- Header -->
                <div class="flex flex-col md:flex-row gap-4 mb-6">
                    <div class="relative flex-1">
                        <i class="fas fa-search absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input 
                            type="text" 
                            id="searchCases" 
                            placeholder="جستجو در پرونده‌ها..."
                            class="input-primary pr-12"
                            onkeyup="renderCases()"
                        >
                    </div>
                    <div class="flex gap-2">
                        <select id="filterCaseStatus" onchange="renderCases()" class="input-primary w-auto">
                            <option value="">همه وضعیت‌ها</option>
                            <option value="جاری">جاری</option>
                            <option value="مختومه">مختومه</option>
                        </select>
                        <select id="filterCaseType" onchange="renderCases()" class="input-primary w-auto">
                            <option value="">همه انواع</option>
                            <option value="حقوقی">حقوقی</option>
                            <option value="کیفری">کیفری</option>
                            <option value="خانواده">خانواده</option>
                            <option value="ملکی">ملکی</option>
                            <option value="ثبتی">ثبتی</option>
                        </select>
                        <button onclick="openCaseModal()" class="btn-primary whitespace-nowrap">
                            <i class="fas fa-plus ml-2"></i>
                            پرونده جدید
                        </button>
                    </div>
                </div>
                
                <!-- Cases Grid -->
                <div id="casesGrid" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 overflow-y-auto pb-4">
                    <!-- Dynamic content -->
                </div>
            </div>
                        <!-- ══════════════════════════════════════════════════════════════ -->
            <!-- تقویم کاری -->
            <!-- ══════════════════════════════════════════════════════════════ -->
            <div id="view-schedule" class="page-view hidden animate-fade-in h-full flex flex-col">
                
                <!-- Header -->
                <div class="flex flex-col md:flex-row gap-4 mb-6">
                    <div class="relative flex-1">
                        <i class="fas fa-search absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input 
                            type="text" 
                            id="searchSchedule" 
                            placeholder="جستجو در برنامه‌ها..."
                            class="input-primary pr-12"
                            onkeyup="renderSchedule()"
                        >
                    </div>
                    <div class="flex gap-2">
                        <select id="filterScheduleLabel" onchange="renderSchedule()" class="input-primary w-auto">
                            <option value="">همه برچسب‌ها</option>
                            <option value="جلسه">🔵 جلسه</option>
                            <option value="دادگاه">🔴 دادگاه</option>
                            <option value="تنظیم">🟣 تنظیم</option>
                            <option value="پیگیری">🟠 پیگیری</option>
                        </select>
                        <button onclick="openScheduleModal()" class="btn-primary whitespace-nowrap">
                            <i class="fas fa-plus ml-2"></i>
                            برنامه جدید
                        </button>
                    </div>
                </div>
                
                <!-- Schedule Content -->
                <div class="flex-1 overflow-y-auto">
                    <!-- Today Highlight -->
                    <div id="todaySchedule" class="mb-6">
                        <div class="flex items-center gap-3 mb-4">
                            <div class="w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-fire text-red-500"></i>
                            </div>
                            <div>
                                <h3 class="font-bold text-gray-800 dark:text-white">امروز</h3>
                                <p id="todayDateSchedule" class="text-sm text-gray-500"></p>
                            </div>
                        </div>
                        <div id="scheduleSummary"></div>
                        <div id="todayScheduleList" class="space-y-3">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                    
                    <!-- Upcoming -->
                    <div id="upcomingSchedule" class="mb-6">
                        <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                            <i class="fas fa-calendar-alt text-primary-500"></i>
                            برنامه‌های آینده
                        </h3>
                        <div id="upcomingScheduleList" class="space-y-3">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                    
                    <!-- Past (Collapsible) -->
                    <div class="border-t border-gray-200 dark:border-dark-800 pt-6">
                        <button onclick="togglePastSchedule()" class="flex items-center gap-2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 mb-4">
                            <i class="fas fa-chevron-down" id="pastScheduleIcon"></i>
                            <span>برنامه‌های گذشته</span>
                        </button>
                        <div id="pastScheduleList" class="hidden space-y-3 opacity-60">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                </div>
            </div>
                        <!-- ══════════════════════════════════════════════════════════════ -->
            <!-- امور مالی -->
            <!-- ══════════════════════════════════════════════════════════════ -->
            <!-- ═══════════════════ امور مالی (کد کامل و اصلاح شده) ═══════════════════ -->
<div id="view-finance" class="page-view hidden animate-fade-in h-full flex flex-col">
    
    <!-- 1. کارت‌های آمار بالای صفحه -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="card p-5 border-r-4 border-r-emerald-500">
            <p class="text-sm text-gray-500 mb-1">مجموع دریافتی</p>
            <p id="totalIncome" class="text-2xl font-black text-emerald-600 font-mono" dir="ltr">0</p>
        </div>
        <div class="card p-5 border-r-4 border-r-red-500">
            <p class="text-sm text-gray-500 mb-1">مجموع هزینه</p>
            <p id="totalExpense" class="text-2xl font-black text-red-600 font-mono" dir="ltr">0</p>
        </div>
        <div class="card p-5 border-r-4 border-r-primary-500 dark:border-r-gold-500">
            <p class="text-sm text-gray-500 mb-1">تراز کل</p>
            <p id="totalBalance" class="text-2xl font-black text-gray-800 dark:text-white font-mono" dir="ltr">0</p>
        </div>
    </div>
    
    <!-- 2. بخش هدر (جستجو + دکمه‌ها) -->
    <!-- این دیو (div) مسئول نگه داشتن جستجو و دکمه‌ها کنار هم‌دیگر است -->
    <div class="flex flex-col md:flex-row gap-4 mb-6">
        
        <!-- کادر جستجو -->
        <div class="relative flex-1">
            <i class="fas fa-search absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input 
                type="text" 
                id="searchFinance" 
                placeholder="جستجو در تراکنش‌ها..."
                class="input-primary pr-12"
                onkeyup="renderFinance()"
            >
        </div>

        <!-- دکمه‌ها -->
        <div class="flex gap-2 text-sm overflow-x-auto pb-1 md:pb-0">
            <!-- دکمه جدید بدهکاران -->
            <button onclick="openDebtorsModal()" class="btn-primary bg-orange-500 hover:bg-orange-600 text-white whitespace-nowrap px-3 flex items-center gap-2">
                <i class="fas fa-hand-holding-dollar"></i>
                <span class="hidden md:inline">بدهکاران</span>
                <span class="md:hidden">طلب</span>
            </button>
            
            <select id="filterFinanceType" onchange="renderFinance()" class="input-primary w-auto">
                <option value="">همه</option>
                <option value="income">دریافت</option>
                <option value="expense">هزینه</option>
            </select>
            
            <button onclick="openFinanceModal()" class="btn-primary whitespace-nowrap">
                <i class="fas fa-plus ml-2"></i>
                جدید
            </button>
        </div>
    </div>
    
    <!-- 3. جدول تراکنش‌ها -->
    <div class="card flex-1 overflow-hidden flex flex-col">
        <div class="overflow-x-auto flex-1">
            <table class="w-full">
                <thead class="bg-gray-50 dark:bg-dark-800 sticky top-0">
                    <tr class="text-right text-sm text-gray-500 dark:text-gray-400">
                        <th class="p-4 font-medium">تاریخ</th>
                        <th class="p-4 font-medium">پرونده</th>
                        <th class="p-4 font-medium">نوع</th>
                        <th class="p-4 font-medium">مبلغ</th>
                        <th class="p-4 font-medium">توضیحات</th>
                        <th class="p-4 font-medium text-center">عملیات</th>
                    </tr>
                </thead>
                <tbody id="financeTableBody" class="divide-y divide-gray-100 dark:divide-dark-800">
                    <!-- اینجا با جاوا اسکریپت پر می‌شود -->
                </tbody>
            </table>
        </div>
    </div>
</div>
                
                        <!-- ══════════════════════════════════════════════════════════════ -->
            <!-- بانک لوایح -->
            <!-- ══════════════════════════════════════════════════════════════ -->
            <div id="view-library" class="page-view hidden animate-fade-in h-full flex flex-col lg:flex-row gap-6">
                
                <!-- List -->
                <div class="w-full lg:w-1/3 flex flex-col">
                    <div class="card p-4 flex flex-col h-full">
                        <button onclick="openLibraryModal()" class="btn-primary w-full mb-4">
                            <i class="fas fa-plus ml-2"></i>
                            متن جدید
                        </button>
                        
                        <div class="relative mb-4">
                            <i class="fas fa-search absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                            <input 
                                type="text" 
                                id="searchLibrary" 
                                placeholder="جستجو..."
                                class="input-primary pr-12"
                                onkeyup="renderLibrary()"
                            >
                        </div>
                        
                        <div id="libraryList" class="flex-1 overflow-y-auto space-y-2">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                </div>
                
                <!-- Content Viewer -->
                <div class="flex-1 flex flex-col">
                    <div class="card p-6 flex-1 flex flex-col">
                        <!-- Empty State -->
                        <div id="libraryEmpty" class="flex-1 flex flex-col items-center justify-center text-center">
                            <div class="w-20 h-20 bg-gray-100 dark:bg-dark-800 rounded-full flex items-center justify-center mb-4">
                                <i class="fas fa-book-open text-3xl text-gray-300 dark:text-gray-600"></i>
                            </div>
                            <p class="text-gray-400">یک متن از لیست انتخاب کنید</p>
                        </div>
                        
                        <!-- Content View -->
                        <div id="libraryContent" class="flex-1 flex flex-col hidden">
                            <div class="flex items-start justify-between mb-4 pb-4 border-b border-gray-100 dark:border-dark-800">
                                <div>
                                    <h2 id="libraryViewTitle" class="text-xl font-bold text-gray-800 dark:text-white"></h2>
                                    <span id="libraryViewType" class="tag mt-2"></span>
                                </div>
                                <div class="flex gap-2">
                                    <button onclick="copyLibraryContent()" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg transition" title="کپی">
                                        <i class="fas fa-copy text-gray-400"></i>
                                    </button>
                                    <button onclick="editLibrary()" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg transition" title="ویرایش">
                                        <i class="fas fa-edit text-gray-400"></i>
                                    </button>
                                    <button onclick="deleteLibrary()" class="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition" title="حذف">
                                        <i class="fas fa-trash text-red-400"></i>
                                    </button>
                                </div>
                            </div>
                            <div id="libraryViewContent" class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-800 rounded-xl p-5 text-sm leading-8 whitespace-pre-wrap"></div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>
</div>
<!-- ═══════════════════════════════════════════════════════════════════════ -->
<!-- مودال‌ها -->
<!-- ═══════════════════════════════════════════════════════════════════════ -->

<!-- Quick Add Modal -->
<div id="quickAddModal" class="modal-overlay" onclick="closeModalOnOverlay(event, 'quickAddModal')">
    <div class="modal-content max-w-md">
        <div class="p-6 border-b border-gray-100 dark:border-dark-800 flex items-center justify-between">
            <h3 class="text-lg font-bold text-gray-800 dark:text-white">
                <i class="fas fa-plus-circle ml-2 text-primary-500"></i>
                افزودن سریع
            </h3>
            <button onclick="closeModal('quickAddModal')" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                <i class="fas fa-times text-gray-400"></i>
            </button>
        </div>
        <div class="p-6 grid grid-cols-2 gap-4">
            <button onclick="closeModal('quickAddModal'); openCaseModal()" class="p-6 card hover:border-primary-500 transition text-center">
                <i class="fas fa-folder-plus text-3xl text-primary-500 mb-2"></i>
                <p class="font-medium text-gray-700 dark:text-gray-300">پرونده جدید</p>
            </button>
            <button onclick="closeModal('quickAddModal'); openScheduleModal()" class="p-6 card hover:border-amber-500 transition text-center">
                <i class="fas fa-calendar-plus text-3xl text-amber-500 mb-2"></i>
                <p class="font-medium text-gray-700 dark:text-gray-300">برنامه جدید</p>
            </button>
            <button onclick="closeModal('quickAddModal'); openFinanceModal()" class="p-6 card hover:border-emerald-500 transition text-center">
                <i class="fas fa-money-bill-wave text-3xl text-emerald-500 mb-2"></i>
                <p class="font-medium text-gray-700 dark:text-gray-300">تراکنش جدید</p>
            </button>
            <button onclick="closeModal('quickAddModal'); openLibraryModal()" class="p-6 card hover:border-purple-500 transition text-center">
                <i class="fas fa-file-alt text-3xl text-purple-500 mb-2"></i>
                <p class="font-medium text-gray-700 dark:text-gray-300">متن جدید</p>
            </button>
        </div>
    </div>
</div>

<!-- Case Modal -->
<div id="caseModal" class="modal-overlay" onclick="closeModalOnOverlay(event, 'caseModal')">
    <div class="modal-content max-w-2xl">
        <div class="p-6 border-b border-gray-100 dark:border-dark-800 flex items-center justify-between bg-primary-600 dark:bg-gold-500 rounded-t-2xl">
            <h3 id="caseModalTitle" class="text-lg font-bold text-white dark:text-dark-900">
                <i class="fas fa-folder-plus ml-2"></i>
                پرونده جدید
            </h3>
            <button onclick="closeModal('caseModal')" class="p-2 hover:bg-white/20 rounded-lg text-white dark:text-dark-900">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form id="caseForm" onsubmit="saveCase(event)" class="p-6 max-h-[70vh] overflow-y-auto">
    <input type="hidden" id="caseId">
    
    <!-- اطلاعات موکل -->
    <div class="mb-5">
        <h4 class="text-xs font-bold text-primary-600 dark:text-gold-500 mb-3 flex items-center gap-2">
            <i class="fas fa-user"></i> اطلاعات موکل
        </h4>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div class="col-span-2">
                <label class="block text-xs text-gray-500 mb-1">نام و نام خانوادگی *</label>
                <input type="text" id="caseName" class="input-primary text-sm py-2" required>
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">شماره تماس *</label>
                <input type="tel" id="caseMobile" class="input-primary text-sm py-2" dir="ltr" required>
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">کد ملی</label>
                <input type="text" id="caseNational" class="input-primary text-sm py-2" dir="ltr">
            </div>
                    <div>
            <label class="block text-xs text-gray-500 mb-1">تاریخ تولد</label>
            <input type="text" id="caseBirth" class="input-primary text-sm py-2 text-center" placeholder="13xx/xx/xx" dir="ltr">
        </div>
        </div>
    </div>
    
    <!-- اطلاعات پرونده -->
    <div class="mb-5">
        <h4 class="text-xs font-bold text-primary-600 dark:text-gold-500 mb-3 flex items-center gap-2">
            <i class="fas fa-folder-open"></i> مشخصات پرونده
        </h4>
        <div class="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div class="col-span-2">
                <label class="block text-xs text-gray-500 mb-1">عنوان پرونده *</label>
                <input type="text" id="caseTitle" class="input-primary text-sm py-2" required>
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">نوع</label>
                <select id="caseType" class="input-primary text-sm py-2">
                    <option value="حقوقی">حقوقی</option>
                    <option value="کیفری">کیفری</option>
                    <option value="خانواده">خانواده</option>
                    <option value="ملکی">ملکی</option>
                    <option value="ثبتی">ثبتی</option>
                </select>
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">وضعیت</label>
                <select id="caseStatus" class="input-primary text-sm py-2">
                    <option value="جاری">جاری</option>
                    <option value="مختومه">مختومه</option>
                </select>
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">شعبه دادگاه</label>
                <input type="text" id="caseBranch" class="input-primary text-sm py-2">
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">شماره بایگانی</label>
                <input type="text" id="caseArchiveNo" class="input-primary text-sm py-2" dir="ltr">
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">طرف دعوی</label>
                <input type="text" id="caseOpponent" class="input-primary text-sm py-2">
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">شماره قرارداد</label>
                <input type="text" id="caseContract" class="input-primary text-sm py-2" dir="ltr">
            </div>
            <div class="col-span-2 md:col-span-1">
        <label class="block text-xs text-emerald-600 font-bold mb-1">مبلغ حق‌الوکاله (تومان)</label>
        <input type="text" id="casePrice" class="input-primary text-sm py-2 font-bold text-emerald-600" dir="ltr" placeholder="0">
    </div>
        </div>
    </div>
    
    <!-- دادسرا -->
    <div class="mb-5 p-3 bg-orange-50 dark:bg-orange-900/10 rounded-xl">
        <label class="flex items-center gap-2 cursor-pointer mb-3">
            <input type="checkbox" id="caseHasProsecutor" onchange="toggleProsecutor()" class="w-4 h-4 rounded">
            <span class="text-sm font-medium text-orange-700 dark:text-orange-400">
                <i class="fas fa-balance-scale ml-1"></i> پرونده دادسرا دارد
            </span>
        </label>
        <div id="prosecutorFields" class="hidden grid grid-cols-2 gap-3">
            <div>
                <label class="block text-xs text-gray-500 mb-1">شعبه دادسرا</label>
                <input type="text" id="caseProsecutorBranch" class="input-primary text-sm py-2">
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">بایگانی دادسرا</label>
                <input type="text" id="caseProsecutorArchive" class="input-primary text-sm py-2" dir="ltr">
            </div>
        </div>
    </div>
    
    <!-- اجرای احکام -->
    <div class="mb-5 p-3 bg-purple-50 dark:bg-purple-900/10 rounded-xl">
        <label class="flex items-center gap-2 cursor-pointer mb-3">
            <input type="checkbox" id="caseHasExecution" onchange="toggleExecution()" class="w-4 h-4 rounded">
            <span class="text-sm font-medium text-purple-700 dark:text-purple-400">
                <i class="fas fa-gavel ml-1"></i> اجرای احکام دارد
            </span>
        </label>
        <div id="executionFields" class="hidden grid grid-cols-2 gap-3">
            <div>
                <label class="block text-xs text-gray-500 mb-1">شعبه اجرا</label>
                <input type="text" id="caseExecutionBranch" class="input-primary text-sm py-2">
            </div>
            <div>
                <label class="block text-xs text-gray-500 mb-1">بایگانی اجرا</label>
                <input type="text" id="caseExecutionArchive" class="input-primary text-sm py-2" dir="ltr">
            </div>
        </div>
    </div>
    
    <!-- تگ‌ها و یادداشت -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
        <div>
            <label class="block text-xs text-gray-500 mb-1">تگ‌ها</label>
            <input type="text" id="caseTags" class="input-primary text-sm py-2" placeholder="با کاما جدا کنید...">
        </div>
        <div>
            <label class="block text-xs text-gray-500 mb-1">آدرس</label>
            <input type="text" id="caseAddress" class="input-primary text-sm py-2">
        </div>
    </div>
    <div>
        <label class="block text-xs text-gray-500 mb-1">یادداشت</label>
        <textarea id="caseNotes" class="input-primary text-sm py-2 resize-none" rows="2"></textarea>
    </div>
    
    <!-- Actions -->
    <div class="flex gap-3 mt-5 pt-4 border-t border-gray-100 dark:border-dark-800">
        <button type="button" onclick="closeModal('caseModal')" class="flex-1 py-2.5 bg-gray-100 dark:bg-dark-800 text-gray-600 dark:text-gray-400 rounded-xl text-sm font-medium hover:bg-gray-200 transition">
            انصراف
        </button>
        <button type="submit" class="flex-1 btn-primary text-sm py-2.5">
            <i class="fas fa-save ml-2"></i> ذخیره
        </button>
    </div>
</form>
    </div>
</div>

<!-- Schedule Modal -->
<div id="scheduleModal" class="modal-overlay" onclick="closeModalOnOverlay(event, 'scheduleModal')">
    <div class="modal-content max-w-lg">
        <div class="p-6 border-b border-gray-100 dark:border-dark-800 flex items-center justify-between bg-amber-500 rounded-t-2xl">
            <h3 id="scheduleModalTitle" class="text-lg font-bold text-white">
                <i class="fas fa-calendar-plus ml-2"></i>
                برنامه جدید
            </h3>
            <button onclick="closeModal('scheduleModal')" class="p-2 hover:bg-white/20 rounded-lg text-white">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form id="scheduleForm" onsubmit="saveSchedule(event)" class="p-6">
            <input type="hidden" id="scheduleId">
            
            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">تاریخ *</label>
                    <input type="text" id="scheduleDate" class="input-primary text-center" placeholder="1403/01/01" required>
                </div>
                <div>
                    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">ساعت *</label>
                    <input type="time" id="scheduleTime" class="input-primary text-center" required>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">موکل / طرف حساب</label>
                <div class="relative">
                    <input type="text" id="scheduleClient" class="input-primary" autocomplete="off" onkeyup="suggestClients(this)">
                    <div id="clientSuggestions" class="absolute top-full right-0 left-0 bg-white dark:bg-dark-900 border border-gray-200 dark:border-dark-700 rounded-xl shadow-xl mt-1 hidden z-50 max-h-40 overflow-y-auto"></div>
                </div>
            </div>
            
            <div class="mb-4">
    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">پرونده مرتبط (اختیاری)</label>
    <div class="relative">
        <input type="text" id="scheduleCaseSearch" class="input-primary" placeholder="جستجوی پرونده..." autocomplete="off" onkeyup="searchCases(this, 'scheduleCaseId')">
        <select id="scheduleCaseId" class="input-primary mt-2">
            <option value="">بدون پرونده</option>
        </select>
    </div>
</div>
            
            <div class="mb-4">
                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">برچسب</label>
                <select id="scheduleLabel" class="input-primary">
                    <option value="">بدون برچسب</option>
                    <option value="جلسه">🔵 جلسه</option>
                    <option value="دادگاه">🔴 دادگاه</option>
                    <option value="تنظیم">🟣 تنظیم</option>
                    <option value="پیگیری">🟠 پیگیری</option>
                </select>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">شرح کار</label>
                <textarea id="scheduleDesc" class="input-primary resize-none" rows="2"></textarea>
            </div>
            
            <div class="mb-4 p-4 bg-emerald-50 dark:bg-emerald-900/20 rounded-xl">
                <label class="block text-sm text-emerald-700 dark:text-emerald-400 mb-1 font-medium">
                    <i class="fas fa-check-double ml-1"></i>
                    نتیجه (اختیاری)
                </label>
                <input type="text" id="scheduleResult" class="input-primary bg-white dark:bg-dark-800">
            </div>
            
            <!-- Actions -->
            <div class="flex gap-3 mt-6 pt-6 border-t border-gray-100 dark:border-dark-800">
                <button type="button" onclick="closeModal('scheduleModal')" class="flex-1 py-3 bg-gray-100 dark:bg-dark-800 text-gray-600 dark:text-gray-400 rounded-xl font-medium hover:bg-gray-200 transition">
                    انصراف
                </button>
                <button type="submit" class="flex-1 btn-primary">
                    <i class="fas fa-save ml-2"></i>
                    ذخیره
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Finance Modal -->
<div id="financeModal" class="modal-overlay" onclick="closeModalOnOverlay(event, 'financeModal')">
    <div class="modal-content max-w-md">
        <div class="p-6 border-b border-gray-100 dark:border-dark-800 flex items-center justify-between bg-emerald-600 rounded-t-2xl">
            <h3 id="financeModalTitle" class="text-lg font-bold text-white">
                <i class="fas fa-money-bill-wave ml-2"></i>
                تراکنش جدید
            </h3>
            <button onclick="closeModal('financeModal')" class="p-2 hover:bg-white/20 rounded-lg text-white">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form id="financeForm" onsubmit="saveFinance(event)" class="p-6">
            <input type="hidden" id="financeId">
            
            <div class="mb-4">
                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">پرونده مرتبط (اختیاری)</label>
                <select id="financeCaseId" class="input-primary">
                    <option value="">بدون پرونده</option>
                </select>
            </div>
            
            <div class="grid grid-cols-2 gap-4 mb-4">
                <div>
                    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">نوع</label>
                    <select id="financeType" class="input-primary">
                        <option value="income">دریافت (+)</option>
                        <option value="expense">هزینه (-)</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">تاریخ</label>
                    <input type="text" id="financeDate" class="input-primary text-center">
                </div>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">مبلغ (تومان) *</label>
                <input type="number" id="financeAmount" class="input-primary text-center text-xl font-bold" required>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">توضیحات</label>
                <input type="text" id="financeDesc" class="input-primary">
            </div>
            
            <!-- Actions -->
            <div class="flex gap-3 mt-6 pt-6 border-t border-gray-100 dark:border-dark-800">
                <button type="button" onclick="closeModal('financeModal')" class="flex-1 py-3 bg-gray-100 dark:bg-dark-800 text-gray-600 dark:text-gray-400 rounded-xl font-medium hover:bg-gray-200 transition">
                    انصراف
                </button>
                <button type="submit" class="flex-1 btn-primary">
                    <i class="fas fa-save ml-2"></i>
                    ذخیره
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Library Modal -->
<div id="libraryModal" class="modal-overlay" onclick="closeModalOnOverlay(event, 'libraryModal')">
    <div class="modal-content max-w-2xl">
        <div class="p-6 border-b border-gray-100 dark:border-dark-800 flex items-center justify-between bg-purple-600 rounded-t-2xl">
            <h3 id="libraryModalTitle" class="text-lg font-bold text-white">
                <i class="fas fa-file-alt ml-2"></i>
                متن جدید
            </h3>
            <button onclick="closeModal('libraryModal')" class="p-2 hover:bg-white/20 rounded-lg text-white">
                <i class="fas fa-times"></i>
            </button>
        </div>
        <form id="libraryForm" onsubmit="saveLibrary(event)" class="p-6">
            <input type="hidden" id="libraryId">
            
            <div class="grid grid-cols-3 gap-4 mb-4">
                <div class="col-span-2">
                    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">عنوان *</label>
                    <input type="text" id="libraryTitle" class="input-primary" required>
                </div>
                <div>
                    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">نوع</label>
                    <select id="libraryType" class="input-primary">
                        <option value="لایحه">لایحه</option>
                        <option value="دادخواست">دادخواست</option>
                        <option value="قرارداد">قرارداد</option>
                        <option value="اظهارنامه">اظهارنامه</option>
                        <option value="سایر">سایر</option>
                    </select>
                </div>
            </div>
            
            <div class="mb-4">
                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">متن</label>
                <!-- 👇 اینجا تغییر کرد: id شد libraryInputText -->
                <textarea id="libraryInputText" class="input-primary resize-none font-mono text-sm leading-7" rows="12"></textarea>
            </div>
            
            <div class="flex gap-3 mt-6 pt-6 border-t border-gray-100 dark:border-dark-800">
                <button type="button" onclick="closeModal('libraryModal')" class="flex-1 py-3 bg-gray-100 dark:bg-dark-800 text-gray-600 dark:text-gray-400 rounded-xl font-medium hover:bg-gray-200 transition">
                    انصراف
                </button>
                <button type="submit" class="flex-1 btn-primary">
                    <i class="fas fa-save ml-2"></i>
                    ذخیره
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Case Detail Modal -->
<div id="caseDetailModal" class="modal-overlay" onclick="closeModalOnOverlay(event, 'caseDetailModal')">
    <div class="modal-content max-w-3xl">
        <div class="p-6 border-b border-gray-100 dark:border-dark-800 flex items-center justify-between">
            <h3 class="text-lg font-bold text-gray-800 dark:text-white">
                <i class="fas fa-folder-open ml-2 text-primary-500"></i>
                جزئیات پرونده
            </h3>
            <button onclick="closeModal('caseDetailModal')" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                <i class="fas fa-times text-gray-400"></i>
            </button>
        </div>
        <div id="caseDetailContent" class="p-6 max-h-[70vh] overflow-y-auto">
            <!-- Dynamic content -->
        </div>
    </div>
</div>

<!-- Debtors Modal -->
<div id="debtorsModal" class="modal-overlay" onclick="closeModalOnOverlay(event, 'debtorsModal')">
    <div class="modal-content max-w-2xl">
        <div class="p-6 border-b border-gray-100 dark:border-dark-800 flex items-center justify-between bg-orange-500 rounded-t-2xl">
            <h3 class="text-lg font-bold text-white">
                <i class="fas fa-file-invoice-dollar ml-2"></i>
                لیست بدهکاران و مانده حساب
            </h3>
            <button onclick="closeModal('debtorsModal')" class="p-2 hover:bg-white/20 rounded-lg text-white">
                <i class="fas fa-times"></i>
            </button>
        </div>
        
        <div class="p-4 bg-orange-50 dark:bg-orange-900/10 border-b border-orange-100 dark:border-orange-900/20">
            <div class="flex justify-between items-center">
                <span class="text-sm text-orange-800 dark:text-orange-300">مجموع کل طلب شما:</span>
                <span id="totalDebtAmount" class="text-xl font-bold text-orange-600 dark:text-orange-400 font-mono">0</span>
            </div>
        </div>

        <div id="debtorsListContent" class="p-6 max-h-[60vh] overflow-y-auto space-y-3">
            <!-- لیست اینجا ساخته می‌شود -->
        </div>
        
        <div class="p-4 border-t border-gray-100 dark:border-dark-800 text-center">
            <button onclick="closeModal('debtorsModal')" class="px-6 py-2 bg-gray-100 dark:bg-dark-700 rounded-lg text-gray-600 dark:text-gray-300 hover:bg-gray-200">
                بستن
            </button>
        </div>
    </div>
</div>
<!-- ═══════════════════════════════════════════════════════════════════════ -->
<!-- JavaScript -->
<!-- ═══════════════════════════════════════════════════════════════════════ -->
<script>
// ═══════════════════════════════════════════════════
// Global State
// ═══════════════════════════════════════════════════
let db = { cases: [], finance: [], library: [], schedule: [] };
let charts = {};
let currentLibraryId = null;


// ═══════════════════════════════════════════════════
// تبدیل اعداد فارسی به انگلیسی
// ═══════════════════════════════════════════════════
function convertToEnglishNumbers(str) {
    if (!str) return str;
    const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    
    for (let i = 0; i < 10; i++) {
        str = str.replace(new RegExp(persianNumbers[i], 'g'), i);
        str = str.replace(new RegExp(arabicNumbers[i], 'g'), i);
    }
    return str;
}

function convertToPersianNumbers(str) {
    if (!str) return str;
    const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return str.toString().replace(/[0-9]/g, d => persianNumbers[d]);
}







// ═══════════════════════════════════════════════════
// Initialize
// ═══════════════════════════════════════════════════
window.onload = async () => {
    // Set today date
    const today = new Date().toLocaleDateString('fa-IR');
    document.getElementById('todayDate').textContent = today;
    document.getElementById('todayDateSchedule').textContent = today;
    document.getElementById('financeDate').value = today;
    document.getElementById('scheduleDate').value = today;
    
    // Load theme
    if (localStorage.getItem('theme') === 'dark') {
        document.documentElement.classList.add('dark');
    }
    
    // Initialize charts FIRST
    initCharts();
    
    // Then load data
    await loadData();
    
    // Close dropdowns on outside click
    document.addEventListener('click', (e) => {
        if (!e.target.closest('#clientSuggestions') && !e.target.closest('#scheduleClient')) {
            document.getElementById('clientSuggestions').classList.add('hidden');
        }
    });
};

// ═══════════════════════════════════════════════════
// API Functions
// ═══════════════════════════════════════════════════
async function loadData() {
    try {
        const res = await fetch('api.php?action=get_data');
        const data = await res.json();
        if (data.success) {
            db = data.data;
            if (!db.schedule) db.schedule = [];
            refreshAll();
        }
    } catch (err) {
        console.error('Load error:', err);
    }
}

async function saveData(syncType = null, syncItem = null) {
    try {
        const body = { db };
        if (syncType && syncItem) {
            body.syncType = syncType;
            body.syncItem = syncItem;
        }
        
        const res = await fetch('api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body)
        });
        
        const data = await res.json();
        if (data.success) {
            showSyncStatus();
        }
        return data.success;
    } catch (err) {
        console.error('Save error:', err);
        return false;
    }
}

function showSyncStatus() {
    const el = document.getElementById('syncStatus');
    el.classList.remove('hidden');
    el.classList.add('flex');
    setTimeout(() => {
        el.classList.add('hidden');
        el.classList.remove('flex');
    }, 2000);
}

// ═══════════════════════════════════════════════════
// Refresh Functions
// ═══════════════════════════════════════════════════
function refreshAll() {
    renderDashboard();
    renderCases();
    renderSchedule();
    renderFinance();
    renderLibrary();
    updateCaseSelects();
}

function updateCaseSelects() {
    const options = '<option value="">بدون پرونده</option>' + 
        db.cases.map(c => `<option value="${c.id}">${c.name} - ${c.title} ${c.archiveNo ? '('+c.archiveNo+')' : ''}</option>`).join('');
    
    document.getElementById('scheduleCaseId').innerHTML = options;
    document.getElementById('financeCaseId').innerHTML = options;
}

// ═══════════════════════════════════════════════════
// Dashboard
// ═══════════════════════════════════════════════════
function renderDashboard() {
    const today = getTodayPersian();
    
    // Stats
    const activeCases = db.cases.filter(c => c.status === 'جاری').length;
    const todaySchedules = db.schedule.filter(s => comparePersianDates(s.date, today) === 0).length;
    const income = db.finance.filter(f => f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
    const expense = db.finance.filter(f => f.type === 'expense').reduce((a, b) => a + Number(b.amount), 0);
    
    document.getElementById('stat-cases').textContent = activeCases;
    document.getElementById('stat-today').textContent = todaySchedules;
    document.getElementById('stat-income').textContent = income.toLocaleString();
    document.getElementById('stat-balance').textContent = (income - expense).toLocaleString();
    
    // Upcoming schedules
const upcoming = db.schedule
    .filter(s => comparePersianDates(s.date, today) >= 0 && !s.is_done)
    .sort((a, b) => {
        const dateCompare = comparePersianDates(a.date, b.date);
        if (dateCompare !== 0) return dateCompare;
        return (a.time || '').localeCompare(b.time || '');
    })
    .slice(0, 4);
    
    document.getElementById('upcomingList').innerHTML = upcoming.length ? upcoming.map(s => `
        <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-800 rounded-xl">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center">
                    <i class="fas fa-clock text-amber-600 dark:text-amber-400"></i>
                </div>
                <div>
                    <p class="font-medium text-gray-700 dark:text-gray-300">${s.client || 'بدون نام'}</p>
                    <p class="text-xs text-gray-400">${s.label || 'برنامه'}</p>
                </div>
            </div>
            <div class="text-left">
                <p class="font-mono text-sm font-bold text-primary-600 dark:text-gold-500">${s.date.split('/').slice(1).join('/')}</p>
                <p class="text-xs text-gray-400">${s.time}</p>
            </div>
        </div>
    `).join('') : '<p class="text-center text-gray-400 py-4">برنامه‌ای نیست</p>';
    
    // Recent cases
    document.getElementById('recentCasesList').innerHTML = db.cases.slice(0, 4).map(c => `
        <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-800 rounded-xl cursor-pointer hover:bg-gray-100 dark:hover:bg-dark-700 transition" onclick="showCaseDetail(${c.id})">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 ${c.status === 'جاری' ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'} rounded-lg flex items-center justify-center">
                    <i class="fas fa-folder ${c.status === 'جاری' ? 'text-emerald-600' : 'text-red-600'}"></i>
                </div>
                <div>
                    <p class="font-medium text-gray-700 dark:text-gray-300">${c.name}</p>
                    <p class="text-xs text-gray-400">${c.title}</p>
                </div>
            </div>
            <span class="${c.status === 'جاری' ? 'badge-success' : 'badge-danger'} text-xs px-2 py-1 rounded">${c.status}</span>
        </div>
    `).join('') || '<p class="text-center text-gray-400 py-4">پرونده‌ای نیست</p>';
    
    // Recent finance
    document.getElementById('recentFinanceList').innerHTML = db.finance.slice(0, 4).map(f => {
        const cs = db.cases.find(c => c.id == f.caseId);
        return `
            <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-800 rounded-xl">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 ${f.type === 'income' ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'} rounded-lg flex items-center justify-center">
                        <i class="fas ${f.type === 'income' ? 'fa-arrow-down text-emerald-600' : 'fa-arrow-up text-red-600'}"></i>
                    </div>
                    <div>
                        <p class="font-medium text-gray-700 dark:text-gray-300">${cs ? cs.name : 'بدون پرونده'}</p>
                        <p class="text-xs text-gray-400">${f.date}</p>
                    </div>
                </div>
                <p class="font-mono font-bold ${f.type === 'income' ? 'text-emerald-600' : 'text-red-600'}" dir="ltr">${Number(f.amount).toLocaleString()}</p>
            </div>
        `;
    }).join('') || '<p class="text-center text-gray-400 py-4">تراکنشی نیست</p>';
    
    // Update charts
    updateCharts();
}

// ═══════════════════════════════════════════════════
// Charts
// ═══════════════════════════════════════════════════
function initCharts() {
    const casesCtx = document.getElementById('casesChart').getContext('2d');
    const financeCtx = document.getElementById('financeChart').getContext('2d');
    
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#94a3b8' : '#64748b';
    const gridColor = isDark ? '#1e293b' : '#f1f5f9';
    
    charts.cases = new Chart(casesCtx, {
        type: 'doughnut',
        data: {
            labels: ['جاری', 'مختومه'],
            datasets: [{
                data: [0, 0],
                backgroundColor: ['#10b981', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: textColor, font: { family: 'Vazirmatn' } }
                }
            }
        }
    });
    
    charts.finance = new Chart(financeCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                { label: 'دریافت', data: [], backgroundColor: '#10b981' },
                { label: 'هزینه', data: [], backgroundColor: '#ef4444' }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color: textColor, font: { family: 'Vazirmatn' } }
                }
            },
            scales: {
                x: { grid: { color: gridColor }, ticks: { color: textColor, font: { family: 'Vazirmatn' } } },
                y: { grid: { color: gridColor }, ticks: { color: textColor } }
            }
        }
    });
}

function updateCharts() {
    // Check if charts exist
    if (!charts.cases || !charts.finance) return;
    
    // Cases chart
    const active = db.cases.filter(c => c.status === 'جاری').length;
    const closed = db.cases.filter(c => c.status === 'مختومه').length;
    charts.cases.data.datasets[0].data = [active, closed];
    charts.cases.update();
    
    // Finance chart - Last 6 months
    const months = {};
    db.finance.forEach(f => {
        if (!f.date) return;
        const month = f.date.split('/').slice(0, 2).join('/');
        if (!months[month]) months[month] = { income: 0, expense: 0 };
        if (f.type === 'income' || f.type === 'expense') {
            months[month][f.type] += Number(f.amount) || 0;
        }
    });
    
    const sortedMonths = Object.keys(months).sort().slice(-6);
    charts.finance.data.labels = sortedMonths;
    charts.finance.data.datasets[0].data = sortedMonths.map(m => months[m]?.income || 0);
    charts.finance.data.datasets[1].data = sortedMonths.map(m => months[m]?.expense || 0);
    charts.finance.update();
}

// ═══════════════════════════════════════════════════
// Cases
// ═══════════════════════════════════════════════════
function renderCases() {
    const search = document.getElementById('searchCases')?.value.toLowerCase() || '';
    const statusFilter = document.getElementById('filterCaseStatus')?.value || '';
    const typeFilter = document.getElementById('filterCaseType')?.value || '';
    
    // مرتب‌سازی بر اساس شماره دفتر (نزولی - جدیدترین‌ها اول)
    const filtered = db.cases.filter(c => {
        if (search && !JSON.stringify(c).toLowerCase().includes(search)) return false;
        if (statusFilter && c.status !== statusFilter) return false;
        if (typeFilter && c.type !== typeFilter) return false;
        return true;
    }).sort((a, b) => (b.officeNo || 0) - (a.officeNo || 0)); // مرتب‌سازی اضافه شد
    
    const grid = document.getElementById('casesGrid');
    
    // تنظیم گرید برای نمایش درست
    grid.className = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 pb-10 content-start";

    grid.innerHTML = filtered.map(c => {
        const tags = (c.tags && c.tags.trim()) ? c.tags.split(',').filter(t => t.trim()).slice(0, 2).map(t => 
            `<span class="inline-block px-1.5 py-0.5 text-[10px] rounded bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">${t.trim()}</span>`
        ).join('') : '';
        
        return `
            <div class="card p-3 cursor-pointer hover:border-primary-500 dark:hover:border-gold-500 transition group" onclick="showCaseDetail(${c.id})">
            
                <div class="flex items-center justify-between mb-2">
                    <div class="flex items-center gap-2">
                        <div class="w-8 h-8 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center">
                            <i class="fas fa-user text-primary-600 dark:text-primary-400 text-sm"></i>
                        </div>
                        
                        <div>
                            <h4 class="font-bold text-gray-800 dark:text-white text-sm">${c.name}</h4>
                            <p class="text-xs text-gray-400 font-mono">${c.mobile}</p>
                        </div>
                    </div>
                    
                    <!-- بخش جدید: شماره دفتر + وضعیت -->
                    <div class="flex items-center gap-1">
                        <span class="text-[10px] font-mono bg-gray-100 dark:bg-gray-700 text-gray-500 px-1.5 py-0.5 rounded border border-gray-200 dark:border-gray-600" title="شماره دفتر">
                            #${c.officeNo || '-'}
                        </span>
                        <span class="${c.status === 'جاری' ? 'badge-success' : 'badge-danger'} text-[10px] px-1.5 py-0.5 rounded">${c.status}</span>
                    </div>
                </div>
                
                <p class="text-sm text-gray-700 dark:text-gray-300 mb-1 truncate font-bold">${c.title}</p>
                
                <div class="flex items-center justify-between text-[10px] text-gray-400">
                    <div class="flex items-center gap-2">
                        <span>${c.type}</span>
                        ${c.archiveNo ? `<span class="bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 px-1 rounded font-mono dir-ltr">📁 ${c.archiveNo}</span>` : ''}
                    </div>
                    <div class="flex gap-1">
                        ${c.hasProsecutor ? '<span title="دادسرا">⚖️</span>' : ''}
                        ${c.hasExecution ? '<span title="اجرای احکام">📋</span>' : ''}
                    </div>
                </div>
                
                ${tags ? `<div class="flex flex-wrap gap-1 mt-2">${tags}</div>` : ''}
                
                <div class="flex items-center justify-between mt-2 pt-2 border-t border-gray-100 dark:border-dark-700">
                    <span class="text-[10px] text-gray-400 font-mono">${c.updatedAt || '-'}</span>
                    <div class="flex gap-0.5 opacity-100 lg:opacity-0 group-hover:opacity-100 transition-opacity">
                        <button onclick="event.stopPropagation(); editCase(${c.id})" class="p-1.5 hover:bg-gray-100 dark:hover:bg-dark-700 rounded transition" title="ویرایش">
                            <i class="fas fa-edit text-gray-400 text-xs"></i>
                        </button>
                        <button onclick="event.stopPropagation(); deleteCase(${c.id})" class="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition" title="حذف">
                            <i class="fas fa-trash text-red-400 text-xs"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('') || '<div class="col-span-full text-center py-12 text-gray-400"><i class="fas fa-folder-open text-4xl mb-4"></i><p>پرونده‌ای یافت نشد</p></div>';
}

function openCaseModal(id = null) {
    document.getElementById('caseForm').reset();
    document.getElementById('caseId').value = '';
    document.getElementById('caseModalTitle').innerHTML = '<i class="fas fa-folder-plus ml-2"></i> پرونده جدید';
    document.getElementById('prosecutorFields').classList.add('hidden');
    document.getElementById('executionFields').classList.add('hidden');
    
    if (id) {
        const c = db.cases.find(x => x.id == id);
        if (c) {
            document.getElementById('caseModalTitle').innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش پرونده';
            document.getElementById('caseId').value = c.id;
            document.getElementById('caseName').value = c.name || '';
            document.getElementById('caseMobile').value = c.mobile || '';
            document.getElementById('caseNational').value = c.national || '';
            document.getElementById('caseBirth').value = c.birthDate || '';
            document.getElementById('caseAddress').value = c.address || '';
            document.getElementById('caseTitle').value = c.title || '';
            document.getElementById('caseType').value = c.type || 'حقوقی';
            document.getElementById('caseStatus').value = c.status || 'جاری';
            document.getElementById('caseBranch').value = c.branch || '';
            document.getElementById('caseArchiveNo').value = c.archiveNo || '';
            document.getElementById('caseOpponent').value = c.opponent || '';
            document.getElementById('caseContract').value = c.contract || '';
            // نمایش قیمت با سه رقم اعشار (کاما)
            document.getElementById('casePrice').value = (c.totalPrice || '').toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
            // دادسرا
            document.getElementById('caseHasProsecutor').checked = c.hasProsecutor || false;
            document.getElementById('caseProsecutorBranch').value = c.prosecutorBranch || '';
            document.getElementById('caseProsecutorArchive').value = c.prosecutorArchive || '';
            if (c.hasProsecutor) document.getElementById('prosecutorFields').classList.remove('hidden');
            // اجرای احکام
            document.getElementById('caseHasExecution').checked = c.hasExecution || false;
            document.getElementById('caseExecutionBranch').value = c.executionBranch || '';
            document.getElementById('caseExecutionArchive').value = c.executionArchive || '';
            if (c.hasExecution) document.getElementById('executionFields').classList.remove('hidden');
            // سایر
            document.getElementById('caseTags').value = c.tags || '';
            document.getElementById('caseNotes').value = c.notes || '';
        }
    }
    
    openModal('caseModal');
}

function editCase(id) {
    openCaseModal(id);
}

async function saveCase(e) {
    e.preventDefault();
    
    const id = document.getElementById('caseId').value;
    
    // منطق شماره دفتر
    let officeNo;
    if (id) {
        const existingCase = db.cases.find(c => c.id == id);
        officeNo = existingCase ? (existingCase.officeNo || '-') : '-';
    } else {
        const maxNo = db.cases.reduce((max, c) => Math.max(max, parseInt(c.officeNo || 0)), 0);
        officeNo = maxNo + 1;
    }

    // 🔴 بخش جاافتاده: دریافت مبلغ و حذفِ کاماها
    const rawPrice = convertToEnglishNumbers(document.getElementById('casePrice').value); // <--- این خط جا افتاده بود
    const cleanPrice = rawPrice.replace(/,/g, ''); // <--- این خط جا افتاده بود

    const item = {
        id: id || Date.now(),
        officeNo: officeNo,
        name: document.getElementById('caseName').value,
        mobile: convertToEnglishNumbers(document.getElementById('caseMobile').value),
        national: convertToEnglishNumbers(document.getElementById('caseNational').value),
        birthDate: convertToEnglishNumbers(document.getElementById('caseBirth').value),

        address: document.getElementById('caseAddress').value,
        title: document.getElementById('caseTitle').value,
        type: document.getElementById('caseType').value,
        status: document.getElementById('caseStatus').value,
        branch: document.getElementById('caseBranch').value,
        archiveNo: convertToEnglishNumbers(document.getElementById('caseArchiveNo').value),
        opponent: document.getElementById('caseOpponent').value,
        
        contract: convertToEnglishNumbers(document.getElementById('caseContract').value),
        totalPrice: cleanPrice, // حالا این متغیر تعریف شده و ارور نمی‌دهد
        
        // دادسرا
        hasProsecutor: document.getElementById('caseHasProsecutor').checked,
        prosecutorBranch: document.getElementById('caseProsecutorBranch').value,
        prosecutorArchive: convertToEnglishNumbers(document.getElementById('caseProsecutorArchive').value),
        // اجرای احکام
        hasExecution: document.getElementById('caseHasExecution').checked,
        executionBranch: document.getElementById('caseExecutionBranch').value,
        executionArchive: convertToEnglishNumbers(document.getElementById('caseExecutionArchive').value),
        // سایر
        tags: document.getElementById('caseTags').value,
        notes: document.getElementById('caseNotes').value,
        updatedAt: new Date().toLocaleDateString('fa-IR')
    };
    
    if (id) {
        const idx = db.cases.findIndex(c => c.id == id);
        if (idx >= 0) db.cases[idx] = item;
    } else {
        db.cases.unshift(item);
    }
    
    closeModal('caseModal');
    refreshAll();
    await saveData('cases', item);
    
    Swal.fire({ icon: 'success', title: `ذخیره شد | شماره دفتر: ${officeNo}`, timer: 2000, showConfirmButton: false });
}

async function deleteCase(id) {
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف پرونده',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله، حذف شود',
        cancelButtonText: 'انصراف',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.cases = db.cases.filter(c => c.id != id);
        refreshAll();
        await saveData();
    }
}

function showCaseDetail(id) {
    const c = db.cases.find(x => x.id == id);
    if (!c) return;
    
    const tags = c.tags ? c.tags.split(',').filter(Boolean).map(t => 
        `<span class="tag">${t.trim()}</span>`
    ).join('') : '<span class="text-gray-400">-</span>';
    
    // Calculate finances
    const finances = db.finance.filter(f => f.caseId == id);
    const income = finances.filter(f => f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
    const expense = finances.filter(f => f.type === 'expense').reduce((a, b) => a + Number(b.amount), 0);
    
    document.getElementById('caseDetailContent').innerHTML = `
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6 pb-6 border-b border-gray-100 dark:border-dark-800">
            <div class="col-span-2 md:col-span-1">
                <p class="text-xs text-gray-400 mb-1">موکل</p>
                <p class="font-bold text-xl text-gray-800 dark:text-white">${c.name}</p>
            </div>
            <div>
                <p class="text-xs text-gray-400 mb-1">تماس</p>
                <p class="font-mono">${c.mobile}</p>
            </div>
            <div>
                <p class="text-xs text-gray-400 mb-1">کد ملی</p>
                <p class="font-mono">${c.national || '-'}</p>
            </div>
            <div>
                <p class="text-xs text-gray-400 mb-1">تولد</p>
                <p class="font-mono">${c.birthDate || '-'}</p>
            </div>
        </div>
        
        <div class="grid grid-cols-2 md:grid-cols-4 gap-6 mb-6 pb-6 border-b border-gray-100 dark:border-dark-800">
            <div class="col-span-2">
                <p class="text-xs text-gray-400 mb-1">عنوان پرونده</p>
                <p class="font-bold text-primary-600 dark:text-gold-500">${c.title}</p>
            </div>
            <div>
                <p class="text-xs text-gray-400 mb-1">نوع</p>
                <p>${c.type}</p>
            </div>
            <div>
                <p class="text-xs text-gray-400 mb-1">وضعیت</p>
                <span class="${c.status === 'جاری' ? 'badge-success' : 'badge-danger'} px-3 py-1 rounded">${c.status}</span>
            </div>
            <div>
                <p class="text-xs text-gray-400 mb-1">شعبه</p>
                <p>${c.branch || '-'}</p>
            </div>
            <div>
                <p class="text-xs text-gray-400 mb-1">طرف دعوی</p>
                <p>${c.opponent || '-'}</p>
            </div>
            <div>
                <p class="text-xs text-gray-400 mb-1">شماره قرارداد</p>
                <p class="font-mono bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 px-2 py-1 rounded inline-block">${c.contract || '-'}</p>
            </div>
            <div>
                <p class="text-xs text-gray-400 mb-1">آدرس</p>
                <p class="text-sm">${c.address || '-'}</p>
            </div>
        </div>
        
        <div class="grid grid-cols-3 gap-4 mb-6 pb-6 border-b border-gray-100 dark:border-dark-800">
            <div class="card p-4 text-center">
                <p class="text-xs text-gray-400 mb-1">دریافتی</p>
                <p class="font-mono font-bold text-emerald-600" dir="ltr">${income.toLocaleString()}</p>
            </div>
            <div class="card p-4 text-center">
                <p class="text-xs text-gray-400 mb-1">هزینه</p>
                <p class="font-mono font-bold text-red-600" dir="ltr">${expense.toLocaleString()}</p>
            </div>
            <div class="card p-4 text-center">
                <p class="text-xs text-gray-400 mb-1">تراز</p>
                <p class="font-mono font-bold ${income - expense >= 0 ? 'text-emerald-600' : 'text-red-600'}" dir="ltr">${(income - expense).toLocaleString()}</p>
            </div>
        </div>
        
        <div class="mb-6">
            <p class="text-xs text-gray-400 mb-2">تگ‌ها</p>
            <div class="flex flex-wrap gap-2">${tags}</div>
        </div>
        
        <div>
            <p class="text-xs text-gray-400 mb-2">یادداشت</p>
            <div class="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-xl border border-amber-100 dark:border-amber-900/30">
                <p class="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">${c.notes || 'یادداشتی ثبت نشده'}</p>
            </div>
        </div>
    `;
    
    openModal('caseDetailModal');
}

// ═══════════════════════════════════════════════════
// Schedule
// ═══════════════════════════════════════════════════
function renderSchedule() {
    let scheduleShowDays = 30;
    const search = document.getElementById('searchSchedule')?.value.toLowerCase() || '';
    const labelFilter = document.getElementById('filterScheduleLabel')?.value || '';
    const today = getTodayPersian();
    
    const filtered = db.schedule.filter(s => {
        if (search && !JSON.stringify(s).toLowerCase().includes(search)) return false;
        if (labelFilter && s.label !== labelFilter) return false;
        return true;
    }).sort((a, b) => {
        const dateCompare = comparePersianDates(a.date, b.date);
        if (dateCompare !== 0) return dateCompare;
        return (a.time || '').localeCompare(b.time || '');
    });
    
    const todayItems = filtered.filter(s => comparePersianDates(s.date, today) === 0);
    const upcomingItems = filtered.filter(s => {
        const daysUntil = getDaysUntil(s.date);
        return daysUntil > 0 && daysUntil <= scheduleShowDays;
    });
    const pastItems = filtered.filter(s => comparePersianDates(s.date, today) < 0).reverse().slice(0, 10);
    
    // خلاصه
    const totalUpcoming = filtered.filter(s => getDaysUntil(s.date) > 0).length;
    const thisWeek = filtered.filter(s => {
        const d = getDaysUntil(s.date);
        return d >= 0 && d <= 7;
    }).length;
    
    document.getElementById('scheduleSummary').innerHTML = `
        <div class="flex items-center gap-4 text-xs mb-4">
            <span class="px-2 py-1 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded">
                📅 این هفته: <b>${thisWeek}</b>
            </span>
            <span class="px-2 py-1 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded">
                📊 کل آینده: <b>${totalUpcoming}</b>
            </span>
        </div>
    `;
    
    document.getElementById('todayScheduleList').innerHTML = renderScheduleItems(todayItems, 'today');
    document.getElementById('upcomingScheduleList').innerHTML = renderScheduleItems(upcomingItems, 'upcoming') + 
        (totalUpcoming > upcomingItems.length ? `
            <button onclick="loadMoreSchedule()" class="w-full py-2 text-sm text-primary-600 dark:text-gold-500 hover:bg-gray-50 dark:hover:bg-dark-800 rounded-lg transition">
                <i class="fas fa-plus-circle ml-1"></i> نمایش ${scheduleShowDays} روز بیشتر
            </button>
        ` : '');
    document.getElementById('pastScheduleList').innerHTML = renderScheduleItems(pastItems, 'past');
}

function loadMoreSchedule() {
    scheduleShowDays += 30;
    renderSchedule();
}

function renderScheduleItems(items, type) {
    if (!items.length) {
        return `<p class="text-center text-gray-400 py-4">${type === 'today' ? 'برنامه‌ای برای امروز نیست' : 'موردی نیست'}</p>`;
    }
    
    return items.map((s, i) => {
        const cs = s.caseId ? db.cases.find(c => c.id == s.caseId) : null;
        const labelColors = {
            'جلسه': 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
            'دادگاه': 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
            'تنظیم': 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
            'پیگیری': 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400'
        };
        
        const idx = db.schedule.indexOf(s);
        const today = getTodayPersian();
        const daysLeft = getDaysUntil(s.date);
        const dayName = getPersianDayName(s.date);
        
        let daysLeftText = '';
        let daysLeftClass = '';
        if (daysLeft === 0) {
            daysLeftText = '📍 امروز';
            daysLeftClass = 'text-red-600 dark:text-red-400 font-bold';
        } else if (daysLeft === 1) {
            daysLeftText = '⏰ فردا';
            daysLeftClass = 'text-orange-600 dark:text-orange-400 font-bold';
        } else if (daysLeft > 0) {
            daysLeftText = `${daysLeft} روز مانده`;
            daysLeftClass = 'text-emerald-600 dark:text-emerald-400';
        } else {
            daysLeftText = `${Math.abs(daysLeft)} روز قبل`;
            daysLeftClass = 'text-gray-400';
        }
        
        // ساخت لینک گوگل کلندر
        const gDate = shamsiToMiladi(s.date);
        let googleLink = '#';
        if (gDate) {
            const pad = (n) => n < 10 ? '0' + n : n;
            // تنظیم زمان شروع و پایان (یک ساعت)
            const timeParts = s.time ? s.time.split(':') : ['09', '00'];
            gDate.setHours(parseInt(timeParts[0]), parseInt(timeParts[1]));
            const startISO = gDate.toISOString().replace(/-|:|\.\d\d\d/g, "");
            gDate.setHours(gDate.getHours() + 1);
            const endISO = gDate.toISOString().replace(/-|:|\.\d\d\d/g, "");
            
            const title = encodeURIComponent(`وکیل‌یار: ${s.client || 'جلسه'} - ${s.label || ''}`);
            const details = encodeURIComponent(`${s.desc || ''}\n\nپرونده: ${cs ? cs.name : '-'}`);
            
            googleLink = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${title}&dates=${startISO}/${endISO}&details=${details}`;
        }
        return `
            <div class="card p-3 ${s.is_done ? 'opacity-50' : ''} transition group">
                <div class="flex items-start gap-3">
                    <label class="cursor-pointer mt-1">
                        <input type="checkbox" class="hidden" onchange="toggleScheduleDone(${idx})" ${s.is_done ? 'checked' : ''}>
                        <div class="w-5 h-5 rounded-full border-2 ${s.is_done ? 'bg-emerald-500 border-emerald-500' : 'border-gray-300 dark:border-gray-600'} flex items-center justify-center transition">
                            ${s.is_done ? '<i class="fas fa-check text-white text-[10px]"></i>' : ''}
                        </div>
                    </label>
                    
                    <div class="flex-1 min-w-0 cursor-pointer" onclick="openScheduleModal(${idx})">
                        <div class="flex items-center gap-2 mb-1">
                            <h4 class="font-bold text-gray-800 dark:text-white text-sm ${s.is_done ? 'line-through' : ''}">${s.client || 'بدون نام'}</h4>
                            ${s.label ? `<span class="${labelColors[s.label] || 'bg-gray-100 text-gray-700'} text-[10px] px-1.5 py-0.5 rounded">${s.label}</span>` : ''}
                        </div>
                        <p class="text-xs text-gray-500 dark:text-gray-400 mb-1 truncate">${s.desc || '-'}</p>
                        ${cs ? `<p class="text-[10px] text-primary-600 dark:text-gold-500"><i class="fas fa-folder ml-1"></i> ${cs.name} ${cs.archiveNo ? '| 📁' + cs.archiveNo : ''}</p>` : ''}
                        ${s.result ? `<p class="text-[10px] text-emerald-600 mt-1"><i class="fas fa-check-double ml-1"></i> ${s.result}</p>` : ''}
                    </div>
                    
                    <div class="text-left shrink-0">
                        <p class="text-xs font-bold text-gray-800 dark:text-white">${s.date}</p>
                        <p class="text-[10px] text-gray-400">${dayName} - ${s.time}</p>
                        <p class="text-[10px] ${daysLeftClass}">${daysLeftText}</p>
                    </div>
                    <a href="${googleLink}" target="_blank" onclick="event.stopPropagation()" class="p-1 opacity-0 group-hover:opacity-100 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded transition mr-1" title="افزودن به گوگل">
                        <i class="fab fa-google text-blue-500 text-xs"></i>
                    </a>
                    <button onclick="event.stopPropagation(); deleteSchedule(${idx})" class="p-1 opacity-0 group-hover:opacity-100 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition">
                        <i class="fas fa-trash text-red-400 text-xs"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function togglePastSchedule() {
    const list = document.getElementById('pastScheduleList');
    const icon = document.getElementById('pastScheduleIcon');
    list.classList.toggle('hidden');
    icon.classList.toggle('fa-chevron-down');
    icon.classList.toggle('fa-chevron-up');
}

function suggestClients(input) {
    const val = input.value.toLowerCase();
    const box = document.getElementById('clientSuggestions');
    
    if (val.length < 1) {
        box.classList.add('hidden');
        return;
    }
    
    const clients = [...new Set(db.cases.map(c => c.name))];
    const matches = clients.filter(n => n.toLowerCase().includes(val));
    
    if (matches.length) {
        box.innerHTML = matches.map(name => `
            <div class="p-3 hover:bg-gray-50 dark:hover:bg-dark-800 cursor-pointer text-sm" onclick="selectClient('${name}')">${name}</div>
        `).join('');
        box.classList.remove('hidden');
    } else {
        box.classList.add('hidden');
    }
}

function selectClient(name) {
    document.getElementById('scheduleClient').value = name;
    document.getElementById('clientSuggestions').classList.add('hidden');
}

function openScheduleModal(idx = null) {
    document.getElementById('scheduleForm').reset();
    document.getElementById('scheduleId').value = '';
    document.getElementById('scheduleDate').value = new Date().toLocaleDateString('fa-IR');
    document.getElementById('scheduleModalTitle').innerHTML = '<i class="fas fa-calendar-plus ml-2"></i> برنامه جدید';
    updateCaseSelects();
    
    if (idx !== null && db.schedule[idx]) {
        const s = db.schedule[idx];
        document.getElementById('scheduleModalTitle').innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش برنامه';
        document.getElementById('scheduleId').value = idx;
        document.getElementById('scheduleDate').value = s.date || '';
        document.getElementById('scheduleTime').value = s.time || '';
        document.getElementById('scheduleClient').value = s.client || '';
        document.getElementById('scheduleCaseId').value = s.caseId || '';
        document.getElementById('scheduleLabel').value = s.label || '';
        document.getElementById('scheduleDesc').value = s.desc || '';
        document.getElementById('scheduleResult').value = s.result || '';
    }
    
    openModal('scheduleModal');
}

async function saveSchedule(e) {
    e.preventDefault();
    
    const idx = document.getElementById('scheduleId').value;
    const item = {
        id: idx !== '' ? db.schedule[idx].id : Date.now(),
        date: convertToEnglishNumbers(document.getElementById('scheduleDate').value),
        time: document.getElementById('scheduleTime').value,
        client: document.getElementById('scheduleClient').value,
        caseId: document.getElementById('scheduleCaseId').value,
        label: document.getElementById('scheduleLabel').value,
        desc: document.getElementById('scheduleDesc').value,
        result: document.getElementById('scheduleResult').value,
        is_done: idx !== '' ? db.schedule[idx].is_done : false
    };
    
    // Add case name for Google Sheets
    if (item.caseId) {
        const cs = db.cases.find(c => c.id == item.caseId);
        if (cs) item.caseName = cs.name;
    }
    
    if (idx !== '') {
        db.schedule[idx] = item;
    } else {
        db.schedule.push(item);
    }
    
    closeModal('scheduleModal');
    refreshAll();
    await saveData('schedule', item);
    
    Swal.fire({ icon: 'success', title: 'ذخیره شد', timer: 1500, showConfirmButton: false });
}

async function toggleScheduleDone(idx) {
    db.schedule[idx].is_done = !db.schedule[idx].is_done;
    refreshAll();
    await saveData('schedule', db.schedule[idx]);
}

async function deleteSchedule(idx) {
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف برنامه',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.schedule.splice(idx, 1);
        refreshAll();
        await saveData();
    }
}

// ═══════════════════════════════════════════════════
// Finance
// ═══════════════════════════════════════════════════
function renderFinance() {
    const search = document.getElementById('searchFinance')?.value.toLowerCase() || '';
    const typeFilter = document.getElementById('filterFinanceType')?.value || '';
    
    const filtered = db.finance.filter(f => {
        if (search && !JSON.stringify(f).toLowerCase().includes(search)) return false;
        if (typeFilter && f.type !== typeFilter) return false;
        return true;
    });
    
    // Totals
    const income = db.finance.filter(f => f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
    const expense = db.finance.filter(f => f.type === 'expense').reduce((a, b) => a + Number(b.amount), 0);
    
    document.getElementById('totalIncome').textContent = income.toLocaleString();
    document.getElementById('totalExpense').textContent = expense.toLocaleString();
    document.getElementById('totalBalance').textContent = (income - expense).toLocaleString();
    
    // Table
    document.getElementById('financeTableBody').innerHTML = filtered.map((f, i) => {
        const cs = db.cases.find(c => c.id == f.caseId);
        const idx = db.finance.indexOf(f);
        
        return `
            <tr class="table-row">
                <td class="p-4 font-mono text-sm text-gray-500">${f.date}</td>
                <td class="p-4">
                    ${cs ? `<span class="font-medium text-gray-700 dark:text-gray-300">${cs.name}</span>` : '<span class="text-gray-400">بدون پرونده</span>'}
                </td>
                <td class="p-4">
                    <span class="${f.type === 'income' ? 'badge-success' : 'badge-danger'} px-2 py-1 rounded text-xs font-medium">
                        ${f.type === 'income' ? 'دریافت' : 'هزینه'}
                    </span>
                </td>
                <td class="p-4 font-mono font-bold ${f.type === 'income' ? 'text-emerald-600' : 'text-red-600'}" dir="ltr">
                    ${Number(f.amount).toLocaleString()}
                </td>
                <td class="p-4 text-sm text-gray-500 max-w-[200px] truncate">${f.desc || '-'}</td>
                <td class="p-4 text-center">
                    <button onclick="editFinance(${idx})" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-700 rounded-lg transition">
                        <i class="fas fa-edit text-gray-400"></i>
                    </button>
                    <button onclick="deleteFinance(${idx})" class="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition">
                        <i class="fas fa-trash text-red-400"></i>
                    </button>
                </td>
            </tr>
        `;
    }).join('') || '<tr><td colspan="6" class="p-8 text-center text-gray-400">تراکنشی یافت نشد</td></tr>';
}

function openFinanceModal(idx = null) {
    document.getElementById('financeForm').reset();
    document.getElementById('financeId').value = '';
    document.getElementById('financeDate').value = new Date().toLocaleDateString('fa-IR');
    document.getElementById('financeModalTitle').innerHTML = '<i class="fas fa-money-bill-wave ml-2"></i> تراکنش جدید';
    updateCaseSelects();
    
    if (idx !== null && db.finance[idx]) {
        const f = db.finance[idx];
        document.getElementById('financeModalTitle').innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش تراکنش';
        document.getElementById('financeId').value = idx;
        document.getElementById('financeCaseId').value = f.caseId || '';
        document.getElementById('financeType').value = f.type || 'income';
        document.getElementById('financeDate').value = f.date || '';
        document.getElementById('financeAmount').value = f.amount || '';
        document.getElementById('financeDesc').value = f.desc || '';
    }
    
    openModal('financeModal');
}

function editFinance(idx) {
    openFinanceModal(idx);
}

async function saveFinance(e) {
    e.preventDefault();
    
    const idx = document.getElementById('financeId').value;
    const item = {
        id: idx !== '' ? db.finance[idx].id : Date.now(),
        caseId: document.getElementById('financeCaseId').value,
        type: document.getElementById('financeType').value,
        date: convertToEnglishNumbers(document.getElementById('financeDate').value),
        amount: convertToEnglishNumbers(document.getElementById('financeAmount').value),
        desc: document.getElementById('financeDesc').value
    };
    
    // Add case name for Google Sheets
    if (item.caseId) {
        const cs = db.cases.find(c => c.id == item.caseId);
        if (cs) item.caseName = cs.name;
    }
    
    if (idx !== '') {
        db.finance[idx] = item;
    } else {
        db.finance.unshift(item);
    }
    
    closeModal('financeModal');
    refreshAll();
    await saveData('finance', item);
    
    Swal.fire({ icon: 'success', title: 'ذخیره شد', timer: 1500, showConfirmButton: false });
}

async function deleteFinance(idx) {
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف تراکنش',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.finance.splice(idx, 1);
        refreshAll();
        await saveData();
    }
}


// ═══════════════════════════════════════════════════
// Library
// ═══════════════════════════════════════════════════
function renderLibrary() {
    const search = document.getElementById('searchLibrary')?.value.toLowerCase() || '';
    
    const filtered = db.library.filter(l => {
        if (search && !l.title.toLowerCase().includes(search) && !(l.content || '').toLowerCase().includes(search)) return false;
        return true;
    });
    
    document.getElementById('libraryList').innerHTML = filtered.map(l => `
        <div onclick="viewLibrary(${l.id})" class="p-4 rounded-xl cursor-pointer transition border ${currentLibraryId == l.id ? 'bg-primary-50 dark:bg-primary-900/20 border-primary-500 dark:border-gold-500' : 'bg-gray-50 dark:bg-dark-800 border-transparent hover:border-gray-200 dark:hover:border-dark-700'}">
            <div class="flex items-start justify-between mb-2">
                <h4 class="font-bold text-gray-800 dark:text-white text-sm">${l.title}</h4>
                <span class="tag text-xs">${l.type}</span>
            </div>
            <p class="text-xs text-gray-400 line-clamp-2">${(l.content || '').substring(0, 100)}...</p>
        </div>
    `).join('') || '<p class="text-center text-gray-400 py-8">متنی یافت نشد</p>';
}

function viewLibrary(id) {
    const l = db.library.find(x => x.id == id);
    if (!l) return;
    
    currentLibraryId = id;
    
    document.getElementById('libraryEmpty').classList.add('hidden');
    document.getElementById('libraryContent').classList.remove('hidden');
    
    document.getElementById('libraryViewTitle').textContent = l.title;
    document.getElementById('libraryViewType').textContent = l.type;
    document.getElementById('libraryViewContent').textContent = l.content || '';
    
    renderLibrary();
}

function openLibraryModal(id = null) {
    document.getElementById('libraryForm').reset();
    document.getElementById('libraryId').value = '';
    document.getElementById('libraryModalTitle').innerHTML = '<i class="fas fa-file-alt ml-2"></i> متن جدید';
    
    if (id) {
        const l = db.library.find(x => x.id == id);
        if (l) {
            document.getElementById('libraryModalTitle').innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش متن';
            document.getElementById('libraryId').value = l.id;
            document.getElementById('libraryTitle').value = l.title || '';
            document.getElementById('libraryType').value = l.type || 'لایحه';
            // 👇 اینجا تغییر کرد
            document.getElementById('libraryInputText').value = l.content || ''; 
        }
    }
    
    openModal('libraryModal');
}

function editLibrary() {
    if (currentLibraryId) {
        openLibraryModal(currentLibraryId);
    }
}

async function saveLibrary(e) {
    e.preventDefault();
    
    const id = document.getElementById('libraryId').value;
    const item = {
        id: id || Date.now(),
        title: document.getElementById('libraryTitle').value,
        type: document.getElementById('libraryType').value,
        // 👇 اینجا تغییر کرد
        content: document.getElementById('libraryInputText').value 
    };
    
    if (id) {
        const idx = db.library.findIndex(l => l.id == id);
        if (idx >= 0) db.library[idx] = item;
    } else {
        db.library.unshift(item);
    }
    
    closeModal('libraryModal');
    currentLibraryId = item.id;
    refreshAll();
    viewLibrary(item.id);
    await saveData('library', item);
    
    Swal.fire({ icon: 'success', title: 'ذخیره شد', timer: 1500, showConfirmButton: false });
}

async function deleteLibrary() {
    if (!currentLibraryId) return;
    
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف متن',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.library = db.library.filter(l => l.id != currentLibraryId);
        currentLibraryId = null;
        
        document.getElementById('libraryEmpty').classList.remove('hidden');
        document.getElementById('libraryContent').classList.add('hidden');
        
        refreshAll();
        await saveData();
    }
}

async function copyLibraryContent() {
    const content = document.getElementById('libraryViewContent').textContent;
    await navigator.clipboard.writeText(content);
    
    Swal.fire({
        icon: 'success',
        title: 'کپی شد!',
        timer: 1000,
        showConfirmButton: false,
        position: 'bottom-end',
        toast: true
    });
}
// ═══════════════════════════════════════════════════
// Modal Functions
// ═══════════════════════════════════════════════════
function openModal(id) {
    document.getElementById(id).classList.add('active');
    document.body.style.overflow = 'hidden';
}

function closeModal(id) {
    document.getElementById(id).classList.remove('active');
    document.body.style.overflow = '';
}

function closeModalOnOverlay(event, id) {
    if (event.target === event.currentTarget) {
        closeModal(id);
    }
}

function openQuickAdd() {
    openModal('quickAddModal');
}

// ═══════════════════════════════════════════════════
// Navigation & Theme
// ═══════════════════════════════════════════════════
function setView(view, element = null) {
    // Hide all views
    document.querySelectorAll('.page-view').forEach(v => v.classList.add('hidden'));
    
    // Show selected view
    document.getElementById('view-' + view).classList.remove('hidden');
    
    // Update sidebar
    document.querySelectorAll('.sidebar-item').forEach(item => item.classList.remove('active'));
    if (element) {
        element.classList.add('active');
    } else {
        document.querySelectorAll('.sidebar-item').forEach(item => {
            if (item.textContent.includes(getViewTitle(view))) {
                item.classList.add('active');
            }
        });
    }
    
    // Update page title
    document.getElementById('pageTitle').textContent = getViewTitle(view);
    
    // Close sidebar on mobile
    closeSidebar();
}

function getViewTitle(view) {
    const titles = {
        'dashboard': 'داشبورد',
        'cases': 'پرونده‌ها',
        'schedule': 'تقویم کاری',
        'finance': 'امور مالی',
        'library': 'بانک لوایح'
    };
    return titles[view] || view;
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    sidebar.classList.toggle('translate-x-full');
    overlay.classList.toggle('hidden');
}

function closeSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebarOverlay');
    
    if (window.innerWidth < 1024) {
        sidebar.classList.add('translate-x-full');
        overlay.classList.add('hidden');
    }
}

function toggleTheme() {
    document.documentElement.classList.toggle('dark');
    const isDark = document.documentElement.classList.contains('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    
    // Update charts colors
    if (charts.cases || charts.finance) {
        updateChartsTheme();
    }
}

function updateChartsTheme() {
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#94a3b8' : '#64748b';
    const gridColor = isDark ? '#1e293b' : '#f1f5f9';
    
    if (charts.cases) {
        charts.cases.options.plugins.legend.labels.color = textColor;
        charts.cases.update();
    }
    
    if (charts.finance) {
        charts.finance.options.plugins.legend.labels.color = textColor;
        charts.finance.options.scales.x.grid.color = gridColor;
        charts.finance.options.scales.x.ticks.color = textColor;
        charts.finance.options.scales.y.grid.color = gridColor;
        charts.finance.options.scales.y.ticks.color = textColor;
        charts.finance.update();
    }
}

// ═══════════════════════════════════════════════════
// Logout
// ═══════════════════════════════════════════════════
async function logout() {
    const result = await Swal.fire({
        icon: 'question',
        title: 'خروج از سیستم',
        text: 'آیا می‌خواهید خارج شوید؟',
        showCancelButton: true,
        confirmButtonText: 'بله، خروج',
        cancelButtonText: 'انصراف'
    });
    
    if (result.isConfirmed) {
        await fetch('api.php?action=logout');
        location.reload();
    }
}

// ═══════════════════════════════════════════════════
// Keyboard Shortcuts
// ═══════════════════════════════════════════════════
document.addEventListener('keydown', (e) => {
    // ESC to close modals
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal-overlay.active').forEach(modal => {
            modal.classList.remove('active');
        });
        document.body.style.overflow = '';
    }
    
    // Ctrl+K for quick search
    if (e.ctrlKey && e.key === 'k') {
        e.preventDefault();
        openQuickAdd();
    }
});

// ═══════════════════════════════════════════════════
// Responsive Handler
// ═══════════════════════════════════════════════════
window.addEventListener('resize', () => {
    if (window.innerWidth >= 1024) {
        document.getElementById('sidebar').classList.remove('translate-x-full');
        document.getElementById('sidebarOverlay').classList.add('hidden');
    }
});


async function testGoogleSheetConnection() {
    try {
        const res = await fetch('api.php?action=test_google');
        const data = await res.json();
        
        if (data.success) {
            Swal.fire({
                icon: 'success',
                title: 'متصل است! ✅',
                text: 'اتصال به گوگل شیت برقرار است',
                confirmButtonText: 'عالی'
            });
        } else {
            Swal.fire({
                icon: 'error',
                title: 'متصل نیست ❌',
                text: data.message || 'مشکل در اتصال به گوگل شیت',
                confirmButtonText: 'باشه'
            });
        }
    } catch (err) {
        Swal.fire({
            icon: 'error',
            title: 'خطا',
            text: 'مشکل در ارتباط با سرور',
            confirmButtonText: 'باشه'
        });
    }
}
// ═══════════════════════════════════════════════════
// تبدیل خودکار اعداد در inputها
// ═══════════════════════════════════════════════════
document.addEventListener('input', function(e) {
    const target = e.target;
    
    // فقط برای inputهای تاریخ و عدد
    if (target.id === 'scheduleDate' || 
        target.id === 'financeDate' || 
        target.id === 'caseBirth' ||
        target.id === 'financeAmount' ||
        target.id === 'caseNational' ||
        target.id === 'caseMobile' ||
        target.id === 'caseContract') {
        
        const start = target.selectionStart;
        const end = target.selectionEnd;
        target.value = convertToEnglishNumbers(target.value);
        target.setSelectionRange(start, end);
    }
});

// ═══════════════════════════════════════════════════
// مقایسه تاریخ شمسی
// ═══════════════════════════════════════════════════
function comparePersianDates(date1, date2) {
    // تبدیل به انگلیسی برای مقایسه
    const d1 = convertToEnglishNumbers(date1 || '');
    const d2 = convertToEnglishNumbers(date2 || '');
    
    // تبدیل به فرمت قابل مقایسه: 1403/09/15 → 14030915
    const normalize = (d) => {
        const parts = d.split('/');
        if (parts.length !== 3) return 0;
        return parseInt(parts[0]) * 10000 + parseInt(parts[1]) * 100 + parseInt(parts[2]);
    };
    
    return normalize(d1) - normalize(d2);
}

function getTodayPersian() {
    return convertToEnglishNumbers(new Date().toLocaleDateString('fa-IR'));
}

// ═══════════════════════════════════════════════════
// Toggle Functions
// ═══════════════════════════════════════════════════
function toggleProsecutor() {
    const checked = document.getElementById('caseHasProsecutor').checked;
    document.getElementById('prosecutorFields').classList.toggle('hidden', !checked);
}

function toggleExecution() {
    const checked = document.getElementById('caseHasExecution').checked;
    document.getElementById('executionFields').classList.toggle('hidden', !checked);
}
// ═══════════════════════════════════════════════════
// توابع کمکی تاریخ
// ═══════════════════════════════════════════════════
function getDaysUntil(targetDate) {
    const today = getTodayPersian();
    const t = convertToEnglishNumbers(today).split('/').map(Number);
    const d = convertToEnglishNumbers(targetDate || '').split('/').map(Number);
    
    if (t.length !== 3 || d.length !== 3) return 0;
    
    // تبدیل تقریبی به روز (برای مقایسه کافیه)
    const todayDays = t[0] * 365 + t[1] * 30 + t[2];
    const targetDays = d[0] * 365 + d[1] * 30 + d[2];
    
    return targetDays - todayDays;
}

function getPersianDayName(dateStr) {
    const days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
    
    try {
        const d = convertToEnglishNumbers(dateStr || '').split('/').map(Number);
        if (d.length !== 3) return '';
        
        // تبدیل شمسی به میلادی (تقریبی)
        const gYear = d[0] + 621;
        const gMonth = d[1] <= 6 ? d[1] + 3 : d[1] - 6;
        const gDay = d[2];
        
        const date = new Date(gYear, gMonth - 1, gDay);
        return days[date.getDay()];
    } catch {
        return '';
    }
}
function searchCases(input, selectId) {
    const val = input.value.toLowerCase();
    const select = document.getElementById(selectId);
    const options = select.querySelectorAll('option');
    
    options.forEach(opt => {
        if (opt.value === '' || opt.textContent.toLowerCase().includes(val)) {
            opt.style.display = '';
        } else {
            opt.style.display = 'none';
        }
    });
}
// ═══════════════════════════════════════════════════
// تبدیل تاریخ شمسی به میلادی (برای گوگل و اعلان‌ها)
// ═══════════════════════════════════════════════════
function shamsiToMiladi(shamsiDate) {
    if(!shamsiDate) return null;
    const jalali = shamsiDate.split('/').map(Number);
    // الگوریتم ساده شده تبدیل (نیاز به کتابخانه کامل ندارد)
    // برای دقت ۱۰۰٪ در پروژه‌های بزرگ بهتر است از کتابخانه jalaali-js استفاده شود
    // اما این تابع برای کار راه اندازی کافیست
    let jy = jalali[0], jm = jalali[1], jd = jalali[2];
    let gy = (jy <= 979) ? 621 : 1600;
    jy -= (jy <= 979) ? 0 : 979;
    let days = (365 * jy) + ((parseInt(jy / 33)) * 8) + parseInt(((jy % 33) + 3) / 4) + 78 + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    gy += 400 * parseInt(days / 146097);
    days %= 146097;
    if (days > 36524) {
        gy += 100 * parseInt(--days / 36524);
        days %= 36524;
        if (days >= 365) days++;
    }
    gy += 4 * parseInt((days) / 1461);
    days %= 1461;
    gy += parseInt((days - 1) / 365);
    if (days > 365) days = (days - 1) % 365;
    let gd = days + 1;
    let sal_a = [0, 31, ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm;
    for (gm = 0; gm < 13; gm++) {
        let v = sal_a[gm];
        if (gd <= v) break;
        gd -= v;
    }
    return new Date(gy, gm - 1, gd);
}
// ═══════════════════════════════════════════════════
// سیستم هوشمند اعلان‌ها (Notifications)
// ═══════════════════════════════════════════════════

// درخواست دسترسی برای ارسال نوتیفیکیشن
function requestNotificationPermission() {
    if (!("Notification" in window)) {
        alert("مرورگر شما از اعلان‌ها پشتیبانی نمی‌کند");
    } else if (Notification.permission !== "denied") {
        Notification.requestPermission();
    }
}

// بررسی دوره‌ای برای یادآوری‌ها
function checkReminders() {
    if (Notification.permission !== "granted") return;

    const now = new Date();
    
    db.schedule.forEach(s => {
        if (s.is_done) return; // اگر انجام شده، یادآوری نکن
        
        const eventDate = shamsiToMiladi(s.date);
        if (!eventDate) return;
        
        // تنظیم ساعت
        const timeParts = s.time ? s.time.split(':') : ['09', '00'];
        eventDate.setHours(parseInt(timeParts[0]), parseInt(timeParts[1]), 0);
        
        const diffMs = eventDate - now;
        const diffHours = diffMs / (1000 * 60 * 60);

        // کلیدهای یکتا برای جلوگیری از تکرار اعلان
        const id24 = `notif_24_${s.id}`;
        const id1 = `notif_1_${s.id}`;

        // یادآوری ۲۴ ساعت قبل (بین ۲۳ تا ۲۴ ساعت مانده)
        if (diffHours > 23 && diffHours < 24.1 && !localStorage.getItem(id24)) {
            sendNotification(`📅 یادآوری فردا: ${s.client}`, `فردا ساعت ${s.time} برنامه "${s.label}" دارید.`);
            localStorage.setItem(id24, 'sent');
        }

        // یادآوری ۱ ساعت قبل (بین ۵۰ تا ۶۰ دقیقه مانده)
        if (diffHours > 0.8 && diffHours < 1.1 && !localStorage.getItem(id1)) {
            const urgency = s.label === 'دادگاه' ? '🚨 مهم: ' : '⏰ ';
            sendNotification(`${urgency}یک ساعت تا جلسه`, `ساعت ${s.time} با ${s.client} - ${s.desc || ''}`);
            localStorage.setItem(id1, 'sent');
        }
        
        // یادآوری مهلت‌های قانونی (اگر تاریخ گذشته و انجام نشده)
        if (diffHours < 0 && diffHours > -24 && !localStorage.getItem(`overdue_${s.id}`)) {
             if(s.label === 'دادگاه' || s.label === 'تنظیم') {
                 sendNotification(`⚠️ مهلت گذشت!`, `برنامه ${s.client} در تاریخ ${s.date} انجام نشده است.`);
                 localStorage.setItem(`overdue_${s.id}`, 'sent');
             }
        }
    });
}

function sendNotification(title, body) {
    const notif = new Notification(title, {
        body: body,
        icon: 'https://img.icons8.com/fluency/96/law.png',
        dir: 'rtl'
    });
}

// فعال‌سازی بررسی‌کننده (هر ۵ دقیقه چک می‌کند)
setInterval(checkReminders, 300000); 

// در زمان لود صفحه هم یک بار درخواست دسترسی بده
window.addEventListener('load', () => {
    if (Notification.permission === "default") {
        setTimeout(requestNotificationPermission, 2000);
    }
    // یک بار چک کن
    checkReminders();
});
function openDebtorsModal() {
    let totalAllDebt = 0;
    let debtorsHTML = '';
    
    const debtors = db.cases.map(c => {
        // 👇 تغییر مهم: استفاده از totalPrice به جای contract
        // اگر مبلغی وارد نشده بود، صفر در نظر بگیر
        const contractAmount = parseInt(c.totalPrice) || 0;
        
        if (contractAmount === 0) return null;
        
        const paidAmount = db.finance
            .filter(f => f.caseId == c.id && f.type === 'income')
            .reduce((sum, f) => {
                const amount = parseInt(convertToEnglishNumbers(f.amount).replace(/,/g, '')) || 0;
                return sum + amount;
            }, 0);
            
        const debt = contractAmount - paidAmount;
        
        if (debt > 0) {
            return {
                id: c.id,
                name: c.name,
                title: c.title,
                contract: contractAmount,
                paid: paidAmount,
                debt: debt,
                mobile: c.mobile
            };
        }
        return null;
    })
    .filter(item => item !== null)
    .sort((a, b) => b.debt - a.debt);

    if (debtors.length === 0) {
        debtorsHTML = `
            <div class="text-center py-8 text-gray-400">
                <i class="fas fa-check-circle text-4xl mb-3 text-emerald-500"></i>
                <p>هیچ بدهکاری یافت نشد. تمام حساب‌ها تسویه شده‌اند!</p>
            </div>
        `;
    } else {
        debtorsHTML = debtors.map(d => {
            totalAllDebt += d.debt;
            const percent = Math.min(100, Math.round((d.paid / d.contract) * 100));
            
            return `
            <div class="card p-4 border-r-4 border-r-orange-500 hover:bg-gray-50 dark:hover:bg-dark-800 transition">
                <div class="flex justify-between items-start mb-2">
                    <div>
                        <h4 class="font-bold text-gray-800 dark:text-white">${d.name}</h4>
                        <p class="text-xs text-gray-500">${d.title}</p>
                    </div>
                    <div class="text-left">
                        <p class="text-xs text-gray-400 mb-1">مانده بدهی</p>
                        <p class="font-bold text-lg text-orange-600 dark:text-orange-400 font-mono">${d.debt.toLocaleString()}</p>
                    </div>
                </div>
                
                <div class="flex justify-between text-xs text-gray-500 dark:text-gray-400 mb-1">
                    <span>کل قرارداد: ${d.contract.toLocaleString()}</span>
                    <span>پرداخت شده: ${d.paid.toLocaleString()}</span>
                </div>
                
                <div class="w-full bg-gray-200 dark:bg-dark-700 rounded-full h-2 overflow-hidden">
                    <div class="bg-emerald-500 h-2 rounded-full" style="width: ${percent}%"></div>
                </div>
                <div class="mt-3 flex justify-end">
                    <a href="tel:${d.mobile}" class="text-xs flex items-center gap-1 text-blue-600 bg-blue-50 px-2 py-1 rounded hover:bg-blue-100">
                        <i class="fas fa-phone"></i> پیگیری
                    </a>
                </div>
            </div>
            `;
        }).join('');
    }
    
    document.getElementById('totalDebtAmount').innerText = totalAllDebt.toLocaleString() + ' تومان';
    document.getElementById('debtorsListContent').innerHTML = debtorsHTML;
    
    openModal('debtorsModal');
}
// جداکننده هزارگان برای فیلد مبلغ پرونده
document.getElementById('casePrice').addEventListener('input', function(e) {
    // حذف هر چیزی جز عدد
    let val = e.target.value.replace(/,/g, '');
    val = convertToEnglishNumbers(val).replace(/[^\d]/g, '');
    
    // فرمت کردن
    if (val) {
        val = parseInt(val).toLocaleString();
    }
    e.target.value = val;
});







</script>

<?php endif; ?>

</body>
</html>