<?php
// api.php - API کامل با سینک گوگل شیت
error_reporting(0);
ini_set('display_errors', 0);
session_start();
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');

define('SECURE_ACCESS', true);
$config = require 'config.php';

// ========== توابع کمکی ==========
function response($success, $message = '', $data = null) {
    echo json_encode([
        'success' => $success,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

function getDB($path) {
    if (!file_exists($path)) {
        $dir = dirname($path);
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $default = ['cases' => [], 'finance' => [], 'library' => [], 'schedule' => []];
        file_put_contents($path, json_encode($default, JSON_UNESCAPED_UNICODE));
        return $default;
    }
    $content = file_get_contents($path);
    $data = json_decode($content, true);
    if (!$data) $data = ['cases' => [], 'finance' => [], 'library' => [], 'schedule' => []];
    if (!isset($data['schedule'])) $data['schedule'] = [];
    return $data;
}

function saveDB($path, $data) {
    $fp = fopen($path, 'c+');
    if (flock($fp, LOCK_EX)) {
        ftruncate($fp, 0);
        fwrite($fp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        fflush($fp);
        flock($fp, LOCK_UN);
        fclose($fp);
        return true;
    }
    fclose($fp);
    return false;
}

// ========== گوگل شیت ==========
function getGoogleToken($config) {
    if (empty($config['google']['refresh_token'])) return null;
    
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'client_id' => $config['google']['client_id'],
            'client_secret' => $config['google']['client_secret'],
            'refresh_token' => $config['google']['refresh_token'],
            'grant_type' => 'refresh_token'
        ]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    return $result['access_token'] ?? null;
}

function syncToGoogleSheet($type, $item, $config) {
    if (!$config['google']['enabled']) return;
    
    $token = getGoogleToken($config);
    if (!$token) return;
    
    $sheetId = $config['google']['sheet_id'];
    $ranges = [
        'cases' => 'Cases',
        'finance' => 'Finance',
        'schedule' => 'Schedule',
        'library' => 'Library'
    ];
    
    $range = $ranges[$type] ?? 'Sheet1';
    $values = [];
    
    switch ($type) {
        case 'cases':
            $values = [[
                $item['id'] ?? '',
                $item['name'] ?? '',
                $item['mobile'] ?? '',
                $item['national'] ?? '',
                $item['birthDate'] ?? '',
                $item['address'] ?? '',
                $item['title'] ?? '',
                $item['type'] ?? '',
                $item['status'] ?? '',
                $item['branch'] ?? '',
                $item['opponent'] ?? '',
                $item['contract'] ?? '',
                $item['tags'] ?? '',
                $item['notes'] ?? '',
                $item['updatedAt'] ?? '',
                date('Y-m-d H:i:s')
            ]];
            break;
            
        case 'finance':
            $values = [[
                $item['id'] ?? '',
                $item['caseId'] ?? '',
                $item['caseName'] ?? 'بدون پرونده',
                $item['type'] ?? '',
                $item['amount'] ?? '',
                $item['date'] ?? '',
                $item['desc'] ?? '',
                date('Y-m-d H:i:s')
            ]];
            break;
            
        case 'schedule':
            $values = [[
                $item['id'] ?? '',
                $item['date'] ?? '',
                $item['time'] ?? '',
                $item['client'] ?? '',
                $item['caseId'] ?? '',
                $item['label'] ?? '',
                $item['desc'] ?? '',
                $item['result'] ?? '',
                $item['is_done'] ? 'بله' : 'خیر',
                date('Y-m-d H:i:s')
            ]];
            break;
            
        case 'library':
            $values = [[
                $item['id'] ?? '',
                $item['title'] ?? '',
                $item['type'] ?? '',
                mb_substr($item['content'] ?? '', 0, 500),
                date('Y-m-d H:i:s')
            ]];
            break;
    }
    
    if (empty($values)) return;
    
    $url = "https://sheets.googleapis.com/v4/spreadsheets/{$sheetId}/values/{$range}!A1:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS";
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode(['values' => $values]),
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            "Authorization: Bearer {$token}"
        ],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10
    ]);
    curl_exec($ch);
    curl_close($ch);
}

// ========== مسیریابی ==========
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? $_POST['action'] ?? '';

// لاگین
if ($method === 'POST' && $action === 'login') {
    $password = $_POST['password'] ?? '';
    if ($password === $config['password']) {
        $_SESSION['logged_in'] = true;
        $_SESSION['login_time'] = time();
        response(true, 'ورود موفق');
    }
    response(false, 'رمز عبور اشتباه است');
}

// بررسی لاگین
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401);
    response(false, 'لطفاً وارد شوید');
}

// خروج
if ($action === 'logout') {
    session_destroy();
    response(true, 'خروج موفق');
}

// دریافت دیتا
if ($method === 'GET' && $action === 'get_data') {
    $data = getDB($config['db_path']);
    response(true, '', $data);
}

// ذخیره دیتا
if ($method === 'POST' && $action !== 'login') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (isset($input['db'])) {
        if (saveDB($config['db_path'], $input['db'])) {
            // سینک به گوگل شیت
            if (isset($input['syncType']) && isset($input['syncItem'])) {
                syncToGoogleSheet($input['syncType'], $input['syncItem'], $config);
            }
            response(true, 'ذخیره شد');
        }
        response(false, 'خطا در ذخیره');
    }
}

// تست اتصال گوگل شیت
if ($action === 'test_google') {
    $token = getGoogleToken($config);
    if ($token) {
        response(true, 'اتصال برقرار است');
    } else {
        response(false, 'توکن دریافت نشد - refresh_token را چک کنید');
    }
}
response(false, 'درخواست نامعتبر');