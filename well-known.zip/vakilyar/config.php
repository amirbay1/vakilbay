<?php
// config.php
defined('SECURE_ACCESS') or die('Access Denied');

return [
    // رمز عبور: admin (می‌تونی عوض کنی)
    'password' => 'admin',
    
    // تنظیمات گوگل شیت
    'google' => [
        'enabled'       => true,
        'sheet_id'      => '1ugWnww_Cx7e7BdoDFsfg5gsiP113Iiougw8Eu6reIH4',
        'client_id'     => '1031802114248-htsduhc2l1v2t4rre71fk9fnf1qlp25a.apps.googleusercontent.com',
        'client_secret' => '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',
        'refresh_token' => '1//04sxN4CA5BoYmCgYIARAAGAQSNwF-L9IrV53Yk1dDhFUjPoN4W-hHb8v52xyMSMInYi8dkK_tYIp8RAAky_2RhQG8cpKZcNDBZwY',
    ],
    
    // مسیر دیتابیس
    'db_path' => __DIR__ . '/db/database.json',
];