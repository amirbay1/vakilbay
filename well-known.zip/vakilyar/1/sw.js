// sw.js - Service Worker اصلاح شده (Network First)

const CACHE_NAME = 'vakilyar-v4.0'; // ورژن را تغییر دادم تا کش قبلی پاک شود
const urlsToCache = [
    './',
    './index.php',
    './app.js',
    './style.css',
    './img/vakilyar.png'
];

// 1. نصب و کش کردن فایل‌های اولیه
self.addEventListener('install', event => {
    self.skipWaiting(); // فوراً فعال شود
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Opened cache');
                return cache.addAll(urlsToCache);
            })
    );
});

// 2. مدیریت درخواست‌ها (بخش مهم تغییر کرده)
self.addEventListener('fetch', event => {
    const requestUrl = new URL(event.request.url);

    // الف) اگر درخواست مربوط به API است، اصلاً کش نکن (همیشه آنلاین)
    if (requestUrl.pathname.includes('api.php')) {
        return; // بگذار مرورگر کار خودش را بکند
    }

    // ب) برای بقیه فایل‌ها: استراتژی Network First
    // یعنی اول تلاش کن نسخه تازه را بگیری، اگر نشد نسخه قدیمی را نشان بده
    event.respondWith(
        fetch(event.request)
            .then(response => {
                // اگر پاسخ موفق بود، کش را هم آپدیت کن
                if (response && response.status === 200 && response.type === 'basic') {
                    const responseClone = response.clone();
                    caches.open(CACHE_NAME).then(cache => {
                        cache.put(event.request, responseClone);
                    });
                }
                return response;
            })
            .catch(() => {
                // اگر آفلاین بودیم یا سرور قطع بود، از کش بخوان
                return caches.match(event.request);
            })
    );
});

// 3. پاک کردن کش‌های قدیمی
self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (cacheName !== CACHE_NAME) {
                        console.log('Deleting old cache:', cacheName);
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
    self.clients.claim(); // کنترل تمام تب‌ها را بگیر
});