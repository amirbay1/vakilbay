<?php
// تنظیمات کوکی برای جلوگیری از پریدن لاگین
ini_set('session.cookie_lifetime', 86400 * 30); // ماندگاری ۳۰ روز
ini_set('session.gc_maxlifetime', 86400 * 30);
session_set_cookie_params([
    'lifetime' => 86400 * 30,
    'path' => '/',
    'domain' => '', // خالی بگذارید تا روی همه دامین‌ها کار کند
    'secure' => false, // اگر ssl ندارید false باشد
    'httponly' => true,
    'samesite' => 'Lax' // برای سازگاری با کروم‌های جدید
]);session_start();






// --- شروع کد عیب‌یابی (بعداً پاک کنید) ---
$debug = [
    'Method' => $_SERVER['REQUEST_METHOD'],
    'GET' => $_GET,
    'POST' => $_POST,
    'RawInput' => file_get_contents('php://input')
];
file_put_contents('log/login_debug.txt', print_r($debug, true));
// --- پایان کد عیب‌یابی ---






header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit(0);
}

// ═════════════════════════════════════════════════
// ۱. تنظیمات (رمز عبور و گوگل شیت)
// ═════════════════════════════════════════════════
$config = [
    'password' => '1234', // رمز ورود به سیستم
    'db_path'  => 'db/data.json',
    'google'   => [
        'enabled'       => true,
        'sheet_id'      => '1ugWnww_Cx7e7BdoDFsfg5gsiP113Iiougw8Eu6reIH4',
        'client_id'     => '1031802114248-htsduhc2l1v2t4rre71fk9fnf1qlp25a.apps.googleusercontent.com',
        'client_secret' => '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',
        'refresh_token' => '1//04sxN4CA5BoYmCgYIARAAGAQSNwF-L9IrV53Yk1dDhFUjPoN4W-hHb8v52xyMSMInYi8dkK_tYIp8RAAky_2RhQG8cpKZcNDBZwY',
    ]
];

// ═════════════════════════════════════════════════
// ۲. توابع گوگل شیت
// ═════════════════════════════════════════════════
function getGoogleToken($config) {
    if (empty($config['google']['refresh_token'])) return null;
    
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => http_build_query([
            'client_id' => $config['google']['client_id'],
            'client_secret' => $config['google']['client_secret'],
            'refresh_token' => $config['google']['refresh_token'],
            'grant_type' => 'refresh_token'
        ]),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 10
    ]);
    $response = curl_exec($ch);
    curl_close($ch);
    
    $result = json_decode($response, true);
    return $result['access_token'] ?? null;
}

function syncToGoogleSheet($type, $item, $config) {
    if (!$config['google']['enabled']) return;
    
    file_put_contents('log/debug.txt', "Start Sync: $type\n", FILE_APPEND);

    $token = getGoogleToken($config);
    if (!$token) {
        file_put_contents('debug.txt', "Error: Token is null\n", FILE_APPEND);
        return;
    }
    
    $sheetId = $config['google']['sheet_id'];
    $ranges = [
        'cases' => 'Cases',
        'finance' => 'Finance',
        'schedule' => 'Schedule',
        'library' => 'Library'
    ];
    
    $tabName = $ranges[$type] ?? null;
    if (!$tabName) return;

    $values = [];
    
    switch ($type) {
        case 'cases':
            $values = [[
                $item['id'] ?? '', $item['name'] ?? '', $item['mobile'] ?? '', $item['national'] ?? '',
                $item['birthDate'] ?? '', $item['address'] ?? '', $item['title'] ?? '', $item['type'] ?? '',
                $item['status'] ?? '', $item['branch'] ?? '', $item['opponent'] ?? '', $item['contract'] ?? '',
                $item['tags'] ?? '', $item['notes'] ?? '', $item['updatedAt'] ?? '', date('Y-m-d H:i:s')
            ]];
            break;
        case 'finance':
            $values = [[
                $item['id'] ?? '', $item['caseId'] ?? '', $item['caseName'] ?? 'بدون پرونده',
                $item['type'] ?? '', $item['amount'] ?? '', $item['date'] ?? '', $item['desc'] ?? '',
                date('Y-m-d H:i:s')
            ]];
            break;
        case 'schedule':
            $values = [[
                $item['id'] ?? '', $item['date'] ?? '', $item['time'] ?? '', $item['client'] ?? '',
                $item['caseId'] ?? '', $item['label'] ?? '', $item['desc'] ?? '', $item['result'] ?? '',
                ($item['is_done'] ?? false) ? 'بله' : 'خیر', date('Y-m-d H:i:s')
            ]];
            break;
        case 'library':
            $values = [[
                $item['id'] ?? '', $item['title'] ?? '', $item['type'] ?? '',
                mb_substr($item['content'] ?? '', 0, 500), date('Y-m-d H:i:s')
            ]];
            break;
    }
    
    if (empty($values)) return;
    
    $url = "https://sheets.googleapis.com/v4/spreadsheets/{$sheetId}/values/{$tabName}!A1:append?valueInputOption=USER_ENTERED&insertDataOption=INSERT_ROWS";
    
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode(['values' => $values]),
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', "Authorization: Bearer {$token}"],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15
    ]);
    curl_exec($ch);
    curl_close($ch);
}

// ═════════════════════════════════════════════════
// ۳. منطق اصلی (Logic) - اصلاح شده
// ═════════════════════════════════════════════════

// دریافت ورودی‌ها (هم JSON و هم POST معمولی را پوشش می‌دهد)
$inputJSON = json_decode(file_get_contents('php://input'), true);

$action = $_POST['action'] 
          ?? $_GET['action'] 
          ?? $inputJSON['action'] 
          ?? '';

$password = $_POST['password'] 
            ?? $inputJSON['password'] 
            ?? '';

// --- مرحله ۱: بررسی لاگین (قبل از چک کردن دسترسی) ---
if ($action === 'login') {
    if ($password === $config['password']) {
        $_SESSION['logged_in'] = true;
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'رمز عبور اشتباه است']);
    }
    exit;
}

// --- مرحله ۲: بررسی خروج ---
if ($action === 'logout') {
    session_destroy();
    echo json_encode(['success' => true]);
    exit;
}

// --- مرحله ۳: دیوار امنیتی (چک کردن سشن) ---
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(401); // به مرورگر می‌فهماند که کاربر لاگین نیست
    echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
    exit;
}

// --- مرحله ۴: درخواست‌های محافظت شده (فقط برای کاربران لاگین شده) ---

// درخواست‌های GET
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ($action === 'get_data') {
        if (file_exists($config['db_path'])) {
            $data = json_decode(file_get_contents($config['db_path']), true);
            echo json_encode(['success' => true, 'data' => $data]);
        } else {
            $emptyData = ['cases' => [], 'finance' => [], 'library' => [], 'schedule' => []];
            file_put_contents($config['db_path'], json_encode($emptyData, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
            echo json_encode(['success' => true, 'data' => $emptyData]);
        }
    } elseif ($action === 'test_google') {
        $token = getGoogleToken($config);
        echo json_encode([
            'success' => $token ? true : false,
            'message' => $token ? 'اتصال برقرار است' : 'خطا در اتصال'
        ]);
    }
    exit;
}

// درخواست‌های POST (ذخیره)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($inputJSON['db'])) {
        // ذخیره در فایل
        file_put_contents($config['db_path'], json_encode($inputJSON['db'], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
        
        // سینک به گوگل
        if (isset($inputJSON['syncType']) && isset($inputJSON['syncItem'])) {
            syncToGoogleSheet($inputJSON['syncType'], $inputJSON['syncItem'], $config);
        }
        
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'message' => 'داده نامعتبر']);
    }
    exit;
}
?>