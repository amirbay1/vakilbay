<?php
session_start();
define('SECURE_ACCESS', true);
header("Cache-Control: no-store, no-cache, must-revalidate");
header("Pragma: no-cache");

// PWA Manifest
if (isset($_GET['manifest'])) {
    header('Content-Type: application/json');
    echo json_encode([
        "name" => "وکیل‌یار",
        "short_name" => "وکیل‌یار", 
        "start_url" => ".",
        "display" => "standalone",
        "background_color" => "#f8fafc",
        "theme_color" => "#2563eb",
        "icons" => [[
            "src" => "img/vakilyar.png",
            "sizes" => "192x192",
            "type" => "image/png"
        ]]
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>وکیل‌یار | سیستم مدیریت دفتر وکالت</title>
    <link rel="manifest" href="?manifest=1">
    <meta name="theme-color" content="#2563eb">
    
    <!-- Fonts & Icons -->
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    
    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- حل مشکل اخطار Tailwind CDN -->
    <script>
        if (typeof window !== 'undefined') {
            const originalLog = console.warn;
            console.warn = function(...args) {
                if (args[0] && args[0].includes && args[0].includes('should not be used in production')) {
                    return;
                }
                originalLog.apply(console, args);
            };
        }
    </script>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- Configuration -->
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        primary: {
                            50: '#eff6ff',
                            100: '#dbeafe',
                            200: '#bfdbfe',
                            300: '#93c5fd',
                            400: '#60a5fa',
                            500: '#3b82f6',
                            600: '#2563eb',
                            700: '#1d4ed8',
                            800: '#1e40af',
                            900: '#1e3a8a',
                        },
                        gold: {
                            400: '#facc15',
                            500: '#eab308',
                            600: '#ca8a04',
                        },
                        dark: {
                            800: '#1e293b',
                            900: '#0f172a',
                            950: '#020617',
                        }
                    },
                    fontFamily: {
                        sans: ['Vazirmatn', 'system-ui', 'sans-serif'],
                    },
                    animation: {
                        'fade-in': 'fadeIn 0.3s ease-out',
                        'slide-up': 'slideUp 0.3s ease-out',
                        'scale-in': 'scaleIn 0.2s ease-out',
                    }
                }
            }
        }
    </script>
    
    <!-- Styles -->
    <link rel="stylesheet" href="style.css">
    
<!-- JS Files - ترتیب مهم است! -->
<script src="js/config.js?v=<?php echo time(); ?>"></script>
<script src="js/utils.js?v=<?php echo time(); ?>"></script>
<script src="js/dateUtils.js?v=<?php echo time(); ?>"></script>
<script src="js/api.js?v=<?php echo time(); ?>"></script>
<script src="js/ui.js?v=<?php echo time(); ?>"></script>
<script src="js/dashboard.js?v=<?php echo time(); ?>"></script>
<script src="js/cases.js?v=<?php echo time(); ?>"></script>
<script src="js/schedule.js?v=<?php echo time(); ?>"></script>
<script src="js/finance.js?v=<?php echo time(); ?>"></script>
<script src="js/library.js?v=<?php echo time(); ?>"></script>
<script src="js/backup.js?v=<?php echo time(); ?>"></script>
<script src="js/main.js?v=<?php echo time(); ?>"></script>
</head>
<body class="bg-gray-50 dark:bg-dark-950 text-gray-800 dark:text-gray-200 min-h-screen">

<?php if (!isset($_SESSION['logged_in'])): ?>
<!-- ═══════════════════ صفحه ورود ═══════════════════ -->
<div class="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary-600 to-primary-900 dark:from-dark-900 dark:to-dark-950">
    <div class="w-full max-w-md animate-fade-in">
        <!-- Logo -->
        <div class="text-center mb-8">
            <div class="w-20 h-20 bg-white dark:bg-gold-500 rounded-2xl mx-auto mb-4 flex items-center justify-center shadow-2xl">
                <i class="fas fa-scale-balanced text-3xl text-primary-600 dark:text-dark-900"></i>
            </div>
            <h1 class="text-2xl font-bold text-white">وکیل‌یار</h1>
            <p class="text-primary-200 dark:text-gray-400 text-sm mt-1">سیستم هوشمند مدیریت دفتر وکالت</p>
        </div>
        
        <!-- Login Form -->
        <div class="card p-8">
            <form id="loginForm" onsubmit="handleLogin(event)">
                <div class="mb-6">
                    <label class="block text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">
                        <i class="fas fa-lock ml-1"></i> رمز عبور
                    </label>
                    <input 
                        type="password" 
                        id="loginPassword"
                        class="input-primary text-center text-lg tracking-widest"
                        placeholder="••••••••"
                        autocomplete="current-password"
                        required
                    >
                </div>
                <button type="submit" class="btn-primary w-full">
                    <i class="fas fa-sign-in-alt ml-2"></i>
                    ورود به سیستم
                </button>
            </form>
        </div>
        
        <p class="text-center text-primary-200 dark:text-gray-500 text-xs mt-6"> نسخه 3.1 | طراحی شده با ❤️ </p>
    </div>
</div>

<script>
async function handleLogin(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button');
    btn.disabled = true;
    btn.innerHTML = '<i class="fas fa-spinner fa-spin ml-2"></i> در حال ورود...';
    
    try {
        const fd = new FormData();
        fd.append('action', 'login');
        fd.append('password', document.getElementById('loginPassword').value);
        
        const res = await fetch('api.php', { method: 'POST', body: fd });
        const data = await res.json();
        
        if (data.success) {
            location.reload();
        } else {
            Swal.fire({
                icon: 'error',
                title: 'خطا',
                text: data.message,
                confirmButtonText: 'باشه'
            });
        }
    } catch (err) {
        Swal.fire({
            icon: 'error',
            title: 'خطای سرور',
            text: 'لطفاً دوباره تلاش کنید',
            confirmButtonText: 'باشه'
        });
    }
    
    btn.disabled = false;
    btn.innerHTML = '<i class="fas fa-sign-in-alt ml-2"></i> ورود به سیستم';
}

// Check dark mode
if (localStorage.getItem('theme') === 'dark') {
    document.documentElement.classList.add('dark');
}
</script>

<?php else: ?>
<!-- ═══════════════════ اپلیکیشن اصلی ═══════════════════ -->
<div class="flex h-screen overflow-hidden flex-col">
    
    <!-- ═══════ Header ═══════ -->
    <header class="h-16 bg-white dark:bg-dark-900 border-b border-gray-200 dark:border-dark-800 flex items-center justify-between px-4 lg:px-6 shrink-0 z-30">
        <!-- Logo & Title (Right Side) -->
        <div class="flex items-center gap-4">
            <div class="w-10 h-10 bg-primary-600 dark:bg-gold-500 rounded-xl flex items-center justify-center">
                <i class="fas fa-scale-balanced text-white dark:text-dark-900"></i>
            </div>
            <div>
                <h1 class="font-bold text-gray-800 dark:text-white text-lg">وکیل‌یار</h1>
                <p class="text-[10px] text-gray-400 uppercase tracking-wider">Pro Edition</p>
            </div>
        </div>
        
        <!-- Desktop Navigation (Center) -->
<nav class="hidden lg:flex items-center gap-1">
    <button onclick="setView('dashboard')" class="desktop-nav-item" data-view="dashboard">
        <i class="fas fa-home"></i>
        <span>داشبورد</span>
    </button>
    <button onclick="setView('cases')" class="desktop-nav-item" data-view="cases">
        <i class="fas fa-folder-open"></i>
        <span>پرونده‌ها</span>
    </button>
    <button onclick="setView('schedule')" class="desktop-nav-item" data-view="schedule">
        <i class="fas fa-calendar-alt"></i>
        <span>تقویم</span>
    </button>
    <button onclick="setView('finance')" class="desktop-nav-item" data-view="finance">
        <i class="fas fa-wallet"></i>
        <span>امور مالی</span>
    </button>
    <button onclick="setView('library')" class="desktop-nav-item" data-view="library">
        <i class="fas fa-book"></i>
        <span>بانک لوایح</span>
    </button>
</nav>

        <!-- Left Side Actions -->
        <div class="flex items-center gap-3">
            <!-- Sync Status -->
            <div id="syncStatus" class="hidden items-center gap-2 text-xs text-gray-400">
                <i class="fas fa-cloud text-emerald-500"></i>
                <span>سینک شد</span>
            </div>
            
            <!-- Date -->
            <div class="hidden md:flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
                <i class="fas fa-calendar-day"></i>
                <span id="todayDate"></span>
            </div>

            <!-- Dark Mode Toggle -->
            <button onclick="toggleTheme()" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg transition" title="تغییر حالت نمایش">
                <i class="fas fa-moon text-gray-600 dark:text-gray-400 dark:hidden"></i>
                <i class="fas fa-sun text-gray-400 dark:text-yellow-400 hidden dark:block"></i>
            </button>
            
            <!-- User Menu -->
            <div class="relative">
                <button onclick="toggleUserMenu()" class="flex items-center gap-2 p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg transition">
                    <div class="w-8 h-8 bg-primary-100 dark:bg-gold-500/20 rounded-full flex items-center justify-center">
                       <i class="fas fa-user text-primary-600 dark:text-gold-500 text-sm"></i>
                    </div>
                    <i class="fas fa-chevron-down text-xs text-gray-400"></i>
                </button>
                
                <!-- Dropdown Menu -->
<div id="userMenu" class="absolute left-0 top-full mt-2 w-56 bg-white dark:bg-dark-900 border border-gray-200 dark:border-dark-700 rounded-xl shadow-xl hidden z-50">
    <div class="p-4 border-b border-gray-100 dark:border-dark-800">
        <p class="text-sm font-medium text-gray-700 dark:text-gray-300">امیرحسین بای</p>
        <p class="text-xs text-gray-400">مدیر سیستم</p>
    </div>
    <div class="p-2">
        <!-- بانک لوایح - فقط در موبایل نمایش داده می‌شود -->
        <button onclick="setView('library'); toggleUserMenu();" class="lg:hidden w-full text-right px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg transition flex items-center gap-2">
            <i class="fas fa-book text-purple-500"></i>
            بانک لوایح
        </button>
        <button onclick="setView('settings'); toggleUserMenu();" class="w-full text-right px-3 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg transition flex items-center gap-2">
            <i class="fas fa-cog"></i>
            تنظیمات
        </button>
        <button onclick="logout()" class="w-full text-right px-3 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition flex items-center gap-2">
            <i class="fas fa-sign-out-alt"></i>
            خروج از سیستم
        </button>
    </div>
</div>
            </div>
        </div>
    </header>
    
    <!-- ═══════ Main Content ═══════ -->
    <main class="flex-1 overflow-hidden flex flex-col">
        <!-- ═══════ Content Area ═══════ -->
        <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
            
            <!-- ════════════════════════════════════════════════════════════ -->
            <!-- داشبورد -->
            <!-- ════════════════════════════════════════════════════════════ -->
            <div id="view-dashboard" class="page-view animate-fade-in">
                
                <!-- Stats Cards -->
                <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    <!-- پرونده‌های فعال -->
                    <div class="card p-5">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">پرونده‌های فعال</p>
                                <p id="stat-cases" class="text-3xl font-black text-gray-800 dark:text-white">0</p>
                            </div>
                            <div class="w-12 h-12 bg-primary-100 dark:bg-primary-900/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-folder-open text-primary-600 dark:text-primary-400 text-xl"></i>
                            </div>
                        </div>
                        <div id="monthly-comparison" class="mt-3 flex items-center gap-1 text-xs">
                            <!-- این بخش توسط جاوااسکریپت پر می‌شود -->
                        </div>
                    </div>
                    
                    <!-- جلسات امروز -->
                    <div class="card p-5">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">جلسات امروز</p>
                                <p id="stat-today" class="text-3xl font-black text-gray-800 dark:text-white">0</p>
                            </div>
                            <div class="w-12 h-12 bg-amber-100 dark:bg-amber-900/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-calendar-check text-amber-600 dark:text-amber-400 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-3 flex items-center gap-1 text-xs">
                            <span class="text-gray-400">برنامه روز جاری</span>
                        </div>
                    </div>
                    
                    <!-- درآمد ماه -->
                    <div class="card p-5">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">درآمد ماه</p>
                                <p id="stat-income" class="text-2xl font-black text-emerald-600 dark:text-emerald-400 font-mono" dir="ltr">0</p>
                            </div>
                            <div class="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-arrow-trend-up text-emerald-600 dark:text-emerald-400 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-3 flex items-center gap-1 text-xs text-gray-400">
                            <span>تومان</span>
                        </div>
                    </div>
                    
                    <!-- تراز مالی -->
                    <div class="card p-5">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-sm text-gray-500 dark:text-gray-400 mb-1">تراز مالی</p>
                                <p id="stat-balance" class="text-2xl font-black text-gray-800 dark:text-white font-mono" dir="ltr">0</p>
                            </div>
                            <div class="w-12 h-12 bg-purple-100 dark:bg-purple-900/30 rounded-xl flex items-center justify-center">
                                <i class="fas fa-coins text-purple-600 dark:text-purple-400 text-xl"></i>
                            </div>
                        </div>
                        <div class="mt-3 flex items-center gap-1 text-xs text-gray-400">
                            <span>مجموع دریافت - هزینه</span>
                        </div>
                    </div>
                </div>
                
                <!-- Charts Row -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                    <!-- نمودار وضعیت پرونده‌ها -->
                    <div class="card p-6">
                        <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                            <i class="fas fa-chart-pie text-primary-500"></i>
                            وضعیت پرونده‌ها
                        </h3>
                        <div class="h-64 flex items-center justify-center">
                            <canvas id="casesChart"></canvas>
                        </div>
                    </div>
                    
                    <!-- نمودار مالی -->
                    <div class="card p-6">
                        <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                            <i class="fas fa-chart-line text-emerald-500"></i>
                            روند مالی
                        </h3>
                        <div class="h-64">
                            <canvas id="financeChart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- Lists Row -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <!-- جلسات آینده -->
                    <div class="card p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-gray-800 dark:text-white flex items-center gap-2">
                                <i class="fas fa-clock text-amber-500"></i>
                                جلسات آینده
                            </h3>
                            <button onclick="setView('schedule')" class="text-xs text-primary-600 dark:text-gold-500 hover:underline">
                                مشاهده همه
                            </button>
                        </div>
                        <div id="upcomingList" class="space-y-3">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                    
                    <!-- پرونده‌های اخیر -->
                    <div class="card p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-gray-800 dark:text-white flex items-center gap-2">
                                <i class="fas fa-folder text-primary-500"></i>
                                پرونده‌های اخیر
                            </h3>
                            <button onclick="setView('cases')" class="text-xs text-primary-600 dark:text-gold-500 hover:underline">
                                مشاهده همه
                            </button>
                        </div>
                        <div id="recentCasesList" class="space-y-3">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                    
                    <!-- تراکنش‌های اخیر -->
                    <div class="card p-6">
                        <div class="flex items-center justify-between mb-4">
                            <h3 class="font-bold text-gray-800 dark:text-white flex items-center gap-2">
                                <i class="fas fa-receipt text-emerald-500"></i>
                                تراکنش‌های اخیر
                            </h3>
                            <button onclick="setView('finance')" class="text-xs text-primary-600 dark:text-gold-500 hover:underline">
                                مشاهده همه
                            </button>
                        </div>
                        <div id="recentFinanceList" class="space-y-3">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- ════════════════════════════════════════════════════════════ -->
            <!-- پرونده‌ها -->
            <!-- ════════════════════════════════════════════════════════════ -->
            <div id="view-cases" class="page-view hidden animate-fade-in h-full flex flex-col">
                
                <!-- Header -->
                <div class="flex flex-col md:flex-row gap-4 mb-6">
                    <div class="relative flex-1">
                        <i class="fas fa-search absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                        <input 
                            type="text" 
                            id="searchCases" 
                            placeholder="جستجو در پرونده‌ها..."
                            class="input-primary pr-12"
                            onkeyup="renderCases()"
                        >
                    </div>
                    <div class="flex gap-2">
                        <select id="filterCaseStatus" onchange="renderCases()" class="input-primary w-auto">
                            <option value="">همه وضعیت‌ها</option>
                            <option value="جاری">جاری</option>
                            <option value="مختومه">مختومه</option>
                        </select>
                        <select id="filterCaseType" onchange="renderCases()" class="input-primary w-auto">
                            <option value="">همه انواع</option>
                            <option value="حقوقی">حقوقی</option>
                            <option value="کیفری">کیفری</option>
                            <option value="خانواده">خانواده</option>
                            <option value="ملکی">ملکی</option>
                            <option value="ثبتی">ثبتی</option>
                        </select>
                        <button onclick="openCaseModal()" class="btn-primary whitespace-nowrap">
                            <i class="fas fa-plus ml-2"></i>
                            پرونده جدید
                        </button>
                    </div>
                </div>
                
                <!-- Cases Grid -->
                <div id="casesGrid" class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 overflow-y-auto pb-4">
                    <!-- Dynamic content -->
                </div>
                
                <!-- Pagination -->
                <div id="casesPagination" class="pagination mt-4"></div>
            </div>
<!-- ════════════════════════════════════════════════════════════ -->
<!-- تقویم کاری -->
<!-- ════════════════════════════════════════════════════════════ -->
<div id="view-schedule" class="page-view hidden animate-fade-in h-full flex flex-col">
    
    <!-- Header -->
    <div class="flex flex-col md:flex-row gap-4 mb-6">
        <div class="relative flex-1">
            <i class="fas fa-search absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
            <input 
                type="text" 
                id="searchSchedule" 
                placeholder="جستجو در برنامه‌ها..."
                class="input-primary pr-12"
                onkeyup="renderSchedule()"
            >
        </div>
        <div class="flex gap-2">
            <select id="filterScheduleLabel" onchange="renderSchedule()" class="input-primary w-auto">
                <option value="">همه برچسب‌ها</option>
                <option value="جلسه">🔵 جلسه</option>
                <option value="دادگاه">🔴 دادگاه</option>
                <option value="تنظیم">🟣 تنظیم</option>
                <option value="پیگیری">🟠 پیگیری</option>
            </select>
            <button onclick="openScheduleModal()" class="btn-primary whitespace-nowrap">
                <i class="fas fa-plus ml-2"></i>
                برنامه جدید
            </button>
            <!-- دکمه تغییر نما -->
            <button id="viewToggleBtn" onclick="toggleCalendarView()" class="btn-primary whitespace-nowrap">
                <i class="fas fa-calendar-alt"></i>
            </button>
        </div>
    </div>
    
    <!-- Schedule Content -->
    <div class="flex-1 overflow-y-auto">
        <!-- نمای لیست -->
        <div id="listViewContainer">
            <!-- Today Highlight -->
            <div id="todaySchedule" class="mb-6">
                <div class="flex items-center gap-3 mb-4">
                    <div class="w-10 h-10 bg-red-100 dark:bg-red-900/30 rounded-xl flex items-center justify-center">
                        <i class="fas fa-fire text-red-500"></i>
                    </div>
                    <div>
                        <h3 class="font-bold text-gray-800 dark:text-white">امروز</h3>
                        <p id="todayDateSchedule" class="text-sm text-gray-500"></p>
                    </div>
                </div>
                <div id="scheduleSummary"></div>
                <div id="todayScheduleList" class="space-y-3">
                    <!-- Dynamic content -->
                </div>
            </div>
            
            <!-- Upcoming -->
            <div id="upcomingSchedule" class="mb-6">
                <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                    <i class="fas fa-calendar-alt text-primary-500"></i>
                    برنامه‌های آینده
                </h3>
                <div id="upcomingScheduleList" class="space-y-3">
                    <!-- Dynamic content -->
                </div>
                <!-- Pagination -->
                <div id="schedulePagination" class="pagination mt-4"></div>
            </div>
            
            <!-- Past (Collapsible) -->
            <div class="border-t border-gray-200 dark:border-dark-800 pt-6">
                <button onclick="togglePastSchedule()" class="flex items-center gap-2 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 mb-4">
                    <i class="fas fa-chevron-down" id="pastScheduleIcon"></i>
                    <span>برنامه‌های گذشته</span>
                </button>
                <div id="pastScheduleList" class="hidden space-y-3 opacity-60">
                    <!-- Dynamic content -->
                </div>
            </div>
        </div>
        
        <!-- نمای ماهانه (در ابتدا مخفی) -->
        <div id="monthCalendarContainer" class="hidden">
            <!-- تقویم ماهانه توسط جاوا اسکریپت اینجا رندر می‌شود -->
        </div>
    </div>
</div>
            <!-- ════════════════════════════════════════════════════════════ -->
            <!-- امور مالی -->
            <!-- ════════════════════════════════════════════════════════════ -->
<div id="view-finance" class="page-view hidden animate-fade-in h-full flex flex-col">
    
    <!-- 1. کارت‌های آمار بالای صفحه -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div class="card p-5 border-r-4 border-r-emerald-500">
            <p class="text-sm text-gray-500 mb-1">مجموع دریافتی</p>
            <p id="totalIncome" class="text-2xl font-black text-emerald-600 font-mono" dir="ltr">0</p>
        </div>
        <div class="card p-5 border-r-4 border-r-red-500">
            <p class="text-sm text-gray-500 mb-1">مجموع هزینه</p>
            <p id="totalExpense" class="text-2xl font-black text-red-600 font-mono" dir="ltr">0</p>
        </div>
        <div class="card p-5 border-r-4 border-r-primary-500 dark:border-r-gold-500">
            <p class="text-sm text-gray-500 mb-1">تراز کل</p>
            <p id="totalBalance" class="text-2xl font-black text-gray-800 dark:text-white font-mono" dir="ltr">0</p>
        </div>
    </div>
    
    <!-- 2. بخش هدر (جستجو + فیلترها + دکمه‌ها) -->
    <div class="flex flex-col gap-4 mb-6">
        
        <!-- ردیف اول: جستجو و دکمه‌ها -->
        <div class="flex flex-col md:flex-row gap-4">
            <!-- کادر جستجو -->
            <div class="relative flex-1">
                <i class="fas fa-search absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                <input 
                    type="text" 
                    id="searchFinance" 
                    placeholder="جستجو در تراکنش‌ها..."
                    class="input-primary pr-12"
                    onkeyup="renderFinance()"
                >
            </div>

            <!-- دکمه‌ها -->
            <div class="flex gap-2 text-sm overflow-x-auto pb-1 md:pb-0">
                <!-- دکمه جدید بدهکاران -->
                <button onclick="setView('debtors')" class="btn-primary bg-orange-500 hover:bg-orange-600 text-white whitespace-nowrap px-3 flex items-center gap-2">
                    <i class="fas fa-hand-holding-dollar"></i>
                    <span class="hidden md:inline">بدهکاران</span>
                    <span class="md:hidden">طلب</span>
                </button>
                
                <select id="filterFinanceType" onchange="renderFinance()" class="input-primary w-auto">
                    <option value="">همه</option>
                    <option value="income">دریافت</option>
                    <option value="expense">هزینه</option>
                </select>
                
                <button onclick="openFinanceModal()" class="btn-primary whitespace-nowrap">
                    <i class="fas fa-plus ml-2"></i>
                    جدید
                </button>
            </div>
        </div>
        
        <!-- ردیف دوم: فیلتر بازه زمانی -->
        <div class="flex flex-col md:flex-row gap-4 items-end">
            <div class="flex-1">
                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">از تاریخ</label>
                <input type="text" id="filterDateFrom" class="input-primary text-center" placeholder="1403/01/01" onchange="renderFinance()">
            </div>
            <div class="flex-1">
                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">تا تاریخ</label>
                <input type="text" id="filterDateTo" class="input-primary text-center" placeholder="1403/12/29" onchange="renderFinance()">
            </div>
            <button onclick="clearDateFilters()" class="btn-primary bg-gray-500 hover:bg-gray-600 whitespace-nowrap">
                <i class="fas fa-times ml-2"></i>
                پاک کردن فیلتر
            </button>
        </div>
    </div>
    
    <!-- 3. جدول تراکنش‌ها -->
    <div class="card flex-1 overflow-hidden flex flex-col">
        <div class="overflow-x-auto flex-1">
            <table class="w-full">
                <thead class="bg-gray-50 dark:bg-dark-800 sticky top-0">
                    <tr class="text-right text-sm text-gray-500 dark:text-gray-400">
                        <th class="p-4 font-medium">تاریخ</th>
                        <th class="p-4 font-medium">پرونده</th>
                        <th class="p-4 font-medium">نوع</th>
                        <th class="p-4 font-medium">مبلغ</th>
                        <th class="p-4 font-medium">توضیحات</th>
                        <th class="p-4 font-medium text-center">عملیات</th>
                    </tr>
                </thead>
                <tbody id="financeTableBody" class="divide-y divide-gray-100 dark:divide-dark-800">
                    <!-- اینجا با جاوااسکریپت پر می‌شود -->
                </tbody>
            </table>
        </div>
        <!-- Pagination -->
        <div id="financePagination" class="pagination border-t border-gray-100 dark:border-dark-800 pt-4"></div>
    </div>
</div>
                
            <!-- ════════════════════════════════════════════════════════════ -->
            <!-- بانک لوایح -->
            <!-- ════════════════════════════════════════════════════════════ -->
            <div id="view-library" class="page-view hidden animate-fade-in h-full flex flex-col lg:flex-row gap-6">
                
                <!-- List -->
                <div class="w-full lg:w-1/3 flex flex-col">
                    <div class="card p-4 flex flex-col h-full">
                        <button onclick="openLibraryModal()" class="btn-primary w-full mb-4">
                            <i class="fas fa-plus ml-2"></i>
                            متن جدید
                        </button>
                        
                        <div class="relative mb-4">
                            <i class="fas fa-search absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                            <input 
                                type="text" 
                                id="searchLibrary" 
                                placeholder="جستجو..."
                                class="input-primary pr-12"
                                onkeyup="renderLibrary()"
                            >
                        </div>
                        
                        <div id="libraryList" class="flex-1 overflow-y-auto space-y-2">
                            <!-- Dynamic content -->
                        </div>
                    </div>
                </div>
                
                <!-- Content Viewer -->
                <div class="flex-1 flex flex-col">
                    <div class="card p-6 flex-1 flex flex-col">
                        <!-- Empty State -->
                        <div id="libraryEmpty" class="flex-1 flex flex-col items-center justify-center text-center">
                            <div class="w-20 h-20 bg-gray-100 dark:bg-dark-800 rounded-full flex items-center justify-center mb-4">
                                <i class="fas fa-book-open text-3xl text-gray-300 dark:text-gray-600"></i>
                            </div>
                            <p class="text-gray-400">یک متن از لیست انتخاب کنید</p>
                        </div>
                        
                        <!-- Content View -->
                        <div id="libraryContent" class="flex-1 flex flex-col hidden">
                            <div class="flex items-center justify-between mb-4 pb-4 border-b border-gray-100 dark:border-dark-800">
                                <div>
                                    <h2 id="libraryViewTitle" class="text-xl font-bold text-gray-800 dark:text-white"></h2>
                                    <span id="libraryViewType" class="tag mt-2"></span>
                                </div>
                                <div class="flex gap-2">
                                    <button onclick="copyLibraryContent()" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg transition" title="کپی">
                                        <i class="fas fa-copy text-gray-400"></i>
                                    </button>
                                    <button onclick="editLibrary()" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg transition" title="ویرایش">
                                        <i class="fas fa-edit text-gray-400"></i>
                                    </button>
                                    <button onclick="deleteLibrary()" class="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition" title="حذف">
                                        <i class="fas fa-trash text-red-400"></i>
                                    </button>
                                </div>
                            </div>
                            <div id="libraryViewContent" class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-800 rounded-xl p-5 text-sm leading-8 whitespace-pre-wrap"></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- ═════════════════════════════════════════════════════════════════════ -->
            <!-- صفحات جدید (جایگزین مودال‌ها) -->
            <!-- ═════════════════════════════════════════════════════════════════════ -->

            <!-- صفحه افزودن سریع -->
            <div id="view-quickadd" class="page-view hidden animate-fade-in h-full flex flex-col">
                <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
                    <div class="max-w-4xl mx-auto">
                        <h2 class="text-xl font-bold text-gray-800 dark:text-white mb-6">افزودن سریع</h2>
                        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                            <button onclick="openCaseModal()" class="p-6 card hover:border-primary-500 transition text-center">
                                <i class="fas fa-folder-plus text-3xl text-primary-500 mb-2"></i>
                                <p class="font-medium text-gray-700 dark:text-gray-300">پرونده جدید</p>
                            </button>
                            <button onclick="openScheduleModal()" class="p-6 card hover:border-amber-500 transition text-center">
                                <i class="fas fa-calendar-plus text-3xl text-amber-500 mb-2"></i>
                                <p class="font-medium text-gray-700 dark:text-gray-300">برنامه جدید</p>
                            </button>
                            <button onclick="openFinanceModal()" class="p-6 card hover:border-emerald-500 transition text-center">
                                <i class="fas fa-money-bill-wave text-3xl text-emerald-500 mb-2"></i>
                                <p class="font-medium text-gray-700 dark:text-gray-300">تراکنش جدید</p>
                            </button>
                            <button onclick="openLibraryModal()" class="p-6 card hover:border-purple-500 transition text-center">
                                <i class="fas fa-file-alt text-3xl text-purple-500 mb-2"></i>
                                <p class="font-medium text-gray-700 dark:text-gray-300">متن جدید</p>
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- صفحه فرم پرونده (طراحی جدید) -->
            <div id="view-caseform" class="page-view hidden animate-fade-in h-full flex flex-col">
                <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
                    <div class="max-w-7xl mx-auto">
                        <div class="flex items-center justify-between mb-6">
                            <h2 id="caseFormTitle" class="text-xl font-bold text-gray-800 dark:text-white">
                                <i class="fas fa-folder-plus ml-2"></i>
                                پرونده جدید
                            </h2>
                            <button onclick="setView('cases')" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                                <i class="fas fa-times text-gray-400"></i>
                            </button>
                        </div>
                        
                        <form id="caseForm" onsubmit="saveCase(event)" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            <input type="hidden" id="caseId">
                            
                            <!-- ستون اصلی فرم -->
                            <div class="lg:col-span-2 space-y-6">
                                <!-- اطلاعات موکل -->
                                <div class="card p-5">
                                    <h4 class="text-sm font-bold text-primary-600 dark:text-gold-500 mb-4 flex items-center gap-2">
                                        <i class="fas fa-user"></i> اطلاعات موکل
                                    </h4>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div class="md:col-span-2">
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">نام و نام خانوادگی *</label>
                                            <input type="text" id="caseName" class="input-primary" required>
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">شماره تماس *</label>
                                            <input type="tel" id="caseMobile" class="input-primary" dir="ltr" required>
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">کد ملی</label>
                                            <input type="text" id="caseNational" class="input-primary" dir="ltr">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">تاریخ تولد</label>
                                            <input type="text" id="caseBirth" class="input-primary text-center" placeholder="13xx/xx/xx" dir="ltr">
                                        </div>
                                        <div class="md:col-span-2">
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">آدرس</label>
                                            <input type="text" id="caseAddress" class="input-primary">
                                        </div>
                                    </div>
                                </div>

                                <!-- اطلاعات پرونده -->
                                <div class="card p-5">
                                    <h4 class="text-sm font-bold text-primary-600 dark:text-gold-500 mb-4 flex items-center gap-2">
                                        <i class="fas fa-folder-open"></i> مشخصات پرونده
                                    </h4>
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div class="md:col-span-2">
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">عنوان پرونده *</label>
                                            <input type="text" id="caseTitle" class="input-primary" required>
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">نوع</label>
                                            <select id="caseType" class="input-primary">
                                                <option value="حقوقی">حقوقی</option>
                                                <option value="کیفری">کیفری</option>
                                                <option value="خانواده">خانواده</option>
                                                <option value="ملکی">ملکی</option>
                                                <option value="ثبتی">ثبتی</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">وضعیت</label>
                                            <select id="caseStatus" class="input-primary">
                                                <option value="جاری">جاری</option>
                                                <option value="مختومه">مختومه</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">شعبه دادگاه</label>
                                            <input type="text" id="caseBranch" class="input-primary">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">شماره بایگانی</label>
                                            <input type="text" id="caseArchiveNo" class="input-primary" dir="ltr">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">طرف دعوی</label>
                                            <input type="text" id="caseOpponent" class="input-primary">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">شماره قرارداد</label>
                                            <input type="text" id="caseContract" class="input-primary" dir="ltr">
                                        </div>
                                        <div class="md:col-span-2">
                                            <label class="block text-sm text-emerald-600 font-bold mb-1">مبلغ حق‌الوکاله (تومان)</label>
                                            <input type="text" id="casePrice" class="input-primary font-bold text-emerald-600" dir="ltr" placeholder="0">
                                        </div>
                                    </div>
                                </div>

                                <!-- دادسرا -->
                                <div class="card p-5 bg-orange-50 dark:bg-orange-900/10 border border-orange-200 dark:border-orange-900/30">
                                    <label class="flex items-center gap-2 cursor-pointer mb-4">
                                        <input type="checkbox" id="caseHasProsecutor" onchange="toggleProsecutor()" class="w-4 h-4 rounded">
                                        <span class="text-sm font-medium text-orange-700 dark:text-orange-400">
                                            <i class="fas fa-balance-scale ml-1"></i> پرونده دادسرا دارد
                                        </span>
                                    </label>
                                    <div id="prosecutorFields" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">شعبه دادسرا</label>
                                            <input type="text" id="caseProsecutorBranch" class="input-primary">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">بایگانی دادسرا</label>
                                            <input type="text" id="caseProsecutorArchive" class="input-primary" dir="ltr">
                                        </div>
                                    </div>
                                </div>

                                <!-- اجرای احکام -->
                                <div class="card p-5 bg-purple-50 dark:bg-purple-900/10 border border-purple-200 dark:border-purple-900/30">
                                    <label class="flex items-center gap-2 cursor-pointer mb-4">
                                        <input type="checkbox" id="caseHasExecution" onchange="toggleExecution()" class="w-4 h-4 rounded">
                                        <span class="text-sm font-medium text-purple-700 dark:text-purple-400">
                                            <i class="fas fa-gavel ml-1"></i> اجرای احکام دارد
                                        </span>
                                    </label>
                                    <div id="executionFields" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4">
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">شعبه اجرا</label>
                                            <input type="text" id="caseExecutionBranch" class="input-primary">
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">بایگانی اجرا</label>
                                            <input type="text" id="caseExecutionArchive" class="input-primary" dir="ltr">
                                        </div>
                                    </div>
                                </div>

                                <!-- یادداشت -->
                                <div class="card p-5">
                                    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">یادداشت</label>
                                    <textarea id="caseNotes" class="input-primary resize-none" rows="3"></textarea>
                                </div>
                            </div>

                            <!-- ستون کناری (خلاصه و اقدامات) -->
                            <div class="space-y-6">
                                <!-- خلاصه پرونده -->
                                <div class="card p-5 sticky top-6">
                                    <h4 class="text-sm font-bold text-gray-600 dark:text-gray-400 mb-4">خلاصه پرونده</h4>
                                    <div class="space-y-3 text-sm">
                                        <div class="flex justify-between">
                                            <span class="text-gray-500">موکل:</span>
                                            <span id="summary-name" class="font-medium">-</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-500">نوع پرونده:</span>
                                            <span id="summary-type" class="font-medium">-</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-500">وضعیت:</span>
                                            <span id="summary-status" class="font-medium">-</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-500">حق‌الوکاله:</span>
                                            <span id="summary-price" class="font-medium text-emerald-600">-</span>
                                        </div>
                                    </div>
                                </div>

                                <!-- تگ‌ها -->
                                <div class="card p-5">
                                    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">تگ‌ها</label>
                                    <input type="text" id="caseTags" class="input-primary" placeholder="با کاما جدا کنید...">
                                </div>

                                <!-- اقدامات -->
                                <div class="card p-5">
                                    <h4 class="text-sm font-bold text-gray-600 dark:text-gray-400 mb-4">اقدامات</h4>
                                    <div class="space-y-3">
                                        <button type="submit" class="w-full btn-primary">
                                            <i class="fas fa-save ml-2"></i> ذخیره پرونده
                                        </button>
                                        <button type="button" onclick="setView('cases')" class="w-full py-2.5 bg-gray-100 dark:bg-dark-800 text-gray-600 dark:text-gray-400 rounded-xl text-sm font-medium hover:bg-gray-200 transition">
                                            انصراف
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- صفحه فرم برنامه (طراحی جدید) -->
            <!-- صفحه فرم برنامه (طراحی جدید) -->
<div id="view-scheduleform" class="page-view hidden animate-fade-in h-full flex flex-col">
    <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
        <div class="max-w-4xl mx-auto">
            <div class="flex items-center justify-between mb-6">
                <h2 id="scheduleFormTitle" class="text-xl font-bold text-gray-800 dark:text-white">
                    <i class="fas fa-calendar-plus ml-2"></i>
                    برنامه جدید
                </h2>
                <button onclick="setView('schedule')" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                    <i class="fas fa-times text-gray-400"></i>
                </button>
            </div>
            
            <form id="scheduleForm" onsubmit="saveSchedule(event)" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <input type="hidden" id="scheduleId">
                
                <!-- ستون اصلی فرم -->
                <div class="lg:col-span-2 space-y-6">
                    <!-- اطلاعات اصلی -->
                    <div class="card p-5">
                        <h4 class="text-sm font-bold text-primary-600 dark:text-gold-500 mb-4 flex items-center gap-2">
                            <i class="fas fa-calendar"></i> اطلاعات برنامه
                        </h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">تاریخ *</label>
                                <input type="text" id="scheduleDate" class="input-primary text-center" placeholder="1403/01/01" required>
                            </div>
                            <div>
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">ساعت *</label>
                                <input type="time" id="scheduleTime" class="input-primary text-center" required>
                            </div>
                            
                            <!-- موکل -->
                            <div class="md:col-span-2">
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">نام موکل / طرف حساب</label>
                                <div class="relative">
                                    <i class="fas fa-user absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                                    <input 
                                        type="text" 
                                        id="scheduleClient" 
                                        class="input-primary pr-10" 
                                        placeholder="نام موکل را وارد کنید..."
                                        autocomplete="off" 
                                        onkeyup="suggestClients(this)"
                                    >
                                    <div id="clientSuggestions" class="absolute top-full right-0 left-0 bg-white dark:bg-dark-900 border border-gray-200 dark:border-dark-700 rounded-xl shadow-xl mt-1 hidden z-50 max-h-48 overflow-y-auto"></div>
                                </div>
                            </div>
                            
                            <!-- پرونده مرتبط -->
                            <div class="md:col-span-2">
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">پرونده مرتبط (اختیاری)</label>
                                <select id="scheduleCaseId" class="input-primary">
                                    <option value="">بدون پرونده</option>
                                </select>
                            </div>
                            
                            <div class="md:col-span-2">
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">شرح کار</label>
                                <textarea id="scheduleDesc" class="input-primary resize-none" rows="3"></textarea>
                            </div>
                        </div>
                    </div>

                    <!-- نتیجه -->
                    <div class="card p-5 bg-emerald-50 dark:bg-emerald-900/20 border border-emerald-200 dark:border-emerald-900/30">
                        <label class="block text-sm text-emerald-700 dark:text-emerald-400 mb-1 font-medium">
                            <i class="fas fa-check-double ml-1"></i>
                            نتیجه (اختیاری)
                        </label>
                        <input type="text" id="scheduleResult" class="input-primary bg-white dark:bg-dark-800">
                    </div>
                </div>

                <!-- ستون کناری -->
                <div class="space-y-6">
                    <!-- برچسب -->
                    <div class="card p-5">
                        <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">برچسب</label>
                        <select id="scheduleLabel" class="input-primary">
                            <option value="">بدون برچسب</option>
                            <option value="جلسه">🔵 جلسه</option>
                            <option value="دادگاه">🔴 دادگاه</option>
                            <option value="تنظیم">🟣 تنظیم</option>
                            <option value="پیگیری">🟠 پیگیری</option>
                        </select>
                    </div>

                    <!-- اقدامات -->
                    <div class="card p-5">
                        <h4 class="text-sm font-bold text-gray-600 dark:text-gray-400 mb-4">اقدامات</h4>
                        <div class="space-y-3">
                            <button type="submit" class="w-full btn-primary">
                                <i class="fas fa-save ml-2"></i> ذخیره برنامه
                            </button>
                            <button type="button" onclick="setView('schedule')" class="w-full py-2.5 bg-gray-100 dark:bg-dark-800 text-gray-600 dark:text-gray-400 rounded-xl text-sm font-medium hover:bg-gray-200 transition">
                                انصراف
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

            <!-- صفحه فرم مالی (طراحی جدید) -->
<div id="view-financeform" class="page-view hidden animate-fade-in h-full flex flex-col">
    <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
        <div class="max-w-4xl mx-auto">
            <div class="flex items-center justify-between mb-6">
                <h2 id="financeFormTitle" class="text-xl font-bold text-gray-800 dark:text-white">
                    <i class="fas fa-money-bill-wave ml-2"></i>
                    تراکنش جدید
                </h2>
                <button onclick="setView('finance')" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                    <i class="fas fa-times text-gray-400"></i>
                </button>
            </div>
            
            <form id="financeForm" onsubmit="saveFinance(event)" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <input type="hidden" id="financeId">
                
                <!-- ستون اصلی فرم -->
                <div class="lg:col-span-2 space-y-6">
                    <div class="card p-5">
                        <h4 class="text-sm font-bold text-primary-600 dark:text-gold-500 mb-4 flex items-center gap-2">
                            <i class="fas fa-receipt"></i> اطلاعات تراکنش
                        </h4>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            
                            <!-- پرونده مرتبط -->
                            <div class="md:col-span-2">
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">پرونده مرتبط</label>
                                <div class="relative">
                                    <i class="fas fa-search absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 text-sm"></i>
                                    <input 
                                        type="text" 
                                        id="financeCaseSearch" 
                                        class="input-primary pr-10" 
                                        placeholder="جستجوی نام موکل یا پرونده..."
                                        autocomplete="off" 
                                        onkeyup="searchFinanceCases(this)"
                                    >
                                    <div id="financeCaseSuggestions" class="absolute top-full right-0 left-0 bg-white dark:bg-dark-900 border border-gray-200 dark:border-dark-700 rounded-xl shadow-xl mt-1 hidden z-50 max-h-48 overflow-y-auto"></div>
                                </div>
                                
                            </div>
                            
                            <div>
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">نوع</label>
                                <select id="financeType" class="input-primary">
                                    <option value="income">دریافت (+)</option>
                                    <option value="expense">هزینه (-)</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">تاریخ</label>
                                <input type="text" id="financeDate" class="input-primary text-center">
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">مبلغ (تومان) *</label>
                                <input type="text" id="financeAmount" class="input-primary text-center text-xl font-bold" required>
                            </div>
                            <div class="md:col-span-2">
                                <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">توضیحات</label>
                                <input type="text" id="financeDesc" class="input-primary">
                            </div>
                        </div>
                    </div>
                </div>

                <!-- ستون کناری -->
                <div class="space-y-6">
                    <div class="card p-5">
                        <h4 class="text-sm font-bold text-gray-600 dark:text-gray-400 mb-4">اقدامات</h4>
                        <div class="space-y-3">
                            <button type="submit" class="w-full btn-primary">
                                <i class="fas fa-save ml-2"></i> ذخیره تراکنش
                            </button>
                            <button type="button" onclick="setView('finance')" class="w-full py-2.5 bg-gray-100 dark:bg-dark-800 text-gray-600 dark:text-gray-400 rounded-xl text-sm font-medium hover:bg-gray-200 transition">
                                انصراف
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

            <!-- صفحه فرم کتابخانه (طراحی جدید) -->
            <div id="view-libraryform" class="page-view hidden animate-fade-in h-full flex flex-col">
                <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
                    <div class="max-w-7xl mx-auto">
                        <div class="flex items-center justify-between mb-6">
                            <h2 id="libraryFormTitle" class="text-xl font-bold text-gray-800 dark:text-white">
                                <i class="fas fa-file-alt ml-2"></i>
                                متن جدید
                            </h2>
                            <button onclick="setView('library')" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                                <i class="fas fa-times text-gray-400"></i>
                            </button>
                        </div>
                        
                        <form id="libraryForm" onsubmit="saveLibrary(event)" class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                            <input type="hidden" id="libraryId">
                            
                            <!-- ستون اصلی فرم -->
                            <div class="lg:col-span-2 space-y-6">
                                <!-- اطلاعات اصلی -->
                                <div class="card p-5">
                                    <h4 class="text-sm font-bold text-primary-600 dark:text-gold-500 mb-4 flex items-center gap-2">
                                        <i class="fas fa-file-alt"></i> اطلاعات متن
                                    </h4>
                                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                                        <div class="md:col-span-2">
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">عنوان *</label>
                                            <input type="text" id="libraryTitle" class="input-primary" required>
                                        </div>
                                        <div>
                                            <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">نوع</label>
                                            <select id="libraryType" class="input-primary">
                                                <option value="لایحه">لایحه</option>
                                                <option value="دادخواست">دادخواست</option>
                                                <option value="قرارداد">قرارداد</option>
                                                <option value="اظهارنامه">اظهارنامه</option>
                                                <option value="سایر">سایر</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <!-- متن -->
                                <div class="card p-5 flex-1">
                                    <label class="block text-sm text-gray-600 dark:text-gray-400 mb-1">متن</label>
                                    <textarea id="libraryInputText" class="input-primary resize-none font-mono text-sm leading-7 w-full h-96" rows="12"></textarea>
                                </div>
                            </div>

                            <!-- ستون کناری (تنظیمات و اقدامات) -->
                            <div class="space-y-6">
                                <!-- آمار متن -->
                                <div class="card p-5">
                                    <h4 class="text-sm font-bold text-gray-600 dark:text-gray-400 mb-4">آمار متن</h4>
                                    <div class="space-y-3 text-sm">
                                        <div class="flex justify-between">
                                            <span class="text-gray-500">تعداد کلمات:</span>
                                            <span id="wordCount" class="font-medium">0</span>
                                        </div>
                                        <div class="flex justify-between">
                                            <span class="text-gray-500">تعداد کاراکتر:</span>
                                            <span id="charCount" class="font-medium">0</span>
                                        </div>
                                    </div>
                                </div>

                                <!-- اقدامات -->
                                <div class="card p-5">
                                    <h4 class="text-sm font-bold text-gray-600 dark:text-gray-400 mb-4">اقدامات</h4>
                                    <div class="space-y-3">
                                        <button type="submit" class="w-full btn-primary">
                                            <i class="fas fa-save ml-2"></i> ذخیره متن
                                        </button>
                                        <button type="button" onclick="setView('library')" class="w-full py-2.5 bg-gray-100 dark:bg-dark-800 text-gray-600 dark:text-gray-400 rounded-xl text-sm font-medium hover:bg-gray-200 transition">
                                            انصراف
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- صفحه جزئیات پرونده -->
            <div id="view-casedetail" class="page-view hidden animate-fade-in h-full flex flex-col">
                <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
                    <div class="max-w-4xl mx-auto">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-xl font-bold text-gray-800 dark:text-white">
                                <i class="fas fa-folder-open ml-2 text-primary-500"></i>
                                جزئیات پرونده
                            </h2>
                            <button onclick="setView('cases')" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                                <i class="fas fa-times text-gray-400"></i>
                            </button>
                        </div>
                        
                        <div id="caseDetailContent" class="max-w-4xl">
                            <!-- محتوای جزئیات پرونده اینجا قرار می‌گیرد -->
                        </div>
                    </div>
                </div>
            </div>

            <!-- صفحه بدهکاران -->
            <div id="view-debtors" class="page-view hidden animate-fade-in h-full flex flex-col">
                <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
                    <div class="max-w-4xl mx-auto">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-xl font-bold text-gray-800 dark:text-white">
                                <i class="fas fa-file-invoice-dollar ml-2 text-orange-500"></i>
                                لیست بدهکاران و مانده حساب
                            </h2>
                            <button onclick="setView('finance')" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                                <i class="fas fa-times text-gray-400"></i>
                            </button>
                        </div>
                        
                        <div class="p-4 bg-orange-50 dark:bg-orange-900/10 border-b border-orange-100 dark:border-orange-900/20 mb-4">
                            <div class="relative mb-3">
                                <i class="fas fa-search absolute right-4 top-1/2 -translate-y-1/2 text-gray-400"></i>
                                <input 
                                    type="text" 
                                    id="searchDebtors" 
                                    placeholder="جستجو در بدهکاران..."
                                    class="input-primary pr-12"
                                    onkeyup="renderDebtors()"
                                >
                            </div>
                            <div class="flex justify-between items-center">
                                <span class="text-sm text-orange-800 dark:text-orange-300">مجموع کل طلب شما:</span>
                                <span id="totalDebtAmount" class="text-xl font-bold text-orange-600 dark:text-orange-400 font-mono">0</span>
                            </div>
                        </div>

                        <div id="debtorsListContent" class="space-y-3 mb-4">
                            <!-- لیست اینجا ساخته می‌شود -->
                        </div>
                        
                        <!-- Pagination -->
                        <div id="debtorsPagination" class="pagination"></div>
                    </div>
                </div>
            </div>

            <!-- ═════════════════════════════════════════════════════════════════════ -->
            <!-- صفحه تنظیمات -->
            <!-- ═════════════════════════════════════════════════════════════════════ -->
            <div id="view-settings" class="page-view hidden animate-fade-in h-full flex flex-col">
                <div class="flex-1 overflow-y-auto bg-gray-50 dark:bg-dark-950 p-4 lg:p-6">
                    <div class="max-w-4xl mx-auto">
                        <div class="flex items-center justify-between mb-6">
                            <h2 class="text-xl font-bold text-gray-800 dark:text-white">
                                <i class="fas fa-cog ml-2"></i>
                                تنظیمات سیستم
                            </h2>
                            <button onclick="setView('dashboard')" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-800 rounded-lg">
                                <i class="fas fa-times text-gray-400"></i>
                            </button>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- مدیریت داده‌ها -->
                            <div class="card p-6">
                                <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                                    <i class="fas fa-database text-blue-500"></i>
                                    مدیریت داده‌ها
                                </h3>
                                <div class="space-y-3">
                                    <button onclick="downloadBackup()" class="w-full btn-primary text-sm py-2.5 text-left flex items-center justify-between">
                                        <span><i class="fas fa-download ml-2"></i> دانلود نسخه پشتیبان (بک‌آپ)</span>
                                        <i class="fas fa-chevron-left text-xs"></i>
                                    </button>
                                    <label class="w-full btn-primary bg-gray-500 hover:bg-gray-600 text-sm py-2.5 text-left flex items-center justify-between cursor-pointer">
                                        <span><i class="fas fa-upload ml-2"></i> بازگردانی نسخه پشتیبان</span>
                                        <i class="fas fa-chevron-left text-xs"></i>
                                        <input type="file" id="restoreFile" accept=".json" style="display:none" onchange="restoreBackup(event)">
                                    </label>
                                </div>
                            </div>

                            <!-- همگام‌سازی با گوگل شیت -->
                            <div class="card p-6">
                                <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                                    <i class="fas fa-cloud-upload-alt text-green-500"></i>
                                    همگام‌سازی با گوگل شیت
                                </h3>
                                <div class="space-y-3">
                                    <button onclick="testGoogleSheetConnection()" class="w-full btn-primary bg-purple-500 hover:bg-purple-600 text-sm py-2.5 text-left flex items-center justify-between">
                                        <span><i class="fas fa-plug ml-2"></i> تست اتصال به گوگل شیت</span>
                                        <i class="fas fa-chevron-left text-xs"></i>
                                    </button>
                                    <button onclick="syncAllToGoogleSheet()" class="w-full btn-primary bg-green-500 hover:bg-green-600 text-sm py-2.5 text-left flex items-center justify-between">
                                        <span><i class="fas fa-sync ml-2"></i> ارسال تمام داده‌ها به گوگل شیت</span>
                                        <i class="fas fa-chevron-left text-xs"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- ظاهر برنامه -->
                            <div class="card p-6">
                                <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                                    <i class="fas fa-palette text-purple-500"></i>
                                    ظاهر برنامه
                                </h3>
                                <div class="space-y-3">
                                    <button onclick="toggleTheme()" class="w-full btn-primary bg-indigo-500 hover:bg-indigo-600 text-sm py-2.5 text-left flex items-center justify-between">
                                        <span><i class="fas fa-adjust ml-2"></i> تغییر حالت شب/روز</span>
                                        <i class="fas fa-chevron-left text-xs"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- درباره -->
                            <div class="card p-6">
                                <h3 class="font-bold text-gray-800 dark:text-white mb-4 flex items-center gap-2">
                                    <i class="fas fa-info-circle text-gray-500"></i>
                                    درباره برنامه
                                </h3>
                                <div class="text-sm text-gray-600 dark:text-gray-400 space-y-2">
                                    <p><strong>نام:</strong> وکیل‌یار</p>
                                    <p><strong>نسخه:</strong> 3.1</p>
                                    <p><strong>توسعه دهنده:</strong> امیرحسین بای</p>
                                    <p class="pt-2 text-xs">طراحی شده با ❤️ برای وکلای محترم</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </main>
</div>

<!-- ═════════════════════════════════════════════════════════════════════ -->
<!-- Bottom Navigation برای موبایل -->
<!-- ═════════════════════════════════════════════════════════════════════ -->
<nav class="fixed bottom-0 left-0 right-0 bg-white dark:bg-dark-900 border-t border-gray-200 dark:border-dark-800 z-40 lg:hidden">
    <div class="grid grid-cols-5 gap-1">
        <button onclick="setView('dashboard')" class="bottom-nav-item" data-view="dashboard">
            <i class="fas fa-home text-xl"></i>
            <span class="text-xs">داشبورد</span>
        </button>
        <button onclick="setView('cases')" class="bottom-nav-item" data-view="cases">
            <i class="fas fa-folder-open text-xl"></i>
            <span class="text-xs">پرونده‌ها</span>
        </button>
        <button onclick="setView('quickadd')" class="bottom-nav-item" data-view="quickadd">
            <div class="bg-primary-600 dark:bg-gold-500 rounded-full p-3 -mt-6 shadow-lg">
                <i class="fas fa-plus text-white dark:text-dark-900"></i>
            </div>
        </button>
        <button onclick="setView('schedule')" class="bottom-nav-item" data-view="schedule">
            <i class="fas fa-calendar-alt text-xl"></i>
            <span class="text-xs">تقویم</span>
        </button>
        <button onclick="setView('finance')" class="bottom-nav-item" data-view="finance">
            <i class="fas fa-wallet text-xl"></i>
            <span class="text-xs">امور مالی</span>
        </button>
    </div>
</nav>

<input type="file" id="restoreFile" accept=".json" style="display:none" onchange="restoreBackup(event)">

<?php endif; ?>

</body>
</html>