'use strict';

console.log('Api.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Load Data - بارگذاری داده‌ها از سرور
// ═══════════════════════════════════════════════════════════════════

async function loadData() {
    try {
        const res = await fetch('api.php?action=get_data');
        
        // اگر وضعیت 401 (لاگین نبودن) بود
        if (res.status === 401) {
            console.warn('دسترسی محدود (401): نمایش فرم ورود');
            
            const loginSec = document.getElementById('login-section');
            const appSec = document.getElementById('app-section');
            
            if (loginSec) loginSec.classList.remove('hidden');
            if (appSec) appSec.classList.add('hidden');
            
            return; 
        }

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        
        const data = await res.json();
        
        if (data.success) {
            const loginSec = document.getElementById('login-section');
            const appSec = document.getElementById('app-section');
            
            if (loginSec) loginSec.classList.add('hidden');
            if (appSec) appSec.classList.remove('hidden');

            db = data.data;
            VakilYar.db = db;
            
            // اطمینان از وجود آرایه‌ها
            ['schedule', 'cases', 'finance', 'library'].forEach(key => {
                if (!db[key]) db[key] = [];
            });
            
            refreshAll();
        } else {
            throw new Error(data.message || 'خطا در بارگذاری داده‌ها');
        }
    } catch (err) {
        if (err.message && err.message.includes('401')) return;

        console.error('Load error:', err);
        Swal.fire({
            icon: 'error',
            title: 'خطا در بارگذاری',
            text: err.message,
            confirmButtonText: 'تلاش مجدد'
        }).then(() => loadData());
    }
}

// ═══════════════════════════════════════════════════════════════════
// Save Data - ذخیره داده‌ها در سرور
// ═══════════════════════════════════════════════════════════════════

async function saveData(syncType = null, syncItem = null) {
    try {
        const body = { 
            db: VakilYar.db,
            csrf_token: window.CSRF_TOKEN || ''
        };
        
        if (syncType && syncItem) {
            body.syncType = syncType;
            body.syncItem = syncItem;
        }
        
        const res = await fetch('api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            credentials: 'include'
        });
        
        if (res.status === 401) {
            console.warn('نشست منقضی شد');
            location.reload();
            return false;
        }

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        
        const data = await res.json();
        
        if (data.success) {
            showSyncStatus();
            return true;
        } else {
            throw new Error(data.message || 'خطا در ذخیره');
        }
    } catch (err) {
        console.error('Save error:', err);
        Swal.fire({
            icon: 'error',
            title: 'خطا در ذخیره',
            text: 'لطفاً اتصال اینترنت را چک کنید و دوباره تلاش کنید',
            confirmButtonText: 'باشه'
        });
        return false;
    }
}

// ═══════════════════════════════════════════════════════════════════
// Show Sync Status - نمایش وضعیت سینک
// ═══════════════════════════════════════════════════════════════════

function showSyncStatus() {
    const el = document.getElementById('syncStatus');
    if (el) {
        el.classList.remove('hidden');
        el.classList.add('flex');
        setTimeout(() => {
            el.classList.add('hidden');
            el.classList.remove('flex');
        }, 2000);
    }
}

// ═══════════════════════════════════════════════════════════════════
// Refresh All - بروزرسانی همه بخش‌ها
// ═══════════════════════════════════════════════════════════════════

function refreshAll() {
    renderDashboard();
    renderCases();
    renderSchedule();
    renderFinance();
    renderLibrary();
    updateCaseSelects();
}

// ═══════════════════════════════════════════════════════════════════
// Update Case Selects - بروزرسانی لیست پرونده‌ها در select ها
// ═══════════════════════════════════════════════════════════════════

function updateCaseSelects() {
    const options = '<option value="">بدون پرونده</option>' + 
        db.cases.map(c => `<option value="${c.id}">${escapeHtml(c.name)} - ${escapeHtml(c.title)} ${c.archiveNo ? '('+escapeHtml(c.archiveNo)+')' : ''}</option>`).join('');
    
    const scheduleSelect = document.getElementById('scheduleCaseId');
    const financeSelect = document.getElementById('financeCaseId');

    if (scheduleSelect) scheduleSelect.innerHTML = options;
    if (financeSelect) financeSelect.innerHTML = options;
}

// ═══════════════════════════════════════════════════════════════════
// Logout - خروج از سیستم
// ═══════════════════════════════════════════════════════════════════

async function logout() {
    const result = await Swal.fire({
        icon: 'question',
        title: 'خروج از سیستم',
        text: 'آیا می‌خواهید خارج شوید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر'
    });
    
    if (result.isConfirmed) {
        await fetch('api.php?action=logout');
        location.reload();
    }
}