'use strict';

console.log('Utils.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Debounce Function - تابع تاخیر
// ═══════════════════════════════════════════════════════════════════

function debounce(func, wait, timerId) {
    return function executedFunction(...args) {
        clearTimeout(VakilYar.debounceTimers[timerId]);
        VakilYar.debounceTimers[timerId] = setTimeout(() => func.apply(this, args), wait);
    };
}

// ═══════════════════════════════════════════════════════════════════
// Escape HTML - جلوگیری از XSS
// ═══════════════════════════════════════════════════════════════════

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ═══════════════════════════════════════════════════════════════════
// Number Conversion - تبدیل اعداد
// ═══════════════════════════════════════════════════════════════════

// تبدیل اعداد فارسی/عربی به انگلیسی
function convertToEnglishNumbers(str) {
    if (!str) return str;
    const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    
    for (let i = 0; i < 10; i++) {
        str = str.replace(new RegExp(persianNumbers[i], 'g'), i);
        str = str.replace(new RegExp(arabicNumbers[i], 'g'), i);
    }
    return str;
}

// تبدیل اعداد انگلیسی به فارسی
function convertToPersianNumbers(str) {
    if (!str) return str;
    const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return str.toString().replace(/[0-9]/g, d => persianNumbers[d]);
}

// ═══════════════════════════════════════════════════════════════════
// Number Formatting - فرمت اعداد
// ═══════════════════════════════════════════════════════════════════

// جداکننده هزارگان
function formatNumber(num) {
    if (!num) return '0';
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// حذف جداکننده و تبدیل به عدد
function parseFormattedNumber(str) {
    if (!str) return 0;
    return parseInt(str.replace(/,/g, '')) || 0;
}

// ═══════════════════════════════════════════════════════════════════
// Pagination Helper - کمکی صفحه‌بندی
// ═══════════════════════════════════════════════════════════════════

function renderPagination(containerId, totalItems, currentPage, itemsPerPage, onPageChange) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const totalPages = Math.ceil(totalItems / itemsPerPage);
    if (totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let html = `
        <button onclick="${onPageChange}(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>
            <i class="fas fa-chevron-right"></i>
        </button>
    `;
    
    if (currentPage > 3) {
        html += `<button onclick="${onPageChange}(1)">1</button>`;
        if (currentPage > 4) html += `<span class="px-2">...</span>`;
    }
    
    for (let i = Math.max(1, currentPage - 2); i <= Math.min(totalPages, currentPage + 2); i++) {
        html += `<button onclick="${onPageChange}(${i})" class="${i === currentPage ? 'active' : ''}">${i}</button>`;
    }
    
    if (currentPage < totalPages - 2) {
        if (currentPage < totalPages - 3) html += `<span class="px-2">...</span>`;
        html += `<button onclick="${onPageChange}(${totalPages})">${totalPages}</button>`;
    }
    
    html += `
        <button onclick="${onPageChange}(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>
            <i class="fas fa-chevron-left"></i>
        </button>
    `;
    
    container.innerHTML = html;
}