'use strict';

console.log('Main.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Initialize App - راه‌اندازی اولیه
// ═══════════════════════════════════════════════════════════════════

document.addEventListener('DOMContentLoaded', async () => {
    console.log('DOM Content Loaded - Initializing VakilYar...');
    
    // Set today date
    const today = getTodayPersian();
    const todayFormatted = new Date().toLocaleDateString('fa-IR');
    
    const todayDateEl = document.getElementById('todayDate');
    const todayDateScheduleEl = document.getElementById('todayDateSchedule');
    const financeDateEl = document.getElementById('financeDate');
    const scheduleDateEl = document.getElementById('scheduleDate');

    if (todayDateEl) todayDateEl.textContent = todayFormatted;
    if (todayDateScheduleEl) todayDateScheduleEl.textContent = todayFormatted;
    if (financeDateEl) financeDateEl.value = todayFormatted;
    if (scheduleDateEl) scheduleDateEl.value = todayFormatted;
    
    // Load theme
    if (localStorage.getItem('theme') === 'dark') {
        document.documentElement.classList.add('dark');
    }
    
    // Initialize charts FIRST
    initCharts();
    
    // Then load data
    await loadData();
    
    // Setup event handlers
    setupClickOutsideHandlers();
    setupInputFormatting();
    setupKeyboardShortcuts();
    setupNotifications();
    
    console.log('VakilYar initialized successfully!');
});

// ═══════════════════════════════════════════════════════════════════
// Notifications Setup - تنظیمات نوتیفیکیشن
// ═══════════════════════════════════════════════════════════════════

function setupNotifications() {
    if (!("Notification" in window)) return;
    
    if (Notification.permission === "default") {
        setTimeout(() => {
            Notification.requestPermission();
        }, 3000);
    }
    
    // Check reminders every 5 minutes
    setInterval(checkReminders, 300000);
    
    // Initial check
    setTimeout(checkReminders, 5000);
}

// ═══════════════════════════════════════════════════════════════════
// Check Reminders - بررسی یادآورها
// ═══════════════════════════════════════════════════════════════════

function checkReminders() {
    if (Notification.permission !== "granted") return;

    const now = new Date();
    
    db.schedule.forEach(s => {
        if (s.is_done) return;
        
        const eventDate = shamsiToMiladi(s.date);
        if (!eventDate) return;
        
        const timeParts = s.time ? s.time.split(':') : ['09', '00'];
        eventDate.setHours(parseInt(timeParts[0]), parseInt(timeParts[1]), 0);
        
        const diffMs = eventDate - now;
        const diffHours = diffMs / (1000 * 60 * 60);

        const id24 = `notif_24_${s.id}`;
        const id1 = `notif_1_${s.id}`;

        // 24 hours before notification
        if (diffHours > 23 && diffHours < 24.1 && !localStorage.getItem(id24)) {
            sendNotification(
                `📅 یادآوری فردا: ${s.client || 'برنامه'}`, 
                `فردا ساعت ${s.time} برنامه "${s.label || 'جلسه'}" دارید.`
            );
            localStorage.setItem(id24, 'sent');
        }

        // 1 hour before notification
        if (diffHours > 0.8 && diffHours < 1.1 && !localStorage.getItem(id1)) {
            const urgency = s.label === 'دادگاه' ? '🚨 مهم: ' : '⏰ ';
            sendNotification(
                `${urgency}یک ساعت تا جلسه`, 
                `ساعت ${s.time} با ${s.client || 'موکل'} - ${s.desc || ''}`
            );
            localStorage.setItem(id1, 'sent');
        }
        
        // Overdue notification (for important events)
        if (diffHours < 0 && diffHours > -24 && !localStorage.getItem(`overdue_${s.id}`)) {
            if (s.label === 'دادگاه' || s.label === 'تنظیم') {
                sendNotification(
                    `⚠️ مهلت گذشت!`, 
                    `برنامه ${s.client || ''} در تاریخ ${s.date} انجام نشده است.`
                );
                localStorage.setItem(`overdue_${s.id}`, 'sent');
            }
        }
    });
}

// ═══════════════════════════════════════════════════════════════════
// Send Notification - ارسال نوتیفیکیشن
// ═══════════════════════════════════════════════════════════════════

function sendNotification(title, body) {
    try {
        const notif = new Notification(title, {
            body: body,
            icon: 'img/vakilyar.png',
            dir: 'rtl',
            tag: title,
            requireInteraction: false
        });
        
        // Auto close after 10 seconds
        setTimeout(() => {
            notif.close();
        }, 10000);
        
        // Handle click
        notif.onclick = function() {
            window.focus();
            setView('schedule');
            notif.close();
        };
    } catch (err) {
        console.error('Notification error:', err);
    }
}

// ═══════════════════════════════════════════════════════════════════
// Service Worker Registration (PWA)
// ═══════════════════════════════════════════════════════════════════

if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js')
            .then(registration => {
                console.log('SW registered:', registration.scope);
            })
            .catch(error => {
                console.log('SW registration failed:', error);
            });
    });
}

// ═══════════════════════════════════════════════════════════════════
// Global Error Handler - مدیریت خطاهای گلوبال
// ═══════════════════════════════════════════════════════════════════

window.onerror = function(message, source, lineno, colno, error) {
    console.error('Global error:', { message, source, lineno, colno, error });
    return false;
};

window.addEventListener('unhandledrejection', function(event) {
    console.error('Unhandled promise rejection:', event.reason);
});

// ═══════════════════════════════════════════════════════════════════
// Expose Functions to Global Scope - دسترسی گلوبال توابع
// ═══════════════════════════════════════════════════════════════════

// Navigation & UI
window.setView = setView;
window.toggleTheme = toggleTheme;
window.toggleUserMenu = toggleUserMenu;
window.logout = logout;

// Cases
window.renderCases = renderCases;
window.debouncedRenderCases = debouncedRenderCases;
window.goToCasesPage = goToCasesPage;
window.openCaseModal = openCaseModal;
window.editCase = editCase;
window.saveCase = saveCase;
window.deleteCase = deleteCase;
window.showCaseDetail = showCaseDetail;
window.toggleProsecutor = toggleProsecutor;
window.toggleExecution = toggleExecution;

// Schedule
window.renderSchedule = renderSchedule;
window.debouncedRenderSchedule = debouncedRenderSchedule;
window.goToSchedulePage = goToSchedulePage;
window.togglePastSchedule = togglePastSchedule;
window.toggleCalendarView = toggleCalendarView;
window.changeMonth = changeMonth;
window.openDaySchedules = openDaySchedules;
window.openScheduleModal = openScheduleModal;
window.saveSchedule = saveSchedule;
window.toggleScheduleDone = toggleScheduleDone;
window.deleteSchedule = deleteSchedule;
window.debouncedSuggestClients = debouncedSuggestClients;
window.suggestClients = suggestClients;
window.selectClient = selectClient;
window.debouncedSearchScheduleCases = debouncedSearchScheduleCases;
window.selectCaseForSelect = selectCaseForSelect;
window.selectClientAndCase = selectClientAndCase;

// Finance
window.renderFinance = renderFinance;
window.debouncedRenderFinance = debouncedRenderFinance;
window.goToFinancePage = goToFinancePage;
window.clearDateFilters = clearDateFilters;
window.openFinanceModal = openFinanceModal;
window.editFinance = editFinance;
window.saveFinance = saveFinance;
window.deleteFinance = deleteFinance;
window.debouncedSearchFinanceCases = debouncedSearchFinanceCases;
window.searchFinanceCases = searchFinanceCases;
window.selectFinanceCase = selectFinanceCase;
// Debtors
window.calculateDebtors = calculateDebtors;
window.renderDebtors = renderDebtors;
window.debouncedRenderDebtors = debouncedRenderDebtors;
window.goToDebtorsPage = goToDebtorsPage;

// Library
window.renderLibrary = renderLibrary;
window.debouncedRenderLibrary = debouncedRenderLibrary;
window.viewLibrary = viewLibrary;
window.openLibraryModal = openLibraryModal;
window.editLibrary = editLibrary;
window.saveLibrary = saveLibrary;
window.deleteLibrary = deleteLibrary;
window.copyLibraryContent = copyLibraryContent;

// Backup & Sync
window.downloadBackup = downloadBackup;
window.restoreBackup = restoreBackup;
window.syncAllToGoogleSheet = syncAllToGoogleSheet;
window.testGoogleSheetConnection = testGoogleSheetConnection;

// ═══════════════════════════════════════════════════════════════════
// End of main.js
// ═══════════════════════════════════════════════════════════════════

console.log('All modules loaded successfully! 🚀');