'use strict';

console.log('Dashboard.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Render Dashboard - رندر داشبورد
// ═══════════════════════════════════════════════════════════════════

function renderDashboard() {
    const today = getTodayPersian();
    
    // Stats
    const activeCases = db.cases.filter(c => c.status === 'جاری').length;
    const todaySchedules = db.schedule.filter(s => comparePersianDates(s.date, today) === 0).length;
    const income = db.finance.filter(f => f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
    const expense = db.finance.filter(f => f.type === 'expense').reduce((a, b) => a + Number(b.amount), 0);
    const totalCases = db.cases.length;
    
    // Calculate monthly comparison
    const currentMonth = getCurrentPersianMonth();
    const lastMonth = getLastPersianMonth();
    
    const currentMonthCases = db.cases.filter(c => {
        if (!c.updatedAt) return false;
        const caseMonth = c.updatedAt.split('/').slice(0, 2).join('/');
        return caseMonth === currentMonth;
    }).length;
    
    const lastMonthCases = db.cases.filter(c => {
        if (!c.updatedAt) return false;
        const caseMonth = c.updatedAt.split('/').slice(0, 2).join('/');
        return caseMonth === lastMonth;
    }).length;
    
    const monthlyChange = lastMonthCases > 0 ? 
        Math.round(((currentMonthCases - lastMonthCases) / lastMonthCases) * 100) : 
        (currentMonthCases > 0 ? 100 : 0);
    
    // Update UI elements
    const updates = {
        'stat-cases': activeCases,
        'stat-today': todaySchedules,
        'stat-income': formatNumber(income),
        'stat-balance': formatNumber(income - expense)
    };
    
    Object.entries(updates).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    });
    
    // Monthly comparison
    const monthlyComparisonEl = document.getElementById('monthly-comparison');
    if (monthlyComparisonEl) {
        const changeIcon = monthlyChange >= 0 ? 'fa-arrow-up' : 'fa-arrow-down';
        const changeClass = monthlyChange >= 0 ? 'text-emerald-600' : 'text-red-600';
        
        monthlyComparisonEl.innerHTML = `
            <span class="text-xs ${changeClass} font-medium">
                ${Math.abs(monthlyChange)}% <i class="fas ${changeIcon}"></i>
            </span>
            <span class="text-xs text-gray-500 mr-2">(کل : ${totalCases})</span>
        `;
    }
    
    // Upcoming schedules
    renderUpcomingSchedules(today);
    
    // Recent cases
    renderRecentCases();
    
    // Recent finance
    renderRecentFinance();
    
    // Update charts
    updateCharts();
}

// ═══════════════════════════════════════════════════════════════════
// Render Upcoming Schedules - برنامه‌های پیش رو
// ═══════════════════════════════════════════════════════════════════

function renderUpcomingSchedules(today) {
    const upcoming = db.schedule
        .filter(s => comparePersianDates(s.date, today) >= 0 && !s.is_done)
        .sort((a, b) => {
            const dateCompare = comparePersianDates(a.date, b.date);
            if (dateCompare !== 0) return dateCompare;
            return (a.time || '').localeCompare(b.time || '');
        })
        .slice(0, 4);
    
    const upcomingListEl = document.getElementById('upcomingList');
    if (upcomingListEl) {
        upcomingListEl.innerHTML = upcoming.length ? upcoming.map(s => {
            const idx = db.schedule.findIndex(x => x.id === s.id);
            return `
            <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-800 rounded-xl cursor-pointer hover:bg-gray-100 dark:hover:bg-dark-700 transition" onclick="openScheduleModal(${idx})">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-amber-600 dark:text-amber-400"></i>
                    </div>
                    <div>
                        <p class="font-medium text-gray-700 dark:text-gray-300">${escapeHtml(s.client) || 'بدون نام'}</p>
                        <p class="text-xs text-gray-400">${escapeHtml(s.label) || 'برنامه'}</p>
                    </div>
                </div>
                <div class="text-left">
                    <p class="font-mono text-sm font-bold text-primary-600 dark:text-gold-500">${s.date.split('/').slice(1).join('/')}</p>
                    <p class="text-xs text-gray-400">${s.time || ''}</p>
                </div>
            </div>
        `}).join('') : '<p class="text-center text-gray-400 py-4">برنامه‌ای نیست</p>';
    }
}

// ═══════════════════════════════════════════════════════════════════
// Render Recent Cases - پرونده‌های اخیر
// ═══════════════════════════════════════════════════════════════════

function renderRecentCases() {
    const recentCasesListEl = document.getElementById('recentCasesList');
    if (recentCasesListEl) {
        recentCasesListEl.innerHTML = db.cases.slice(0, 4).map(c => `
            <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-800 rounded-xl cursor-pointer hover:bg-gray-100 dark:hover:bg-dark-700 transition" onclick="showCaseDetail(${c.id})">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 ${c.status === 'جاری' ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'} rounded-lg flex items-center justify-center">
                        <i class="fas fa-folder ${c.status === 'جاری' ? 'text-emerald-600' : 'text-red-600'}"></i>
                    </div>
                    <div>
                        <p class="font-medium text-gray-700 dark:text-gray-300">${escapeHtml(c.name)}</p>
                        <p class="text-xs text-gray-400">${escapeHtml(c.title)}</p>
                    </div>
                </div>
                <span class="${c.status === 'جاری' ? 'badge-success' : 'badge-danger'} text-xs px-2 py-1 rounded">${c.status}</span>
            </div>
        `).join('') || '<p class="text-center text-gray-400 py-4">پرونده‌ای نیست</p>';
    }
}

// ═══════════════════════════════════════════════════════════════════
// Render Recent Finance - تراکنش‌های اخیر
// ═══════════════════════════════════════════════════════════════════

function renderRecentFinance() {
    const recentFinanceListEl = document.getElementById('recentFinanceList');
    if (recentFinanceListEl) {
        recentFinanceListEl.innerHTML = db.finance.slice(0, 4).map(f => {
            const cs = db.cases.find(c => c.id == f.caseId);
            const idx = db.finance.findIndex(x => x.id === f.id);
            return `
                <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-800 rounded-xl cursor-pointer hover:bg-gray-100 dark:hover:bg-dark-700 transition" onclick="editFinance(${idx})">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 ${f.type === 'income' ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'} rounded-lg flex items-center justify-center">
                            <i class="fas ${f.type === 'income' ? 'fa-arrow-down text-emerald-600' : 'fa-arrow-up text-red-600'}"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-700 dark:text-gray-300">${cs ? escapeHtml(cs.name) : 'بدون پرونده'}</p>
                            <p class="text-xs text-gray-400">${f.date || ''}</p>
                        </div>
                    </div>
                    <p class="font-mono font-bold ${f.type === 'income' ? 'text-emerald-600' : 'text-red-600'}" dir="ltr">${formatNumber(f.amount)}</p>
                </div>
            `;
        }).join('') || '<p class="text-center text-gray-400 py-4">تراکنشی نیست</p>';
    }
}

// ═══════════════════════════════════════════════════════════════════
// Initialize Charts - ساخت نمودارها
// ═══════════════════════════════════════════════════════════════════

function initCharts() {
    const casesCtx = document.getElementById('casesChart')?.getContext('2d');
    const financeCtx = document.getElementById('financeChart')?.getContext('2d');
    
    if (!casesCtx || !financeCtx) return;

    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#94a3b8' : '#64748b';
    const gridColor = isDark ? '#1e293b' : '#f1f5f9';
    
    charts.cases = new Chart(casesCtx, {
        type: 'doughnut',
        data: {
            labels: ['جاری', 'مختومه'],
            datasets: [{
                data: [0, 0],
                backgroundColor: ['#10b981', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: textColor, font: { family: 'Vazirmatn' } }
                }
            }
        }
    });
    
    charts.finance = new Chart(financeCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                { label: 'دریافت', data: [], backgroundColor: '#10b981' },
                { label: 'هزینه', data: [], backgroundColor: '#ef4444' }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color: textColor, font: { family: 'Vazirmatn' } }
                }
            },
            scales: {
                x: { grid: { color: gridColor }, ticks: { color: textColor, font: { family: 'Vazirmatn' } } },
                y: { grid: { color: gridColor }, ticks: { color: textColor } }
            }
        }
    });
    
    VakilYar.charts = charts;
}

// ═══════════════════════════════════════════════════════════════════
// Update Charts - بروزرسانی نمودارها
// ═══════════════════════════════════════════════════════════════════

function updateCharts() {
    if (!charts.cases || !charts.finance) return;
    
    // Cases chart
    const active = db.cases.filter(c => c.status === 'جاری').length;
    const closed = db.cases.filter(c => c.status === 'مختومه').length;
    charts.cases.data.datasets[0].data = [active, closed];
    charts.cases.update();
    
    // Finance chart - Last 6 months
    const months = {};
    db.finance.forEach(f => {
        if (!f.date) return;
        const month = f.date.split('/').slice(0, 2).join('/');
        if (!months[month]) months[month] = { income: 0, expense: 0 };
        if (f.type === 'income' || f.type === 'expense') {
            months[month][f.type] += Number(f.amount) || 0;
        }
    });
    
    const sortedMonths = Object.keys(months).sort().slice(-6);
    charts.finance.data.labels = sortedMonths;
    charts.finance.data.datasets[0].data = sortedMonths.map(m => months[m]?.income || 0);
    charts.finance.data.datasets[1].data = sortedMonths.map(m => months[m]?.expense || 0);
    charts.finance.update();
}

// ═══════════════════════════════════════════════════════════════════
// Update Charts Theme - بروزرسانی تم نمودارها
// ═══════════════════════════════════════════════════════════════════

function updateChartsTheme() {
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#94a3b8' : '#64748b';
    const gridColor = isDark ? '#1e293b' : '#f1f5f9';
    
    if (charts.cases) {
        charts.cases.options.plugins.legend.labels.color = textColor;
        charts.cases.update();
    }
    
    if (charts.finance) {
        charts.finance.options.plugins.legend.labels.color = textColor;
        charts.finance.options.scales.x.grid.color = gridColor;
        charts.finance.options.scales.x.ticks.color = textColor;
        charts.finance.options.scales.y.grid.color = gridColor;
        charts.finance.options.scales.y.ticks.color = textColor;
        charts.finance.update();
    }
}