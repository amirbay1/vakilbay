'use strict';

console.log('Library.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Debounced Render
// ═══════════════════════════════════════════════════════════════════

const debouncedRenderLibrary = debounce(renderLibrary, 300, 'library');

// ═══════════════════════════════════════════════════════════════════
// Render Library - رندر لیست کتابخانه
// ═══════════════════════════════════════════════════════════════════

function renderLibrary() {
    const search = document.getElementById('searchLibrary')?.value.toLowerCase() || '';
    
    const filtered = db.library.filter(l => {
        if (search && !l.title.toLowerCase().includes(search) && !(l.content || '').toLowerCase().includes(search)) return false;
        return true;
    });
    
    const list = document.getElementById('libraryList');
    if (list) {
        list.innerHTML = filtered.map(l => `
            <div onclick="viewLibrary(${l.id})" class="p-4 rounded-xl cursor-pointer transition border ${currentLibraryId == l.id ? 'bg-primary-50 dark:bg-primary-900/20 border-primary-500' : 'bg-gray-50 dark:bg-dark-800 border-transparent hover:border-gray-200'}">
                <div class="flex items-start justify-between mb-2">
                    <h4 class="font-bold text-sm">${escapeHtml(l.title)}</h4>
                    <span class="tag text-xs">${escapeHtml(l.type)}</span>
                </div>
                <p class="text-xs text-gray-400 line-clamp-2">${escapeHtml((l.content || '').substring(0, 100))}...</p>
            </div>
        `).join('') || '<p class="text-center text-gray-400 py-8">متنی یافت نشد</p>';
    }
}

// ═══════════════════════════════════════════════════════════════════
// View Library - نمایش محتوای متن
// ═══════════════════════════════════════════════════════════════════

function viewLibrary(id) {
    const l = db.library.find(x => x.id == id);
    if (!l) return;
    
    currentLibraryId = id;
    VakilYar.state.currentLibraryId = id;
    
    const empty = document.getElementById('libraryEmpty');
    const content = document.getElementById('libraryContent');
    
    if (empty) empty.classList.add('hidden');
    if (content) content.classList.remove('hidden');
    
    const titleEl = document.getElementById('libraryViewTitle');
    const typeEl = document.getElementById('libraryViewType');
    const contentEl = document.getElementById('libraryViewContent');

    if (titleEl) titleEl.textContent = l.title;
    if (typeEl) typeEl.textContent = l.type;
    if (contentEl) contentEl.textContent = l.content || '';
    
    renderLibrary();
}

// ═══════════════════════════════════════════════════════════════════
// Open Library Modal - باز کردن فرم کتابخانه
// ═══════════════════════════════════════════════════════════════════

function openLibraryModal(id = null) {
    const form = document.getElementById('libraryForm');
    if (form) form.reset();
    
    document.getElementById('libraryId').value = '';
    const title = document.getElementById('libraryFormTitle');
    if (title) title.innerHTML = '<i class="fas fa-file-alt ml-2"></i> متن جدید';
    
    if (id) {
        const l = db.library.find(x => x.id == id);
        if (l) {
            if (title) title.innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش متن';
            document.getElementById('libraryId').value = l.id;
            document.getElementById('libraryTitle').value = l.title || '';
            document.getElementById('libraryType').value = l.type || 'لایحه';
            document.getElementById('libraryInputText').value = l.content || ''; 
        }
    }
    
    setView('libraryform');
}

// ═══════════════════════════════════════════════════════════════════
// Edit Library - ویرایش متن
// ═══════════════════════════════════════════════════════════════════

function editLibrary() {
    if (currentLibraryId) openLibraryModal(currentLibraryId);
}

// ═══════════════════════════════════════════════════════════════════
// Save Library - ذخیره متن
// ═══════════════════════════════════════════════════════════════════

async function saveLibrary(e) {
    e.preventDefault();
    
    const id = document.getElementById('libraryId').value;
    const item = {
        id: id || Date.now(),
        title: document.getElementById('libraryTitle').value,
        type: document.getElementById('libraryType').value,
        content: document.getElementById('libraryInputText').value 
    };
    
    if (id) {
        const idx = db.library.findIndex(l => l.id == id);
        if (idx >= 0) db.library[idx] = item;
    } else {
        db.library.unshift(item);
    }
    
    refreshAll();
    viewLibrary(item.id);
    await saveData('library', item);
    
    Swal.fire({ icon: 'success', title: 'ذخیره شد', timer: 1500, showConfirmButton: false });
    setView('library');
}

// ═══════════════════════════════════════════════════════════════════
// Delete Library - حذف متن
// ═══════════════════════════════════════════════════════════════════

async function deleteLibrary() {
    if (!currentLibraryId) return;
    
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف متن',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.library = db.library.filter(l => l.id != currentLibraryId);
        currentLibraryId = null;
        
        const empty = document.getElementById('libraryEmpty');
        const content = document.getElementById('libraryContent');
        if (empty) empty.classList.remove('hidden');
        if (content) content.classList.add('hidden');
        
        refreshAll();
        await saveData();
        setView('library');
    }
}

// ═══════════════════════════════════════════════════════════════════
// Copy Library Content - کپی محتوا
// ═══════════════════════════════════════════════════════════════════

async function copyLibraryContent() {
    const content = document.getElementById('libraryViewContent')?.textContent;
    if (content) {
        await navigator.clipboard.writeText(content);
        Swal.fire({ 
            icon: 'success', 
            title: 'کپی شد!', 
            timer: 1000, 
            showConfirmButton: false, 
            position: 'bottom-end', 
            toast: true 
        });
    }
}