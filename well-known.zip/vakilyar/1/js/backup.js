'use strict';

console.log('Backup.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Download Backup - دانلود بک‌آپ
// ═══════════════════════════════════════════════════════════════════

function downloadBackup() {
    const dataStr = JSON.stringify(db, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_${new Date().toLocaleDateString('fa-IR').replace(/\//g, '-')}.json`;
    link.click();
    URL.revokeObjectURL(url);
    
    Swal.fire({ 
        icon: 'success', 
        title: 'بک‌آپ دانلود شد', 
        timer: 2000, 
        showConfirmButton: false 
    });
}

// ═══════════════════════════════════════════════════════════════════
// Restore Backup - بازیابی بک‌آپ
// ═══════════════════════════════════════════════════════════════════

async function restoreBackup(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const result = await Swal.fire({
        icon: 'warning',
        title: 'بازگردانی بک‌آپ',
        text: 'تمام داده‌های فعلی جایگزین می‌شوند. مطمئنید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (!result.isConfirmed) {
        event.target.value = '';
        return;
    }
    
    const reader = new FileReader();
    reader.onload = async (e) => {
        try {
            const restored = JSON.parse(e.target.result);
            if (restored.cases && restored.finance && restored.library && restored.schedule) {
                db = restored;
                VakilYar.db = db;
                await saveData();
                refreshAll();
                Swal.fire({ 
                    icon: 'success', 
                    title: 'بازگردانی موفق', 
                    confirmButtonText: 'باشه' 
                });
            } else {
                throw new Error('فرمت نامعتبر');
            }
        } catch (err) {
            Swal.fire({ 
                icon: 'error', 
                title: 'خطا', 
                text: 'فایل بک‌آپ معتبر نیست', 
                confirmButtonText: 'باشه' 
            });
        }
        event.target.value = '';
    };
    reader.readAsText(file);
}

// ═══════════════════════════════════════════════════════════════════
// Sync All to Google Sheet - ارسال همه به گوگل شیت
// ═══════════════════════════════════════════════════════════════════

async function syncAllToGoogleSheet() {
    const result = await Swal.fire({
        icon: 'question',
        title: 'ارسال به گوگل شیت',
        text: 'ادامه می‌دهید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر'
    });
    
    if (!result.isConfirmed) return;
    
    Swal.fire({ 
        title: 'در حال ارسال...', 
        allowOutsideClick: false, 
        didOpen: () => Swal.showLoading() 
    });
    
    try {
        let count = 0;
        for (const item of db.cases) { await saveData('cases', item); count++; }
        for (const item of db.finance) { await saveData('finance', item); count++; }
        for (const item of db.schedule) { await saveData('schedule', item); count++; }
        for (const item of db.library) { await saveData('library', item); count++; }
        
        Swal.fire({ 
            icon: 'success', 
            title: 'ارسال موفق', 
            text: `${count} مورد ارسال شد`, 
            confirmButtonText: 'عالی' 
        });
    } catch (err) {
        Swal.fire({ 
            icon: 'error', 
            title: 'خطا در ارسال', 
            confirmButtonText: 'باشه' 
        });
    }
}

// ═══════════════════════════════════════════════════════════════════
// Test Google Sheet Connection - تست اتصال گوگل شیت
// ═══════════════════════════════════════════════════════════════════

async function testGoogleSheetConnection() {
    try {
        const res = await fetch('api.php?action=test_google');
        const data = await res.json();
        
        if (data.success) {
            Swal.fire({ 
                icon: 'success', 
                title: 'متصل است! ✅', 
                confirmButtonText: 'عالی' 
            });
        } else {
            Swal.fire({ 
                icon: 'error', 
                title: 'متصل نیست ❌', 
                text: data.message || '', 
                confirmButtonText: 'باشه' 
            });
        }
    } catch (err) {
        Swal.fire({ 
            icon: 'error', 
            title: 'خطا', 
            text: 'مشکل در ارتباط با سرور', 
            confirmButtonText: 'باشه' 
        });
    }
}