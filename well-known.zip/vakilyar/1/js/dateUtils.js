'use strict';

console.log('DateUtils.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Persian Date Comparison - مقایسه تاریخ شمسی
// ═══════════════════════════════════════════════════════════════════

function comparePersianDates(date1, date2) {
    const d1 = convertToEnglishNumbers(date1 || '');
    const d2 = convertToEnglishNumbers(date2 || '');
    
    const normalize = (d) => {
        const parts = d.split('/');
        if (parts.length !== 3) return 0;
        return parseInt(parts[0]) * 10000 + parseInt(parts[1]) * 100 + parseInt(parts[2]);
    };
    
    return normalize(d1) - normalize(d2);
}

// ═══════════════════════════════════════════════════════════════════
// Today's Date - تاریخ امروز
// ═══════════════════════════════════════════════════════════════════

function getTodayPersian() {
    return convertToEnglishNumbers(new Date().toLocaleDateString('fa-IR'));
}

// ═══════════════════════════════════════════════════════════════════
// Days Until - روزهای باقیمانده
// ═══════════════════════════════════════════════════════════════════

function getDaysUntil(targetDate) {
    const today = getTodayPersian();
    const t = convertToEnglishNumbers(today).split('/').map(Number);
    const d = convertToEnglishNumbers(targetDate || '').split('/').map(Number);
    
    if (t.length !== 3 || d.length !== 3) return 0;
    
    const todayDays = persianDateToDays(t[0], t[1], t[2]);
    const targetDays = persianDateToDays(d[0], d[1], d[2]);
    
    return targetDays - todayDays;
}

// ═══════════════════════════════════════════════════════════════════
// Persian Date to Days - تبدیل تاریخ شمسی به تعداد روز
// ═══════════════════════════════════════════════════════════════════

function persianDateToDays(year, month, day) {
    // تعداد روزهای سپری شده از مبدا
    let days = (year - 1) * 365;
    
    // اضافه کردن روزهای کبیسه
    days += Math.floor((year - 1) / 4);
    
    // اضافه کردن روزهای ماه‌های قبل
    for (let m = 1; m < month; m++) {
        if (m <= 6) days += 31;
        else if (m <= 11) days += 30;
        else days += 29;
    }
    
    // اضافه کردن روز جاری
    days += day;
    
    return days;
}

// ═══════════════════════════════════════════════════════════════════
// Persian Month Name - نام ماه
// ═══════════════════════════════════════════════════════════════════

function getPersianMonthName(month) {
    const months = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 
                    'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    return months[month] || '';
}

// ═══════════════════════════════════════════════════════════════════
// Days in Month - تعداد روزهای ماه
// ═══════════════════════════════════════════════════════════════════

function getDaysInPersianMonth(year, month) {
    if (month <= 6) return 31;
    if (month <= 11) return 30;
    return isPersianLeapYear(year) ? 30 : 29;
}

// ═══════════════════════════════════════════════════════════════════
// Leap Year Check - سال کبیسه
// ═══════════════════════════════════════════════════════════════════

function isPersianLeapYear(year) {
    const remainder = year % 33;
    return [1, 5, 9, 13, 17, 22, 26, 30].includes(remainder);
}

// ═══════════════════════════════════════════════════════════════════
// ★★★ اصلاح شده: First Day of Week - اولین روز هفته در ماه ★★★
// ═══════════════════════════════════════════════════════════════════

function getFirstDayOfWeek(year, month) {
    // تبدیل تاریخ شمسی به میلادی
    const miladiDate = shamsiToMiladi(`${year}/${month}/01`);
    if (!miladiDate) return 0;
    
    // روز هفته در میلادی (0=یکشنبه تا 6=شنبه)
    const dayOfWeek = miladiDate.getDay();
    
    // تبدیل به فرمت ایرانی (0=شنبه تا 6=جمعه)
    // در جاوااسکریپت: 0=یکشنبه, 1=دوشنبه, ..., 6=شنبه
    // در تقویم ایرانی: 0=شنبه, 1=یکشنبه, ..., 6=جمعه
    
    const persianDayIndex = (dayOfWeek + 1) % 7;
    return persianDayIndex;
}

// ═══════════════════════════════════════════════════════════════════
// Persian Day Name - نام روز هفته
// ═══════════════════════════════════════════════════════════════════

function getPersianDayName(dateStr) {
    const days = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];
    
    try {
        const miladiDate = shamsiToMiladi(dateStr);
        if (!miladiDate) return '';
        
        const dayOfWeek = miladiDate.getDay();
        // تبدیل به ایندکس ایرانی
        const persianDayIndex = (dayOfWeek + 1) % 7;
        return days[persianDayIndex];
    } catch {
        return '';
    }
}

// ═══════════════════════════════════════════════════════════════════
// Current & Last Month - ماه جاری و قبلی
// ═══════════════════════════════════════════════════════════════════

function getCurrentPersianMonth() {
    const today = new Date().toLocaleDateString('fa-IR');
    return convertToEnglishNumbers(today).split('/').slice(0, 2).join('/');
}

function getLastPersianMonth() {
    const today = new Date();
    const lastMonth = new Date(today);
    lastMonth.setMonth(today.getMonth() - 1);
    return convertToEnglishNumbers(lastMonth.toLocaleDateString('fa-IR')).split('/').slice(0, 2).join('/');
}

// ═══════════════════════════════════════════════════════════════════
// ★★★ اصلاح شده: Shamsi to Miladi Conversion ★★★
// ═══════════════════════════════════════════════════════════════════

function shamsiToMiladi(shamsiDate) {
    if (!shamsiDate) return null;
    
    const parts = convertToEnglishNumbers(shamsiDate).split('/').map(Number);
    if (parts.length !== 3) return null;
    
    let jy = parts[0], jm = parts[1], jd = parts[2];
    
    // الگوریتم تبدیل شمسی به میلادی
    jy += 1595;
    let days = -355668 + (365 * jy) + (Math.floor(jy / 33) * 8) + Math.floor(((jy % 33) + 3) / 4) + jd;
    
    if (jm < 7) {
        days += (jm - 1) * 31;
    } else {
        days += ((jm - 7) * 30) + 186;
    }
    
    let gy = 400 * Math.floor(days / 146097);
    days %= 146097;
    
    if (days > 36524) {
        gy += 100 * Math.floor(--days / 36524);
        days %= 36524;
        if (days >= 365) days++;
    }
    
    gy += 4 * Math.floor(days / 1461);
    days %= 1461;
    
    if (days > 365) {
        gy += Math.floor((days - 1) / 365);
        days = (days - 1) % 365;
    }
    
    let gd = days + 1;
    const sal_a = [0, 31, ((gy % 4 === 0 && gy % 100 !== 0) || (gy % 400 === 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm = 0;
    
    for (gm = 0; gm < 13 && gd > sal_a[gm]; gm++) {
        gd -= sal_a[gm];
    }
    
    return new Date(gy, gm - 1, gd);
}