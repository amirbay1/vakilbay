'use strict';

console.log('Cases.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Debounced Render
// ═══════════════════════════════════════════════════════════════════

const debouncedRenderCases = debounce(renderCases, 300, 'cases');

// ═══════════════════════════════════════════════════════════════════
// Render Cases - رندر لیست پرونده‌ها
// ═══════════════════════════════════════════════════════════════════

function renderCases() {
    const search = document.getElementById('searchCases')?.value.toLowerCase() || '';
    const statusFilter = document.getElementById('filterCaseStatus')?.value || '';
    const typeFilter = document.getElementById('filterCaseType')?.value || '';
    
    const filtered = db.cases.filter(c => {
        if (search && !JSON.stringify(c).toLowerCase().includes(search)) return false;
        if (statusFilter && c.status !== statusFilter) return false;
        if (typeFilter && c.type !== typeFilter) return false;
        return true;
    }).sort((a, b) => (b.officeNo || 0) - (a.officeNo || 0));
    
    const { currentPage, itemsPerPage } = pagination.cases;
    const startIdx = (currentPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const paginatedItems = filtered.slice(startIdx, endIdx);
    
    const grid = document.getElementById('casesGrid');
    if (grid) {
        grid.className = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 pb-4 content-start";
        grid.innerHTML = paginatedItems.map(c => renderCaseCard(c)).join('') || 
            '<div class="col-span-full text-center py-12 text-gray-400"><i class="fas fa-folder-open text-4xl mb-4"></i><p>پرونده‌ای یافت نشد</p></div>';
    }
    
    renderPagination('casesPagination', filtered.length, pagination.cases.currentPage, pagination.cases.itemsPerPage, 'goToCasesPage');
}

// ═══════════════════════════════════════════════════════════════════
// Render Case Card - کارت پرونده
// ═══════════════════════════════════════════════════════════════════

function renderCaseCard(c) {
    const tags = (c.tags && c.tags.trim()) ? c.tags.split(',').filter(t => t.trim()).slice(0, 2).map(t => 
        `<span class="inline-block px-1.5 py-0.5 text-[10px] rounded bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">${escapeHtml(t.trim())}</span>`
    ).join('') : '';
    
    return `
        <div class="card p-3 cursor-pointer hover:border-primary-500 dark:hover:border-gold-500 transition group" onclick="showCaseDetail(${c.id})">
            <div class="flex items-center justify-between mb-2">
                <div class="flex items-center gap-2">
                    <div class="w-8 h-8 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center">
                        <i class="fas fa-user text-primary-600 dark:text-primary-400 text-sm"></i>
                    </div>
                    <div>
                        <h4 class="font-bold text-gray-800 dark:text-white text-sm">${escapeHtml(c.name)}</h4>
                        <p class="text-xs text-gray-400 font-mono">${escapeHtml(c.mobile)}</p>
                    </div>
                </div>
                <div class="flex items-center gap-1">
                    <span class="text-[10px] font-mono bg-gray-100 dark:bg-gray-700 text-gray-500 px-1.5 py-0.5 rounded border border-gray-200 dark:border-gray-600" title="شماره دفتر">
                        #${c.officeNo || '-'}
                    </span>
                    <span class="${c.status === 'جاری' ? 'badge-success' : 'badge-danger'} text-[10px] px-1.5 py-0.5 rounded">${c.status}</span>
                </div>
            </div>
            
            <p class="text-sm text-gray-700 dark:text-gray-300 mb-1 truncate font-bold">${escapeHtml(c.title)}</p>
            
            <div class="flex items-center justify-between text-[10px] text-gray-400">
                <div class="flex items-center gap-2">
                    <span>${escapeHtml(c.type)}</span>
                    ${c.archiveNo ? `<span class="bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 px-1 rounded font-mono dir-ltr">📁 ${escapeHtml(c.archiveNo)}</span>` : ''}
                </div>
                <div class="flex gap-1">
                    ${c.hasProsecutor ? '<span title="دادسرا">⚖️</span>' : ''}
                    ${c.hasExecution ? '<span title="اجرای احکام">📋</span>' : ''}
                </div>
            </div>
            
            ${tags ? `<div class="flex flex-wrap gap-1 mt-2">${tags}</div>` : ''}
            
            <div class="flex items-center justify-between mt-2 pt-2 border-t border-gray-100 dark:border-dark-700">
                <span class="text-[10px] text-gray-400 font-mono">${c.updatedAt || '-'}</span>
                <div class="flex gap-0.5 opacity-100 lg:opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onclick="event.stopPropagation(); editCase(${c.id})" class="p-1.5 hover:bg-gray-100 dark:hover:bg-dark-700 rounded transition" title="ویرایش">
                        <i class="fas fa-edit text-gray-400 text-xs"></i>
                    </button>
                    <button onclick="event.stopPropagation(); deleteCase(${c.id})" class="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition" title="حذف">
                        <i class="fas fa-trash text-red-400 text-xs"></i>
                    </button>
                </div>
            </div>
        </div>
    `;
}

// ═══════════════════════════════════════════════════════════════════
// Pagination - صفحه‌بندی
// ═══════════════════════════════════════════════════════════════════

function goToCasesPage(page) {
    pagination.cases.currentPage = page;
    renderCases();
    document.getElementById('casesGrid')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ═══════════════════════════════════════════════════════════════════
// Open Case Modal - باز کردن فرم پرونده
// ═══════════════════════════════════════════════════════════════════

function openCaseModal(id = null) {
    const form = document.getElementById('caseForm');
    if (form) form.reset();
    
    document.getElementById('caseId').value = '';
    const caseFormTitle = document.getElementById('caseFormTitle');
    if (caseFormTitle) caseFormTitle.innerHTML = '<i class="fas fa-folder-plus ml-2"></i> پرونده جدید';
    
    const prosecutorFields = document.getElementById('prosecutorFields');
    const executionFields = document.getElementById('executionFields');
    if (prosecutorFields) prosecutorFields.classList.add('hidden');
    if (executionFields) executionFields.classList.add('hidden');
    
    if (id) {
        const c = db.cases.find(x => x.id == id);
        if (c) {
            if (caseFormTitle) caseFormTitle.innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش پرونده';
            
            const fields = {
                'caseId': c.id,
                'caseName': c.name || '',
                'caseMobile': c.mobile || '',
                'caseNational': c.national || '',
                'caseBirth': c.birthDate || '',
                'caseAddress': c.address || '',
                'caseTitle': c.title || '',
                'caseType': c.type || 'حقوقی',
                'caseStatus': c.status || 'جاری',
                'caseBranch': c.branch || '',
                'caseArchiveNo': c.archiveNo || '',
                'caseOpponent': c.opponent || '',
                'caseContract': c.contract || '',
                'casePrice': formatNumber(c.totalPrice || ''),
                'caseProsecutorBranch': c.prosecutorBranch || '',
                'caseProsecutorArchive': c.prosecutorArchive || '',
                'caseExecutionBranch': c.executionBranch || '',
                'caseExecutionArchive': c.executionArchive || '',
                'caseTags': c.tags || '',
                'caseNotes': c.notes || ''
            };
            
            Object.entries(fields).forEach(([id, value]) => {
                const el = document.getElementById(id);
                if (el) el.value = value;
            });
            
            const hasProsecutorEl = document.getElementById('caseHasProsecutor');
            const hasExecutionEl = document.getElementById('caseHasExecution');
            
            if (hasProsecutorEl) hasProsecutorEl.checked = c.hasProsecutor || false;
            if (hasExecutionEl) hasExecutionEl.checked = c.hasExecution || false;
            
            if (c.hasProsecutor && prosecutorFields) prosecutorFields.classList.remove('hidden');
            if (c.hasExecution && executionFields) executionFields.classList.remove('hidden');
        }
    }
    
    setView('caseform');
}

function editCase(id) {
    openCaseModal(id);
}

// ═══════════════════════════════════════════════════════════════════
// Save Case - ذخیره پرونده
// ═══════════════════════════════════════════════════════════════════

async function saveCase(e) {
    e.preventDefault();
    
    const id = document.getElementById('caseId').value;
    
    let officeNo;
    if (id) {
        const existingCase = db.cases.find(c => c.id == id);
        officeNo = existingCase ? (existingCase.officeNo || '-') : '-';
    } else {
        const maxNo = db.cases.reduce((max, c) => Math.max(max, parseInt(c.officeNo || 0)), 0);
        officeNo = maxNo + 1;
    }

    const rawPrice = convertToEnglishNumbers(document.getElementById('casePrice').value);
    const cleanPrice = parseFormattedNumber(rawPrice);

    const item = {
        id: id || Date.now(),
        officeNo: officeNo,
        name: document.getElementById('caseName').value,
        mobile: convertToEnglishNumbers(document.getElementById('caseMobile').value),
        national: convertToEnglishNumbers(document.getElementById('caseNational').value),
        birthDate: convertToEnglishNumbers(document.getElementById('caseBirth').value),
        address: document.getElementById('caseAddress').value,
        title: document.getElementById('caseTitle').value,
        type: document.getElementById('caseType').value,
        status: document.getElementById('caseStatus').value,
        branch: document.getElementById('caseBranch').value,
        archiveNo: convertToEnglishNumbers(document.getElementById('caseArchiveNo').value),
        opponent: document.getElementById('caseOpponent').value,
        contract: convertToEnglishNumbers(document.getElementById('caseContract').value),
        totalPrice: cleanPrice,
        hasProsecutor: document.getElementById('caseHasProsecutor').checked,
        prosecutorBranch: document.getElementById('caseProsecutorBranch').value,
        prosecutorArchive: convertToEnglishNumbers(document.getElementById('caseProsecutorArchive').value),
        hasExecution: document.getElementById('caseHasExecution').checked,
        executionBranch: document.getElementById('caseExecutionBranch').value,
        executionArchive: convertToEnglishNumbers(document.getElementById('caseExecutionArchive').value),
        tags: document.getElementById('caseTags').value,
        notes: document.getElementById('caseNotes').value,
        updatedAt: new Date().toLocaleDateString('fa-IR')
    };
    
    if (id) {
        const idx = db.cases.findIndex(c => c.id == id);
        if (idx >= 0) db.cases[idx] = item;
    } else {
        db.cases.unshift(item);
    }
    
    refreshAll();
    await saveData('cases', item);
    
    Swal.fire({ icon: 'success', title: `ذخیره شد | شماره دفتر: ${officeNo}`, timer: 2000, showConfirmButton: false });
    setView('cases');
}

// ═══════════════════════════════════════════════════════════════════
// Delete Case - حذف پرونده
// ═══════════════════════════════════════════════════════════════════

async function deleteCase(id) {
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف پرونده',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله، حذف شود',
        cancelButtonText: 'انصراف',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.cases = db.cases.filter(c => c.id != id);
        refreshAll();
        await saveData();
        setView('cases');
    }
}

// ═══════════════════════════════════════════════════════════════════
// Show Case Detail - نمایش جزئیات پرونده
// ═══════════════════════════════════════════════════════════════════

function showCaseDetail(id) {
    const c = db.cases.find(x => x.id == id);
    if (!c) return;
    
    const tags = c.tags ? c.tags.split(',').filter(Boolean).map(t => 
        `<span class="tag">${escapeHtml(t.trim())}</span>`
    ).join('') : '<span class="text-gray-400">-</span>';
    
    // Calculate finances
    const finances = db.finance.filter(f => f.caseId == id);
    const income = finances.filter(f => f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
    const expense = finances.filter(f => f.type === 'expense').reduce((a, b) => a + Number(b.amount), 0);
    const totalPrice = parseFormattedNumber(c.totalPrice || 0);
    const debt = totalPrice - income;
    
    // Multi-case check
    const personCases = db.cases.filter(cs => cs.name === c.name);
    let multiCaseInfo = '';
    if (personCases.length > 1) {
        const totalDebtAllCases = personCases.reduce((sum, cs) => {
            const caseIncome = db.finance.filter(f => f.caseId == cs.id && f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
            const casePrice = parseFormattedNumber(cs.totalPrice || 0);
            return sum + (casePrice - caseIncome);
        }, 0);
        
        multiCaseInfo = `
            <div class="col-span-full bg-amber-50 dark:bg-amber-900/10 p-4 rounded-xl border border-amber-200 dark:border-amber-900/30">
                <p class="text-sm text-amber-800 dark:text-amber-300 mb-2">
                    <i class="fas fa-info-circle ml-1"></i>
                    این شخص ${personCases.length} پرونده دارد
                </p>
                <div class="flex justify-between items-center">
                    <span class="text-sm text-amber-700 dark:text-amber-400">بدهی کل از همه پرونده‌ها:</span>
                    <span class="text-lg font-bold text-amber-600 dark:text-amber-400 font-mono" dir="ltr">${formatNumber(totalDebtAllCases)} تومان</span>
                </div>
            </div>
        `;
    }
    
    const caseDetailContent = document.getElementById('caseDetailContent');
    if (caseDetailContent) {
        caseDetailContent.innerHTML = buildCaseDetailHTML(c, tags, totalPrice, income, expense, debt, multiCaseInfo);
    }
    
    setView('casedetail');
}

// ═══════════════════════════════════════════════════════════════════
// Build Case Detail HTML - ساخت HTML جزئیات پرونده
// ═══════════════════════════════════════════════════════════════════

function buildCaseDetailHTML(c, tags, totalPrice, income, expense, debt, multiCaseInfo) {
    return `
        <div class="bg-gradient-to-r from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white p-6 rounded-t-2xl">
            <div class="flex items-center justify-between">
                <div>
                    <h2 class="text-2xl font-bold mb-1">${escapeHtml(c.name)}</h2>
                    <div class="flex items-center gap-3 text-sm">
                        <span class="bg-white/20 px-3 py-1 rounded-full">پرونده شماره ${c.officeNo || '-'}</span>
                        <span class="bg-white/20 px-3 py-1 rounded-full">${c.status}</span>
                        <span class="bg-white/20 px-3 py-1 rounded-full">${c.type}</span>
                    </div>
                </div>
                <div class="text-right">
                    <p class="text-sm opacity-90">عنوان پرونده</p>
                    <p class="text-xl font-bold">${escapeHtml(c.title)}</p>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
            <div class="flex flex-wrap gap-2">
                <button onclick="openCaseModal(${c.id})" class="px-4 py-2 bg-primary-100 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 rounded-lg hover:bg-primary-200 transition flex items-center gap-2">
                    <i class="fas fa-edit"></i> ویرایش
                </button>
                <button onclick="openFinanceModal()" class="px-4 py-2 bg-emerald-100 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-lg hover:bg-emerald-200 transition flex items-center gap-2">
                    <i class="fas fa-money-bill-wave"></i> ثبت پرداخت
                </button>
                <button onclick="openScheduleModal()" class="px-4 py-2 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-200 transition flex items-center gap-2">
                    <i class="fas fa-calendar-plus"></i> افزودن برنامه
                </button>
                <a href="tel:${c.mobile}" class="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-200 transition flex items-center gap-2">
                    <i class="fas fa-phone"></i> تماس
                </a>
            </div>
        </div>
        
        <!-- Financial Summary -->
        <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
            <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                <i class="fas fa-chart-pie ml-2 text-primary-500"></i> خلاصه وضعیت مالی
            </h3>
            <div class="grid grid-cols-4 gap-4">
                <div class="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl text-center">
                    <p class="text-xs text-blue-600 dark:text-blue-400 mb-1">حق‌الوکاله</p>
                    <p class="text-xl font-bold text-blue-600 dark:text-blue-400 font-mono" dir="ltr">${formatNumber(totalPrice)}</p>
                </div>
                <div class="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-xl text-center">
                    <p class="text-xs text-emerald-600 dark:text-emerald-400 mb-1">دریافتی</p>
                    <p class="text-xl font-bold text-emerald-600 dark:text-emerald-400 font-mono" dir="ltr">${formatNumber(income)}</p>
                </div>
                <div class="bg-red-50 dark:bg-red-900/20 p-4 rounded-xl text-center">
                    <p class="text-xs text-red-600 dark:text-red-400 mb-1">هزینه</p>
                    <p class="text-xl font-bold text-red-600 dark:text-red-400 font-mono" dir="ltr">${formatNumber(expense)}</p>
                </div>
                <div class="${debt > 0 ? 'bg-orange-50 dark:bg-orange-900/20' : 'bg-gray-50 dark:bg-gray-700'} p-4 rounded-xl text-center">
                    <p class="text-xs ${debt > 0 ? 'text-orange-600 dark:text-orange-400' : 'text-gray-600 dark:text-gray-400'} mb-1">مانده</p>
                    <p class="text-xl font-bold ${debt > 0 ? 'text-orange-600 dark:text-orange-400' : 'text-gray-600 dark:text-gray-400'} font-mono" dir="ltr">${formatNumber(debt)}</p>
                </div>
            </div>
            ${multiCaseInfo}
        </div>
        
        <!-- Client Info -->
        <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
            <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                <i class="fas fa-user ml-2 text-primary-500"></i> اطلاعات موکل
            </h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div><p class="text-xs text-gray-400 mb-1">کد ملی</p><p class="font-mono">${escapeHtml(c.national) || '-'}</p></div>
                <div><p class="text-xs text-gray-400 mb-1">تاریخ تولد</p><p class="font-mono">${escapeHtml(c.birthDate) || '-'}</p></div>
                <div><p class="text-xs text-gray-400 mb-1">شماره تماس</p><p class="font-mono">${escapeHtml(c.mobile)}</p></div>
                <div><p class="text-xs text-gray-400 mb-1">آدرس</p><p class="text-sm">${escapeHtml(c.address) || '-'}</p></div>
            </div>
        </div>
        
        <!-- Case Info -->
        <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
            <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                <i class="fas fa-folder-open ml-2 text-primary-500"></i> اطلاعات پرونده
            </h3>
            <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div><p class="text-xs text-gray-400 mb-1">شعبه</p><p>${escapeHtml(c.branch) || '-'}</p></div>
                <div><p class="text-xs text-gray-400 mb-1">شماره بایگانی</p><p class="font-mono bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 px-2 py-1 rounded inline-block">${escapeHtml(c.archiveNo) || '-'}</p></div>
                <div><p class="text-xs text-gray-400 mb-1">طرف دعوی</p><p>${escapeHtml(c.opponent) || '-'}</p></div>
                <div><p class="text-xs text-gray-400 mb-1">شماره قرارداد</p><p class="font-mono">${escapeHtml(c.contract) || '-'}</p></div>
            </div>
        </div>
        
        ${(c.hasProsecutor || c.hasExecution) ? `
        <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
            <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                <i class="fas fa-gavel ml-2 text-primary-500"></i> اطلاعات حقوقی
            </h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                ${c.hasProsecutor ? `
                <div class="bg-orange-50 dark:bg-orange-900/10 p-4 rounded-xl border border-orange-200 dark:border-orange-900/30">
                    <p class="text-sm font-bold text-orange-700 dark:text-orange-400 mb-3"><i class="fas fa-balance-scale ml-1"></i> دادسرا</p>
                    <div class="grid grid-cols-2 gap-3">
                        <div><p class="text-xs text-gray-500">شعبه:</p><p>${escapeHtml(c.prosecutorBranch) || '-'}</p></div>
                        <div><p class="text-xs text-gray-500">بایگانی:</p><p class="font-mono">${escapeHtml(c.prosecutorArchive) || '-'}</p></div>
                    </div>
                </div>
                ` : ''}
                ${c.hasExecution ? `
                <div class="bg-purple-50 dark:bg-purple-900/10 p-4 rounded-xl border border-purple-200 dark:border-purple-900/30">
                    <p class="text-sm font-bold text-purple-700 dark:text-purple-400 mb-3"><i class="fas fa-gavel ml-1"></i> اجرای احکام</p>
                    <div class="grid grid-cols-2 gap-3">
                        <div><p class="text-xs text-gray-500">شعبه:</p><p>${escapeHtml(c.executionBranch) || '-'}</p></div>
                        <div><p class="text-xs text-gray-500">بایگانی:</p><p class="font-mono">${escapeHtml(c.executionArchive) || '-'}</p></div>
                    </div>
                </div>
                ` : ''}
            </div>
        </div>
        ` : ''}
        
        <!-- Tags & Notes -->
        <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div><h3 class="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">تگ‌ها</h3><div class="flex flex-wrap gap-2">${tags}</div></div>
                <div><h3 class="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">یادداشت</h3><div class="bg-amber-50 dark:bg-amber-900/20 p-3 rounded-lg max-h-24 overflow-y-auto"><p class="text-sm whitespace-pre-wrap">${escapeHtml(c.notes) || 'یادداشتی ثبت نشده'}</p></div></div>
            </div>
        </div>
        
        <!-- Actions -->
        <div class="bg-gray-50 dark:bg-dark-800 p-4 rounded-b-2xl flex justify-between">
            <button onclick="setView('cases')" class="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-300 transition">
                <i class="fas fa-arrow-right ml-2"></i> بازگشت
            </button>
            <div class="flex gap-2">
                <button onclick="window.print()" class="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-300 transition">
                    <i class="fas fa-print ml-2"></i> چاپ
                </button>
                <button onclick="deleteCase(${c.id})" class="px-4 py-2 bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-200 transition">
                    <i class="fas fa-trash ml-2"></i> حذف
                </button>
            </div>
        </div>
    `;
}

// ═══════════════════════════════════════════════════════════════════
// Toggle Prosecutor & Execution - نمایش فیلدهای دادسرا و اجرا
// ═══════════════════════════════════════════════════════════════════

function toggleProsecutor() {
    const checked = document.getElementById('caseHasProsecutor')?.checked;
    const fields = document.getElementById('prosecutorFields');
    if (fields) fields.classList.toggle('hidden', !checked);
}

function toggleExecution() {
    const checked = document.getElementById('caseHasExecution')?.checked;
    const fields = document.getElementById('executionFields');
    if (fields) fields.classList.toggle('hidden', !checked);
}