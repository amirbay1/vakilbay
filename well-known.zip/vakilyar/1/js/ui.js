'use strict';

console.log('Ui.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Navigation - ناوبری بین صفحات
// ═══════════════════════════════════════════════════════════════════

function setView(view) {
    // Hide all pages
    document.querySelectorAll('.page-view').forEach(v => {
        if (v) v.classList.add('hidden');
    });
    
    // Show target page
    const viewElement = document.getElementById('view-' + view);
    if (viewElement) {
        viewElement.classList.remove('hidden');
    } else {
        console.error('View element not found: view-' + view);
        return;
    }
    
    // Update bottom navigation
    document.querySelectorAll('.bottom-nav-item').forEach(item => {
        if (item) item.classList.remove('active');
    });
    
    const bottomNavItem = document.querySelector(`.bottom-nav-item[data-view="${view}"]`);
    if (bottomNavItem) {
        bottomNavItem.classList.add('active');
    }
    
    // Update desktop navigation
    document.querySelectorAll('.desktop-nav-item').forEach(item => {
        if (item) item.classList.remove('active');
    });
    
    const desktopNavItem = document.querySelector(`.desktop-nav-item[data-view="${view}"]`);
    if (desktopNavItem) {
        desktopNavItem.classList.add('active');
    }
    
    // Close user menu
    const userMenu = document.getElementById('userMenu');
    if (userMenu && !userMenu.classList.contains('hidden')) {
        userMenu.classList.add('hidden');
    }
    
    // Load data for specific views
    try {
        switch(view) {
            case 'dashboard': renderDashboard(); break;
            case 'cases': renderCases(); break;
            case 'schedule': renderSchedule(); break;
            case 'finance': renderFinance(); break;
            case 'library': renderLibrary(); break;
            case 'debtors': calculateDebtors(); renderDebtors(); break;
        }
    } catch (error) {
        console.error('Error rendering view:', error);
    }
}

function getCurrentView() {
    const views = document.querySelectorAll('.page-view');
    for (const view of views) {
        if (!view.classList.contains('hidden')) {
            return view.id.replace('view-', '');
        }
    }
    return 'dashboard';
}

// ═══════════════════════════════════════════════════════════════════
// Theme Toggle - تغییر تم
// ═══════════════════════════════════════════════════════════════════

function toggleTheme() {
    document.documentElement.classList.toggle('dark');
    const isDark = document.documentElement.classList.contains('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    
    if (charts.cases || charts.finance) {
        updateChartsTheme();
    }
}

// ═══════════════════════════════════════════════════════════════════
// User Menu Toggle - منوی کاربر
// ═══════════════════════════════════════════════════════════════════

function toggleUserMenu() {
    const menu = document.getElementById('userMenu');
    if (menu) {
        menu.classList.toggle('hidden');
    }
}

// ═══════════════════════════════════════════════════════════════════
// Input Formatting Setup - فرمت ورودی‌ها
// ═══════════════════════════════════════════════════════════════════

function setupInputFormatting() {
    document.addEventListener('input', function(e) {
        const target = e.target;
        
        // Date fields - convert to English numbers
        const dateFields = ['scheduleDate', 'financeDate', 'caseBirth', 'caseNational', 
                          'caseMobile', 'caseContract', 'filterDateFrom', 'filterDateTo'];
        
        if (dateFields.includes(target.id)) {
            const start = target.selectionStart;
            const end = target.selectionEnd;
            target.value = convertToEnglishNumbers(target.value);
            target.setSelectionRange(start, end);
        }
        
        // Amount fields - format with thousand separator
        if (target.id === 'financeAmount' || target.id === 'casePrice') {
            const start = target.selectionStart;
            let val = target.value.replace(/,/g, '');
            val = convertToEnglishNumbers(val).replace(/[^\d]/g, '');
            
            if (val) {
                val = formatNumber(val);
            }
            target.value = val;
            
            const diff = val.length - target.value.length;
            target.setSelectionRange(start + diff, start + diff);
        }
    });
}

// ═══════════════════════════════════════════════════════════════════
// Keyboard Shortcuts - کلیدهای میانبر
// ═══════════════════════════════════════════════════════════════════

function setupKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        // Escape - بازگشت
        if (e.key === 'Escape') {
            const currentView = getCurrentView();
            const backMap = {
                'caseform': 'cases',
                'casedetail': 'cases',
                'scheduleform': 'schedule',
                'financeform': 'finance',
                'debtors': 'finance',
                'libraryform': 'library',
                'settings': 'dashboard',
                'quickadd': 'dashboard'
            };
            
            if (backMap[currentView]) {
                setView(backMap[currentView]);
            }
        }
        
        // Ctrl+K - افزودن سریع
        if (e.ctrlKey && e.key === 'k') {
            e.preventDefault();
            setView('quickadd');
        }
    });
}

// ═══════════════════════════════════════════════════════════════════
// Setup Click Outside Handlers - بستن منوها با کلیک بیرون
// ═══════════════════════════════════════════════════════════════════

function setupClickOutsideHandlers() {
    document.addEventListener('click', (e) => {
        // Close client suggestions
        if (!e.target.closest('#clientSuggestions') && !e.target.closest('#scheduleClient')) {
            const clientSuggestions = document.getElementById('clientSuggestions');
            if (clientSuggestions) clientSuggestions.classList.add('hidden');
        }
        
        // Close case suggestions
        if (!e.target.closest('#scheduleCaseSuggestions') && !e.target.closest('#scheduleCaseSearch')) {
            const el = document.getElementById('scheduleCaseSuggestions');
            if (el) el.classList.add('hidden');
        }
        
        if (!e.target.closest('#financeCaseSuggestions') && !e.target.closest('#financeCaseSearch')) {
            const el = document.getElementById('financeCaseSuggestions');
            if (el) el.classList.add('hidden');
        }
        
        // Close user menu
        if (!e.target.closest('#userMenu') && !e.target.closest('button[onclick*="toggleUserMenu"]')) {
            const userMenu = document.getElementById('userMenu');
            if (userMenu && !userMenu.classList.contains('hidden')) {
                userMenu.classList.add('hidden');
            }
        }
    });
}