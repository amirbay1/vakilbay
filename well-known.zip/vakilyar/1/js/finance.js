'use strict';

console.log('Finance.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Debounced Functions
// ═══════════════════════════════════════════════════════════════════

const debouncedRenderFinance = debounce(renderFinance, 300, 'finance');
const debouncedRenderDebtors = debounce(renderDebtors, 300, 'debtors');
const debouncedSearchFinanceCases = debounce((input) => searchCasesForSelect(input, 'financeCaseSuggestions', 'financeCaseId'), 200, 'financeCases');

// ═══════════════════════════════════════════════════════════════════
// Render Finance - رندر لیست مالی
// ═══════════════════════════════════════════════════════════════════

function renderFinance() {
    const search = document.getElementById('searchFinance')?.value.toLowerCase() || '';
    const typeFilter = document.getElementById('filterFinanceType')?.value || '';
    const dateFrom = convertToEnglishNumbers(document.getElementById('filterDateFrom')?.value || '');
    const dateTo = convertToEnglishNumbers(document.getElementById('filterDateTo')?.value || '');
    
    const filtered = db.finance.filter(f => {
        if (search && !JSON.stringify(f).toLowerCase().includes(search)) return false;
        if (typeFilter && f.type !== typeFilter) return false;
        if (dateFrom && comparePersianDates(f.date, dateFrom) < 0) return false;
        if (dateTo && comparePersianDates(f.date, dateTo) > 0) return false;
        return true;
    });
    
    const income = filtered.filter(f => f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
    const expense = filtered.filter(f => f.type === 'expense').reduce((a, b) => a + Number(b.amount), 0);
    
    const updates = {
        'totalIncome': formatNumber(income),
        'totalExpense': formatNumber(expense),
        'totalBalance': formatNumber(income - expense)
    };
    
    Object.entries(updates).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    });
    
    const { currentPage, itemsPerPage } = pagination.finance;
    const startIdx = (currentPage - 1) * itemsPerPage;
    const paginatedItems = filtered.slice(startIdx, startIdx + itemsPerPage);
    
    const tbody = document.getElementById('financeTableBody');
    if (tbody) {
        tbody.innerHTML = paginatedItems.map(f => {
            const cs = db.cases.find(c => c.id == f.caseId);
            const idx = db.finance.findIndex(x => x.id === f.id);
            
            return `
                <tr class="table-row">
                    <td class="p-4 font-mono text-sm text-gray-500">${f.date || ''}</td>
                    <td class="p-4">${cs ? `<span class="font-medium">${escapeHtml(cs.name)}</span>` : '<span class="text-gray-400">بدون پرونده</span>'}</td>
                    <td class="p-4"><span class="${f.type === 'income' ? 'badge-success' : 'badge-danger'} px-2 py-1 rounded text-xs">${f.type === 'income' ? 'دریافت' : 'هزینه'}</span></td>
                    <td class="p-4 font-mono font-bold ${f.type === 'income' ? 'text-emerald-600' : 'text-red-600'}" dir="ltr">${formatNumber(f.amount)}</td>
                    <td class="p-4 text-sm text-gray-500 max-w-[200px] truncate">${escapeHtml(f.desc) || '-'}</td>
                    <td class="p-4 text-center">
                        <button onclick="editFinance(${idx})" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-700 rounded-lg transition"><i class="fas fa-edit text-gray-400"></i></button>
                        <button onclick="deleteFinance(${idx})" class="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition"><i class="fas fa-trash text-red-400"></i></button>
                    </td>
                </tr>
            `;
        }).join('') || '<tr><td colspan="6" class="p-8 text-center text-gray-400">تراکنشی یافت نشد</td></tr>';
    }
    
    renderPagination('financePagination', filtered.length, currentPage, itemsPerPage, 'goToFinancePage');
}

function goToFinancePage(page) {
    pagination.finance.currentPage = page;
    renderFinance();
}

function clearDateFilters() {
    const from = document.getElementById('filterDateFrom');
    const to = document.getElementById('filterDateTo');
    if (from) from.value = '';
    if (to) to.value = '';
    renderFinance();
}

// ═══════════════════════════════════════════════════════════════════
// Open Finance Modal - باز کردن فرم مالی
// ═══════════════════════════════════════════════════════════════════

function openFinanceModal(idx = null) {
    const form = document.getElementById('financeForm');
    if (form) form.reset();
    
    document.getElementById('financeId').value = '';
    document.getElementById('financeDate').value = new Date().toLocaleDateString('fa-IR');
    
    const title = document.getElementById('financeFormTitle');
    if (title) title.innerHTML = '<i class="fas fa-money-bill-wave ml-2"></i> تراکنش جدید';
    
    updateCaseSelects();
    
    if (idx !== null && db.finance[idx]) {
        const f = db.finance[idx];
        if (title) title.innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش تراکنش';
        document.getElementById('financeId').value = idx;
        document.getElementById('financeCaseId').value = f.caseId || '';
        document.getElementById('financeType').value = f.type || 'income';
        document.getElementById('financeDate').value = f.date || '';
        document.getElementById('financeAmount').value = formatNumber(f.amount || '');
        document.getElementById('financeDesc').value = f.desc || '';
    }
    
    setView('financeform');
}

function editFinance(idx) {
    openFinanceModal(idx);
}

// ═══════════════════════════════════════════════════════════════════
// Save Finance - ذخیره تراکنش
// ═══════════════════════════════════════════════════════════════════

async function saveFinance(e) {
    e.preventDefault();
    
    const idx = document.getElementById('financeId').value;
    const rawAmount = convertToEnglishNumbers(document.getElementById('financeAmount').value);
    const cleanAmount = parseFormattedNumber(rawAmount);
    
    const item = {
        id: idx !== '' ? db.finance[idx].id : Date.now(),
        caseId: document.getElementById('financeCaseId').value,
        type: document.getElementById('financeType').value,
        date: convertToEnglishNumbers(document.getElementById('financeDate').value),
        amount: cleanAmount,
        desc: document.getElementById('financeDesc').value
    };
    
    if (item.caseId) {
        const cs = db.cases.find(c => c.id == item.caseId);
        if (cs) item.caseName = cs.name;
    }
    
    if (idx !== '') {
        db.finance[idx] = item;
    } else {
        db.finance.unshift(item);
    }
    
    refreshAll();
    await saveData('finance', item);
    
    Swal.fire({ icon: 'success', title: 'ذخیره شد', timer: 1500, showConfirmButton: false });
    setView('finance');
}

// ═══════════════════════════════════════════════════════════════════
// Delete Finance - حذف تراکنش
// ═══════════════════════════════════════════════════════════════════

async function deleteFinance(idx) {
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف تراکنش',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.finance.splice(idx, 1);
        refreshAll();
        await saveData();
        setView('finance');
    }
}

// ═══════════════════════════════════════════════════════════════════
// DEBTORS - بدهکاران
// ═══════════════════════════════════════════════════════════════════

function calculateDebtors() {
    allDebtors = [];
    let totalAllDebt = 0;
    
    db.cases.forEach(c => {
        const contractAmount = parseInt(c.totalPrice) || 0;
        if (contractAmount === 0) return;
        
        const paidAmount = db.finance
            .filter(f => f.caseId == c.id && f.type === 'income')
            .reduce((sum, f) => sum + (parseInt(f.amount) || 0), 0);
            
        const debt = contractAmount - paidAmount;
        
        if (debt > 0) {
            allDebtors.push({
                id: c.id, 
                name: c.name, 
                title: c.title,
                contract: contractAmount, 
                paid: paidAmount, 
                debt: debt,
                mobile: c.mobile, 
                archiveNo: c.archiveNo, 
                status: c.status
            });
            totalAllDebt += debt;
        }
    });
    
    allDebtors.sort((a, b) => b.debt - a.debt);
    
    const totalEl = document.getElementById('totalDebtAmount');
    if (totalEl) totalEl.innerText = formatNumber(totalAllDebt) + ' تومان';
}

function renderDebtors() {
    const search = document.getElementById('searchDebtors')?.value.toLowerCase() || '';
    
    let filtered = allDebtors.filter(d => {
        if (search && !JSON.stringify(d).toLowerCase().includes(search)) return false;
        return true;
    });
    
    const { currentPage, itemsPerPage } = pagination.debtors;
    const startIdx = (currentPage - 1) * itemsPerPage;
    const paginatedItems = filtered.slice(startIdx, startIdx + itemsPerPage);
    
    const container = document.getElementById('debtorsListContent');
    if (container) {
        if (paginatedItems.length === 0) {
            container.innerHTML = `<div class="text-center py-8 text-gray-400"><i class="fas fa-check-circle text-4xl mb-3 text-emerald-500"></i><p>بدهکاری یافت نشد!</p></div>`;
        } else {
            container.innerHTML = paginatedItems.map(d => renderDebtorCard(d)).join('');
        }
    }
    
    renderPagination('debtorsPagination', filtered.length, currentPage, itemsPerPage, 'goToDebtorsPage');
}

function renderDebtorCard(d) {
    const percent = Math.min(100, Math.round((d.paid / d.contract) * 100));
    const urgency = d.debt > 5000000 ? 'high' : d.debt > 2000000 ? 'medium' : 'low';
    const urgencyColors = { high: 'border-red-500', medium: 'border-orange-500', low: 'border-amber-500' };
    
    return `
    <div class="card p-5 border-r-4 ${urgencyColors[urgency]} hover:shadow-lg transition">
        <div class="flex justify-between items-start mb-3">
            <div>
                <h4 class="font-bold text-lg">${escapeHtml(d.name)}</h4>
                <p class="text-sm text-gray-600">${escapeHtml(d.title)}</p>
            </div>
            <div class="text-left">
                <p class="text-xs text-gray-400">مانده بدهی</p>
                <p class="font-bold text-xl ${urgency === 'high' ? 'text-red-600' : urgency === 'medium' ? 'text-orange-600' : 'text-amber-600'} font-mono">${formatNumber(d.debt)}</p>
            </div>
        </div>
        <div class="grid grid-cols-2 gap-4 mb-3">
            <div><p class="text-xs text-gray-400">قرارداد</p><p class="font-mono">${formatNumber(d.contract)}</p></div>
            <div><p class="text-xs text-gray-400">پرداخت شده</p><p class="font-mono">${formatNumber(d.paid)}</p></div>
        </div>
        <div class="w-full bg-gray-200 rounded-full h-2.5 mb-3">
            <div class="bg-emerald-500 h-2.5 rounded-full transition-all" style="width: ${percent}%"></div>
        </div>
        <div class="flex justify-between items-center">
            <span class="text-xs text-gray-500">${percent}% پرداخت شده</span>
            <div class="flex gap-2">
                <button onclick="showCaseDetail(${d.id})" class="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded hover:bg-blue-100"><i class="fas fa-folder-open ml-1"></i>پرونده</button>
                <a href="tel:${d.mobile}" class="text-xs text-green-600 bg-green-50 px-2 py-1 rounded hover:bg-green-100"><i class="fas fa-phone ml-1"></i>تماس</a>
            </div>
        </div>
    </div>
    `;
}

function goToDebtorsPage(page) {
    pagination.debtors.currentPage = page;
    renderDebtors();
}
// ═══════════════════════════════════════════════════════════════════
// ★★★ اصلاح شده: Finance Case Search ★★★
// ═══════════════════════════════════════════════════════════════════

function searchFinanceCases(input) {
    const val = input.value.toLowerCase().trim();
    const box = document.getElementById('financeCaseSuggestions');
    const select = document.getElementById('financeCaseId');
    
    if (!box) return;
    
    if (val.length < 1) {
        box.classList.add('hidden');
        return;
    }
    
    const matchedCases = db.cases.filter(c => 
        c.name.toLowerCase().includes(val) || 
        c.title.toLowerCase().includes(val) ||
        (c.archiveNo && c.archiveNo.includes(val))
    );
    
    if (matchedCases.length > 0) {
        let html = '';
        matchedCases.slice(0, 8).forEach(c => {
            html += `
                <div class="p-3 hover:bg-gray-50 dark:hover:bg-dark-800 cursor-pointer text-sm flex items-center gap-2 border-b border-gray-100 dark:border-dark-700 last:border-0" 
                     onclick="selectFinanceCase('${c.id}')">
                    <i class="fas fa-folder text-primary-400"></i>
                    <div class="flex-1 min-w-0">
                        <p class="font-medium truncate">${escapeHtml(c.name)}</p>
                        <p class="text-xs text-gray-400 truncate">${escapeHtml(c.title)} ${c.archiveNo ? '(' + escapeHtml(c.archiveNo) + ')' : ''}</p>
                    </div>
                </div>
            `;
        });
        box.innerHTML = html;
        box.classList.remove('hidden');
    } else {
        box.innerHTML = '<div class="p-3 text-sm text-gray-400 text-center">پرونده‌ای یافت نشد</div>';
        box.classList.remove('hidden');
    }
}

function selectFinanceCase(caseId) {
    const select = document.getElementById('financeCaseId');
    const searchInput = document.getElementById('financeCaseSearch');
    const box = document.getElementById('financeCaseSuggestions');
    
    if (select) select.value = caseId;
    if (box) box.classList.add('hidden');
    
    // نمایش نام پرونده در input
    if (searchInput && caseId) {
        const cs = db.cases.find(c => c.id == caseId);
        if (cs) {
            searchInput.value = `${cs.name} - ${cs.title}`;
        }
    }
}

// اضافه کردن به window
window.searchFinanceCases = searchFinanceCases;
window.selectFinanceCase = selectFinanceCase;