'use strict';

console.log('Schedule.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Debounced Functions
// ═══════════════════════════════════════════════════════════════════

const debouncedRenderSchedule = debounce(renderSchedule, 300, 'schedule');
const debouncedSuggestClients = debounce((input) => suggestClients(input), 200, 'clients');
const debouncedSearchScheduleCases = debounce((input) => searchCasesForSelect(input, 'scheduleCaseSuggestions', 'scheduleCaseId'), 200, 'scheduleCases');

// ═══════════════════════════════════════════════════════════════════
// Render Schedule - رندر لیست برنامه‌ها
// ═══════════════════════════════════════════════════════════════════

function renderSchedule() {
    if (currentCalendarView === 'month') {
        renderMonthCalendar();
        return;
    }
    
    const viewToggleBtn = document.getElementById('viewToggleBtn');
    if (viewToggleBtn) {
        viewToggleBtn.innerHTML = '<i class="fas fa-calendar-alt"></i>';
        viewToggleBtn.title = 'نمایش تقویم ماهانه';
    }
    
    const search = document.getElementById('searchSchedule')?.value.toLowerCase() || '';
    const labelFilter = document.getElementById('filterScheduleLabel')?.value || '';
    const today = getTodayPersian();
    
    const filtered = db.schedule.filter(s => {
        if (search && !JSON.stringify(s).toLowerCase().includes(search)) return false;
        if (labelFilter && s.label !== labelFilter) return false;
        return true;
    }).sort((a, b) => {
        const dateCompare = comparePersianDates(a.date, b.date);
        if (dateCompare !== 0) return dateCompare;
        return (a.time || '').localeCompare(b.time || '');
    });
    
    const todayItems = filtered.filter(s => comparePersianDates(s.date, today) === 0);
    const upcomingItems = filtered.filter(s => getDaysUntil(s.date) > 0 && getDaysUntil(s.date) <= 30);
    const pastItems = filtered.filter(s => comparePersianDates(s.date, today) < 0).reverse();
    
    const totalUpcoming = filtered.filter(s => getDaysUntil(s.date) > 0).length;
    const thisWeek = filtered.filter(s => {
        const d = getDaysUntil(s.date);
        return d >= 0 && d <= 7;
    }).length;
    
    // Summary
    const scheduleSummary = document.getElementById('scheduleSummary');
    if (scheduleSummary) {
        scheduleSummary.innerHTML = `
            <div class="flex flex-wrap items-center gap-4 mb-4 text-xs">
                <span class="px-3 py-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg flex items-center gap-2">
                    <i class="fas fa-calendar-week"></i> این هفته: <b>${thisWeek}</b>
                </span>
                <span class="px-3 py-2 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-lg flex items-center gap-2">
                    <i class="fas fa-chart-line"></i> کل آینده: <b>${totalUpcoming}</b>
                </span>
            </div>
        `;
    }
    
    // Today list
    const todayScheduleList = document.getElementById('todayScheduleList');
    if (todayScheduleList) {
        todayScheduleList.innerHTML = renderScheduleItems(todayItems, 'today');
    }
    
    // Upcoming with pagination
    const { currentPage, itemsPerPage } = pagination.schedule;
    const startIdx = (currentPage - 1) * itemsPerPage;
    const paginatedUpcoming = upcomingItems.slice(startIdx, startIdx + itemsPerPage);
    
    const upcomingScheduleList = document.getElementById('upcomingScheduleList');
    if (upcomingScheduleList) {
        upcomingScheduleList.innerHTML = renderScheduleItems(paginatedUpcoming, 'upcoming');
        renderPagination('schedulePagination', upcomingItems.length, currentPage, itemsPerPage, 'goToSchedulePage');
    }
    
    // Past list
    const pastScheduleList = document.getElementById('pastScheduleList');
    if (pastScheduleList) {
        pastScheduleList.innerHTML = renderScheduleItems(pastItems.slice(0, 10), 'past');
    }
}

function goToSchedulePage(page) {
    pagination.schedule.currentPage = page;
    renderSchedule();
    document.getElementById('upcomingScheduleList')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

// ═══════════════════════════════════════════════════════════════════
// Render Schedule Items - رندر آیتم‌های برنامه
// ═══════════════════════════════════════════════════════════════════

function renderScheduleItems(items, type) {
    if (!items.length) {
        const emptyTexts = { 
            'today': 'برنامه‌ای برای امروز نیست', 
            'upcoming': 'برنامه‌ای در آینده نیست', 
            'past': 'برنامه‌ای در گذشته نیست' 
        };
        return `<div class="text-center py-8 text-gray-400"><i class="fas fa-calendar-times text-4xl mb-3"></i><p>${emptyTexts[type]}</p></div>`;
    }
    
    const labelColors = {
        'جلسه': 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
        'دادگاه': 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
        'تنظیم': 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
        'پیگیری': 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400'
    };
    
    const labelIcons = { 'جلسه': 'fa-users', 'دادگاه': 'fa-gavel', 'تنظیم': 'fa-file-contract', 'پیگیری': 'fa-phone-alt' };
    
    return items.map(s => {
        const cs = s.caseId ? db.cases.find(c => c.id == s.caseId) : null;
        const idx = db.schedule.findIndex(x => x.id === s.id);
        const daysLeft = getDaysUntil(s.date);
        const dayName = getPersianDayName(s.date);
        const icon = labelIcons[s.label] || 'fa-calendar-check';
        
        let daysLeftText = '', daysLeftClass = '';
        if (daysLeft === 0) { daysLeftText = 'امروز'; daysLeftClass = 'text-red-600 font-bold'; }
        else if (daysLeft === 1) { daysLeftText = 'فردا'; daysLeftClass = 'text-orange-600 font-bold'; }
        else if (daysLeft > 0) { daysLeftText = `${daysLeft} روز مانده`; daysLeftClass = 'text-emerald-600'; }
        else { daysLeftText = `${Math.abs(daysLeft)} روز قبل`; daysLeftClass = 'text-gray-400'; }
        
        let priorityClass = s.label === 'دادگاه' ? 'border-r-4 border-red-500' : 
                           s.label === 'جلسه' ? 'border-r-4 border-blue-500' : 'border-r-4 border-gray-300';
        
        return `
            <div class="card p-4 ${s.is_done ? 'opacity-50' : ''} ${priorityClass} transition-all group hover:shadow-lg">
                <div class="flex items-start gap-3">
                    <label class="cursor-pointer mt-1">
                        <input type="checkbox" class="hidden" onchange="toggleScheduleDone(${idx})" ${s.is_done ? 'checked' : ''}>
                        <div class="w-5 h-5 rounded-full border-2 ${s.is_done ? 'bg-emerald-500 border-emerald-500' : 'border-gray-300'} flex items-center justify-center transition">
                            ${s.is_done ? '<i class="fas fa-check text-white text-[10px]"></i>' : ''}
                        </div>
                    </label>
                    
                    <div class="flex-1 min-w-0 cursor-pointer" onclick="openScheduleModal(${idx})">
                        <div class="flex items-center gap-2 mb-2">
                            <i class="fas ${icon} text-gray-500"></i>
                            <h4 class="font-bold text-gray-800 dark:text-white text-sm ${s.is_done ? 'line-through' : ''}">${escapeHtml(s.client) || 'بدون نام'}</h4>
                            ${s.label ? `<span class="${labelColors[s.label] || 'bg-gray-100'} text-[10px] px-1.5 py-0.5 rounded-full">${s.label}</span>` : ''}
                        </div>
                        <p class="text-xs text-gray-500 mb-2 truncate">${escapeHtml(s.desc) || '-'}</p>
                        ${cs ? `<p class="text-[10px] text-primary-600 dark:text-gold-500 mb-2"><i class="fas fa-folder-open ml-1"></i>${escapeHtml(cs.name)}</p>` : ''}
                        ${s.result ? `<p class="text-[10px] text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 p-2 rounded"><i class="fas fa-check-double ml-1"></i>${escapeHtml(s.result)}</p>` : ''}
                    </div>
                    
                    <div class="text-left shrink-0">
                        <p class="text-xs font-bold text-gray-800 dark:text-white mb-1">${s.date}</p>
                        <p class="text-[10px] text-gray-400 mb-1">${dayName} - ${s.time || ''}</p>
                        <p class="text-[10px] ${daysLeftClass}">${daysLeftText}</p>
                    </div>
                    
                    <button onclick="event.stopPropagation(); deleteSchedule(${idx})" class="p-1.5 opacity-0 group-hover:opacity-100 hover:bg-red-50 rounded-lg transition" title="حذف">
                        <i class="fas fa-trash text-red-400 text-xs"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

// ═══════════════════════════════════════════════════════════════════
// Toggle Past Schedule - نمایش/مخفی برنامه‌های گذشته
// ═══════════════════════════════════════════════════════════════════

function togglePastSchedule() {
    const list = document.getElementById('pastScheduleList');
    const icon = document.getElementById('pastScheduleIcon');
    if (list && icon) {
        list.classList.toggle('hidden');
        icon.classList.toggle('fa-chevron-down');
        icon.classList.toggle('fa-chevron-up');
    }
}

// ═══════════════════════════════════════════════════════════════════
// Calendar View Toggle - تغییر نمای تقویم
// ═══════════════════════════════════════════════════════════════════

function toggleCalendarView() {
    currentCalendarView = currentCalendarView === 'list' ? 'month' : 'list';
    VakilYar.state.currentCalendarView = currentCalendarView;
    
    const listViewContainer = document.getElementById('listViewContainer');
    const monthViewContainer = document.getElementById('monthCalendarContainer');
    
    if (currentCalendarView === 'list') {
        if (listViewContainer) listViewContainer.classList.remove('hidden');
        if (monthViewContainer) monthViewContainer.classList.add('hidden');
        renderSchedule();
    } else {
        if (!VakilYar.state.currentDisplayMonth) {
            VakilYar.state.currentDisplayMonth = getTodayPersian();
        }
        if (monthViewContainer) monthViewContainer.classList.remove('hidden');
        if (listViewContainer) listViewContainer.classList.add('hidden');
        renderMonthCalendar();
    }
}

// ═══════════════════════════════════════════════════════════════════
// Month Calendar - تقویم ماهانه
// ═══════════════════════════════════════════════════════════════════

function renderMonthCalendar() {
    const viewToggleBtn = document.getElementById('viewToggleBtn');
    if (viewToggleBtn) {
        viewToggleBtn.innerHTML = '<i class="fas fa-list"></i>';
        viewToggleBtn.title = 'نمایش لیست';
    }
    
    const container = document.getElementById('monthCalendarContainer');
    if (!container) return;
    
    const displayMonth = VakilYar.state.currentDisplayMonth || getTodayPersian();
    const [currentYear, currentMonth] = displayMonth.split('/').map(Number);
    
    const monthDays = getDaysInPersianMonth(currentYear, currentMonth);
    const firstDayOfWeek = getFirstDayOfWeek(currentYear, currentMonth);
    
    let html = `
        <div class="calendar-header flex justify-between items-center p-4 bg-gradient-to-r from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white rounded-t-xl">
            <button onclick="changeMonth(-1)" class="p-2 hover:bg-white/20 rounded-full transition"><i class="fas fa-chevron-right"></i></button>
            <div class="text-center">
                <h3 class="text-xl font-bold">${getPersianMonthName(currentMonth)} ${currentYear}</h3>
                <p class="text-xs opacity-80 mt-1">${monthDays} روز</p>
            </div>
            <button onclick="changeMonth(1)" class="p-2 hover:bg-white/20 rounded-full transition"><i class="fas fa-chevron-left"></i></button>
        </div>
        <div class="calendar-grid grid grid-cols-7 gap-1 p-2 bg-white dark:bg-dark-800 rounded-b-xl">
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">شنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">یکشنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">دوشنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">سه‌شنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">چهارشنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">پنجشنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">جمعه</div>
    `;
    
    // Empty days
    for (let i = 0; i < firstDayOfWeek; i++) {
        html += `<div class="p-2 h-24 bg-gray-50 dark:bg-dark-900/20 rounded"></div>`;
    }
    
    // Month days
    for (let day = 1; day <= monthDays; day++) {
        const dateStr = `${currentYear}/${currentMonth.toString().padStart(2, '0')}/${day.toString().padStart(2, '0')}`;
        const daySchedules = db.schedule.filter(s => comparePersianDates(s.date, dateStr) === 0);
        const isToday = comparePersianDates(dateStr, getTodayPersian()) === 0;
        
        html += `
            <div class="calendar-day border border-gray-200 dark:border-dark-700 p-2 h-24 overflow-hidden ${isToday ? 'bg-primary-50 dark:bg-primary-900/20 border-primary-500' : 'hover:bg-gray-50 dark:hover:bg-dark-700'} transition cursor-pointer rounded-lg relative" onclick="openDaySchedules('${dateStr}')">
                <div class="flex justify-between items-start mb-1">
                    <span class="text-sm font-bold ${isToday ? 'text-primary-600' : 'text-gray-700 dark:text-gray-300'}">${convertToPersianNumbers(day.toString())}</span>
                    ${daySchedules.length > 0 ? `<span class="event-count-badge">${daySchedules.length}</span>` : ''}
                </div>
                ${daySchedules.slice(0, 1).map(s => `<div class="text-xs truncate bg-gray-100 dark:bg-dark-700 px-1 rounded">${s.time || ''} ${escapeHtml(s.client) || ''}</div>`).join('')}
            </div>
        `;
    }
    
    html += `</div>`;
    container.innerHTML = html;
}

function changeMonth(direction) {
    let [year, month] = (VakilYar.state.currentDisplayMonth || getTodayPersian()).split('/').map(Number);
    month += direction;
    if (month > 12) { month = 1; year++; }
    else if (month < 1) { month = 12; year--; }
    VakilYar.state.currentDisplayMonth = `${year}/${month.toString().padStart(2, '0')}`;
    renderMonthCalendar();
}

function openDaySchedules(dateStr) {
    const daySchedules = db.schedule.filter(s => comparePersianDates(s.date, dateStr) === 0);
    
    if (daySchedules.length === 0) {
        Swal.fire({
            icon: 'info',
            title: 'رویدادی یافت نشد',
            html: `<p>در تاریخ ${dateStr} برنامه‌ای نیست.</p>`,
            showCancelButton: true,
            confirmButtonText: '<i class="fas fa-plus ml-2"></i>افزودن برنامه',
            cancelButtonText: 'انصراف'
        }).then((result) => {
            if (result.isConfirmed) {
                openScheduleModal();
                setTimeout(() => {
                    const dateInput = document.getElementById('scheduleDate');
                    if (dateInput) dateInput.value = dateStr;
                }, 100);
            }
        });
        return;
    }
    
    let schedulesHTML = daySchedules.map(s => {
        const idx = db.schedule.findIndex(x => x.id === s.id);
        return `
            <div class="border rounded-lg p-4 mb-3 ${s.is_done ? 'opacity-50' : ''} text-right">
                <div class="flex justify-between items-start mb-2">
                    <h4 class="font-bold ${s.is_done ? 'line-through' : ''}">${escapeHtml(s.client) || 'بدون نام'}</h4>
                    <span class="text-xs bg-gray-100 px-2 py-1 rounded">${s.label || ''}</span>
                </div>
                <p class="text-sm text-gray-600 mb-2">${s.time || ''} - ${escapeHtml(s.desc) || ''}</p>
                <div class="flex justify-end gap-2">
                    <button onclick="Swal.close(); toggleScheduleDone(${idx})" class="text-xs px-3 py-1.5 bg-emerald-100 text-emerald-600 rounded-lg">${s.is_done ? 'برگرداندن' : 'انجام شد'}</button>
                    <button onclick="Swal.close(); openScheduleModal(${idx})" class="text-xs px-3 py-1.5 bg-blue-100 text-blue-600 rounded-lg">ویرایش</button>
                    <button onclick="Swal.close(); deleteSchedule(${idx})" class="text-xs px-3 py-1.5 bg-red-100 text-red-600 rounded-lg">حذف</button>
                </div>
            </div>
        `;
    }).join('');
    
    Swal.fire({
        title: `برنامه‌های ${dateStr}`,
        html: `<div class="text-right max-h-96 overflow-y-auto">${schedulesHTML}</div>`,
        width: '600px',
        showConfirmButton: false,
        showCloseButton: true
    });
}

// ═══════════════════════════════════════════════════════════════════
// Client Suggestions - پیشنهاد موکلین
// ═══════════════════════════════════════════════════════════════════

function suggestClients(input) {
    const val = input.value.toLowerCase().trim();
    const box = document.getElementById('clientSuggestions');
    
    if (val.length < 1 || !box) {
        if (box) box.classList.add('hidden');
        return;
    }
    
    // جستجو در موکلین و پرونده‌ها
    const clients = [...new Set(db.cases.map(c => c.name))];
    const matchedClients = clients.filter(n => n.toLowerCase().includes(val));
    const matchedCases = db.cases.filter(c => 
        c.name.toLowerCase().includes(val) || 
        c.title.toLowerCase().includes(val) ||
        (c.archiveNo && c.archiveNo.includes(val))
    );
    
    let html = '';
    
    // نمایش موکلین
    if (matchedClients.length > 0) {
        html += '<div class="px-3 py-1 text-xs text-gray-400 bg-gray-50 dark:bg-dark-800">موکلین</div>';
        matchedClients.slice(0, 5).forEach(name => {
            html += `
                <div class="p-3 hover:bg-gray-50 dark:hover:bg-dark-800 cursor-pointer text-sm flex items-center gap-2 border-b border-gray-100 dark:border-dark-700" 
                     onclick="selectClientAndCase('${escapeHtml(name).replace(/'/g, "\\'")}', '')">
                    <i class="fas fa-user text-gray-400"></i>
                    <span>${escapeHtml(name)}</span>
                </div>
            `;
        });
    }
    
    // نمایش پرونده‌ها
    if (matchedCases.length > 0) {
        html += '<div class="px-3 py-1 text-xs text-gray-400 bg-gray-50 dark:bg-dark-800 mt-1">پرونده‌ها</div>';
        matchedCases.slice(0, 5).forEach(c => {
            html += `
                <div class="p-3 hover:bg-gray-50 dark:hover:bg-dark-800 cursor-pointer text-sm flex items-center gap-2" 
                     onclick="selectClientAndCase('${escapeHtml(c.name).replace(/'/g, "\\'")}', '${c.id}')">
                    <i class="fas fa-folder text-primary-400"></i>
                    <div class="flex-1 min-w-0">
                        <p class="font-medium truncate">${escapeHtml(c.name)}</p>
                        <p class="text-xs text-gray-400 truncate">${escapeHtml(c.title)} ${c.archiveNo ? '(' + escapeHtml(c.archiveNo) + ')' : ''}</p>
                    </div>
                </div>
            `;
        });
    }
    
    if (html) {
        box.innerHTML = html;
        box.classList.remove('hidden');
    } else {
        box.classList.add('hidden');
    }
}

// ★★★ تابع جدید: انتخاب موکل و پرونده همزمان ★★★
function selectClientAndCase(name, caseId) {
    const clientInput = document.getElementById('scheduleClient');
    const caseSelect = document.getElementById('scheduleCaseId');
    const box = document.getElementById('clientSuggestions');
    
    if (clientInput) clientInput.value = name;
    if (box) box.classList.add('hidden');
    
    // اگر پرونده انتخاب شده، آن را هم ست کن
    if (caseId && caseSelect) {
        // ابتدا لیست پرونده‌های این موکل را لود کن
        filterRelatedCases(name);
        // سپس پرونده انتخاب شده را ست کن
        setTimeout(() => {
            caseSelect.value = caseId;
        }, 50);
    } else {
        filterRelatedCases(name);
    }
}

function selectClient(name) {
    selectClientAndCase(name, '');
}

function filterRelatedCases(clientName) {
    const relatedCases = db.cases.filter(c => c.name === clientName);
    const select = document.getElementById('scheduleCaseId');
    if (!select) return;
    
    let optionsHTML = '<option value="">بدون پرونده</option>';
    relatedCases.forEach(c => {
        optionsHTML += `<option value="${c.id}">${escapeHtml(c.title)} ${c.archiveNo ? '(📁' + escapeHtml(c.archiveNo) + ')' : ''}</option>`;
    });
    select.innerHTML = optionsHTML;
}


function filterRelatedCases(clientName) {
    const relatedCases = db.cases.filter(c => c.name === clientName);
    const select = document.getElementById('scheduleCaseId');
    if (!select) return;
    
    let optionsHTML = '<option value="">بدون پرونده</option>';
    relatedCases.forEach(c => {
        optionsHTML += `<option value="${c.id}">${escapeHtml(c.title)} ${c.archiveNo ? '(📁' + escapeHtml(c.archiveNo) + ')' : ''}</option>`;
    });
    select.innerHTML = optionsHTML;
}



function selectCaseForSelect(id, selectId, suggestionsId) {
    const select = document.getElementById(selectId);
    const box = document.getElementById(suggestionsId);
    
    if (select) select.value = id;
    if (box) box.classList.add('hidden');
}

// ═══════════════════════════════════════════════════════════════════
// Open Schedule Modal - باز کردن فرم برنامه
// ═══════════════════════════════════════════════════════════════════

function openScheduleModal(idx = null) {
    const form = document.getElementById('scheduleForm');
    if (form) form.reset();
    
    document.getElementById('scheduleId').value = '';
    document.getElementById('scheduleDate').value = new Date().toLocaleDateString('fa-IR');
    
    const title = document.getElementById('scheduleFormTitle');
    if (title) title.innerHTML = '<i class="fas fa-calendar-plus ml-2"></i> برنامه جدید';
    
    updateCaseSelects();
    
    if (idx !== null && db.schedule[idx]) {
        const s = db.schedule[idx];
        if (title) title.innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش برنامه';
        
        document.getElementById('scheduleId').value = s.id;
        document.getElementById('scheduleDate').value = s.date || '';
        document.getElementById('scheduleTime').value = s.time || '';
        document.getElementById('scheduleClient').value = s.client || '';
        document.getElementById('scheduleCaseId').value = s.caseId || '';
        document.getElementById('scheduleLabel').value = s.label || '';
        document.getElementById('scheduleDesc').value = s.desc || '';
        document.getElementById('scheduleResult').value = s.result || '';
    }
    
    setView('scheduleform');
}

// ═══════════════════════════════════════════════════════════════════
// Save Schedule - ذخیره برنامه
// ═══════════════════════════════════════════════════════════════════

async function saveSchedule(e) {
    e.preventDefault();
    
    const scheduleIdValue = document.getElementById('scheduleId').value;
    const isEditing = scheduleIdValue !== '';
    
    let existingItem = null;
    let existingIndex = -1;
    
    if (isEditing) {
        existingIndex = db.schedule.findIndex(s => s.id == scheduleIdValue);
        if (existingIndex > -1) {
            existingItem = db.schedule[existingIndex];
        }
    }

    const item = {
        id: existingItem ? existingItem.id : Date.now(),
        date: convertToEnglishNumbers(document.getElementById('scheduleDate').value),
        time: document.getElementById('scheduleTime').value,
        client: document.getElementById('scheduleClient').value,
        caseId: document.getElementById('scheduleCaseId').value,
        label: document.getElementById('scheduleLabel').value,
        desc: document.getElementById('scheduleDesc').value,
        result: document.getElementById('scheduleResult').value,
        is_done: existingItem ? existingItem.is_done : false
    };
    
    if (item.caseId) {
        const cs = db.cases.find(c => c.id == item.caseId);
        if (cs) item.caseName = cs.name;
    }
    
    if (existingIndex > -1) {
        db.schedule[existingIndex] = item;
    } else {
        db.schedule.unshift(item);
    }
    
    refreshAll();
    await saveData('schedule', item);
    
    Swal.fire({ icon: 'success', title: 'ذخیره شد', timer: 1500, showConfirmButton: false });
    setView('schedule');
}

// ═══════════════════════════════════════════════════════════════════
// Toggle & Delete Schedule
// ═══════════════════════════════════════════════════════════════════

async function toggleScheduleDone(idx) {
    if (!db.schedule[idx]) return;
    db.schedule[idx].is_done = !db.schedule[idx].is_done;
    refreshAll();
    await saveData('schedule', db.schedule[idx]);
}

async function deleteSchedule(idx) {
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف برنامه',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.schedule.splice(idx, 1);
        refreshAll();
        await saveData();
        setView('schedule');
    }
}