'use strict';

console.log('Config.js loaded');

// ═══════════════════════════════════════════════════════════════════
// Global State - حالت گلوبال برنامه
// ═══════════════════════════════════════════════════════════════════

const VakilYar = {
    db: { 
        cases: [], 
        finance: [], 
        library: [], 
        schedule: [] 
    },
    charts: {},
    state: {
        currentLibraryId: null,
        currentCalendarView: 'list',
        currentDisplayMonth: null
    },
    pagination: {
        cases: { currentPage: 1, itemsPerPage: 12 },
        schedule: { currentPage: 1, itemsPerPage: 10 },
        finance: { currentPage: 1, itemsPerPage: 20 },
        debtors: { currentPage: 1, itemsPerPage: 10 }
    },
    debounceTimers: {}
};

// ═══════════════════════════════════════════════════════════════════
// Aliases for backward compatibility - نام‌های مستعار برای سازگاری
// ═══════════════════════════════════════════════════════════════════

let db = VakilYar.db;
let charts = VakilYar.charts;
let currentLibraryId = null;
let currentCalendarView = 'list';
let pagination = VakilYar.pagination;
let allDebtors = []; // برای ماژول بدهکاران