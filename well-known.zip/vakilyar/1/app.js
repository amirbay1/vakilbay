'use strict';

console.log('App.js v3.1 loaded successfully');

// ═════════════════════════════════════════════════
// Global State
// ═════════════════════════════════════════════════
const VakilYar = {
    db: { cases: [], finance: [], library: [], schedule: [] },
    charts: {},
    state: {
        currentLibraryId: null,
        currentCalendarView: 'list',
        currentDisplayMonth: null
    },
    pagination: {
        cases: { currentPage: 1, itemsPerPage: 12 },
        schedule: { currentPage: 1, itemsPerPage: 10 },
        finance: { currentPage: 1, itemsPerPage: 20 },
        debtors: { currentPage: 1, itemsPerPage: 10 }
    },
    debounceTimers: {}
};

// Aliases for backward compatibility
let db = VakilYar.db;
let charts = VakilYar.charts;
let currentLibraryId = null;
let currentCalendarView = 'list';
let pagination = VakilYar.pagination;

// ═════════════════════════════════════════════════
// Utility Functions
// ═════════════════════════════════════════════════

// Debounce function
function debounce(func, wait, timerId) {
    return function executedFunction(...args) {
        clearTimeout(VakilYar.debounceTimers[timerId]);
        VakilYar.debounceTimers[timerId] = setTimeout(() => func.apply(this, args), wait);
    };
}

// Debounced render functions
const debouncedRenderCases = debounce(renderCases, 300, 'cases');
const debouncedRenderSchedule = debounce(renderSchedule, 300, 'schedule');
const debouncedRenderFinance = debounce(renderFinance, 300, 'finance');
const debouncedRenderLibrary = debounce(renderLibrary, 300, 'library');
const debouncedRenderDebtors = debounce(renderDebtors, 300, 'debtors');
const debouncedSuggestClients = debounce((input) => suggestClients(input), 200, 'clients');
const debouncedSearchScheduleCases = debounce((input) => searchCasesForSelect(input, 'scheduleCaseSuggestions', 'scheduleCaseId'), 200, 'scheduleCases');
const debouncedSearchFinanceCases = debounce((input) => searchCasesForSelect(input, 'financeCaseSuggestions', 'financeCaseId'), 200, 'financeCases');

// Escape HTML to prevent XSS
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// تبدیل اعداد فارسی به انگلیسی
function convertToEnglishNumbers(str) {
    if (!str) return str;
    const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
    
    for (let i = 0; i < 10; i++) {
        str = str.replace(new RegExp(persianNumbers[i], 'g'), i);
        str = str.replace(new RegExp(arabicNumbers[i], 'g'), i);
    }
    return str;
}

function convertToPersianNumbers(str) {
    if (!str) return str;
    const persianNumbers = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return str.toString().replace(/[0-9]/g, d => persianNumbers[d]);
}

// جداکننده هزارگان
function formatNumber(num) {
    if (!num) return '0';
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

function parseFormattedNumber(str) {
    if (!str) return 0;
    return parseInt(str.replace(/,/g, '')) || 0;
}

// ═════════════════════════════════════════════════
// Initialize
// ═════════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', async () => {
    // Set today date
    const today = getTodayPersian();
    const todayFormatted = new Date().toLocaleDateString('fa-IR');
    
    const todayDateEl = document.getElementById('todayDate');
    const todayDateScheduleEl = document.getElementById('todayDateSchedule');
    const financeDateEl = document.getElementById('financeDate');
    const scheduleDateEl = document.getElementById('scheduleDate');

    if(todayDateEl) todayDateEl.textContent = todayFormatted;
    if(todayDateScheduleEl) todayDateScheduleEl.textContent = todayFormatted;
    if(financeDateEl) financeDateEl.value = todayFormatted;
    if(scheduleDateEl) scheduleDateEl.value = todayFormatted;
    
    // Load theme
    if (localStorage.getItem('theme') === 'dark') {
        document.documentElement.classList.add('dark');
    }
    
    // Initialize charts FIRST
    initCharts();
    
    // Then load data
    await loadData();
    
    // Close dropdowns on outside click
    document.addEventListener('click', (e) => {
        // Close client suggestions
        if (!e.target.closest('#clientSuggestions') && !e.target.closest('#scheduleClient')) {
            const clientSuggestions = document.getElementById('clientSuggestions');
            if(clientSuggestions) clientSuggestions.classList.add('hidden');
        }
        
        // Close case suggestions
        if (!e.target.closest('#scheduleCaseSuggestions') && !e.target.closest('#scheduleCaseSearch')) {
            const el = document.getElementById('scheduleCaseSuggestions');
            if(el) el.classList.add('hidden');
        }
        
        if (!e.target.closest('#financeCaseSuggestions') && !e.target.closest('#financeCaseSearch')) {
            const el = document.getElementById('financeCaseSuggestions');
            if(el) el.classList.add('hidden');
        }
        
        // Close user menu
        if (!e.target.closest('#userMenu') && !e.target.closest('button[onclick*="toggleUserMenu"]')) {
            const userMenu = document.getElementById('userMenu');
            if (userMenu && !userMenu.classList.contains('hidden')) {
                userMenu.classList.add('hidden');
            }
        }
    });
    
    // Setup input formatting
    setupInputFormatting();
    
    // Setup keyboard shortcuts
    setupKeyboardShortcuts();
    
    // Setup notifications
    setupNotifications();
});

// ═════════════════════════════════════════════════
// Input Formatting Setup
// ═════════════════════════════════════════════════
function setupInputFormatting() {
    document.addEventListener('input', function(e) {
        const target = e.target;
        
        // Date fields - convert to English numbers
        const dateFields = ['scheduleDate', 'financeDate', 'caseBirth', 'caseNational', 
                          'caseMobile', 'caseContract', 'filterDateFrom', 'filterDateTo'];
        
        if (dateFields.includes(target.id)) {
            const start = target.selectionStart;
            const end = target.selectionEnd;
            target.value = convertToEnglishNumbers(target.value);
            target.setSelectionRange(start, end);
        }
        
        // Amount fields - format with thousand separator
        if (target.id === 'financeAmount' || target.id === 'casePrice') {
            const start = target.selectionStart;
            let val = target.value.replace(/,/g, '');
            val = convertToEnglishNumbers(val).replace(/[^\d]/g, '');
            
            if (val) {
                val = formatNumber(val);
            }
            target.value = val;
            
            const diff = val.length - target.value.length;
            target.setSelectionRange(start + diff, start + diff);
        }
    });
}

// ═════════════════════════════════════════════════
// Keyboard Shortcuts
// ═════════════════════════════════════════════════
function setupKeyboardShortcuts() {
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const currentView = getCurrentView();
            const backMap = {
                'caseform': 'cases',
                'casedetail': 'cases',
                'scheduleform': 'schedule',
                'financeform': 'finance',
                'debtors': 'finance',
                'libraryform': 'library',
                'settings': 'dashboard',
                'quickadd': 'dashboard'
            };
            
            if (backMap[currentView]) {
                setView(backMap[currentView]);
            }
        }
        
        if (e.ctrlKey && e.key === 'k') {
            e.preventDefault();
            setView('quickadd');
        }
    });
}

function getCurrentView() {
    const views = document.querySelectorAll('.page-view');
    for (const view of views) {
        if (!view.classList.contains('hidden')) {
            return view.id.replace('view-', '');
        }
    }
    return 'dashboard';
}

// ═════════════════════════════════════════════════
// API Functions
// ═════════════════════════════════════════════════
async function loadData() {
    try {
        const res = await fetch('api.php?action=get_data');
        
        // ★★★ تغییر مهم: اگر وضعیت 401 (لاگین نبودن) بود ★★★
        if (res.status === 401) {
            console.warn('دسترسی محدود (401): نمایش فرم ورود');
            
            // نمایش فرم لاگین
            const loginSec = document.getElementById('login-section');
            const appSec = document.getElementById('app-section');
            
            if (loginSec) loginSec.classList.remove('hidden');
            if (appSec) appSec.classList.add('hidden');
            
            // ★ توقف تابع (خیلی مهم: اینجا return می‌کنیم تا ارور ندهد)
            return; 
        }

        // اگر ارور دیگری بود (مثلا سرور خراب است)
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        
        const data = await res.json();
        
        if (data.success) {
            // اگر موفق شد، فرم لاگین را مخفی کن و برنامه را نشان بده
            const loginSec = document.getElementById('login-section');
            const appSec = document.getElementById('app-section');
            
            if (loginSec) loginSec.classList.add('hidden');
            if (appSec) appSec.classList.remove('hidden');

            db = data.data;
            VakilYar.db = db;
            
            // اطمینان از وجود آرایه‌ها
            ['schedule', 'cases', 'finance', 'library'].forEach(key => {
                if (!db[key]) db[key] = [];
            });
            
            refreshAll();
        } else {
            throw new Error(data.message || 'خطا در بارگذاری داده‌ها');
        }
    } catch (err) {
        // اگر ارور مربوط به 401 بود، نادیده بگیر (چون بالا هندل کردیم)
        if (err.message && err.message.includes('401')) return;

        console.error('Load error:', err);
        Swal.fire({
            icon: 'error',
            title: 'خطا در بارگذاری',
            text: err.message,
            confirmButtonText: 'تلاش مجدد'
        }).then(() => loadData());
    }
}

// ═════════════════════════════════════════════════
// تابع ذخیره‌سازی (saveData) - این تابع گم شده بود
// ═════════════════════════════════════════════════
async function saveData(syncType = null, syncItem = null) {
    try {
        const body = { 
            db: VakilYar.db, // کل دیتابیس را می‌فرستیم
            csrf_token: window.CSRF_TOKEN || ''
        };
        
        // اگر نیاز به سینک با گوگل بود (مثلا پرونده جدید)
        if (syncType && syncItem) {
            body.syncType = syncType;
            body.syncItem = syncItem;
        }
        
        const res = await fetch('api.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
            credentials: 'include' // ★★★ خیلی مهم برای سشن ★★★
        });
        
        // چک کردن وضعیت لاگین (اگر موقع ذخیره سشن پرید)
        if (res.status === 401) {
            console.warn('نشست منقضی شد');
            location.reload(); // ریلود کن تا فرم لاگین بیاید
            return false;
        }

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        
        const data = await res.json();
        
        if (data.success) {
            showSyncStatus(); // نمایش پیام سبز "سینک شد"
            return true;
        } else {
            throw new Error(data.message || 'خطا در ذخیره');
        }
    } catch (err) {
        console.error('Save error:', err);
        Swal.fire({
            icon: 'error',
            title: 'خطا در ذخیره',
            text: 'لطفاً اتصال اینترنت را چک کنید و دوباره تلاش کنید',
            confirmButtonText: 'باشه'
        });
        return false;
    }
}

// تابع کمکی برای نمایش وضعیت سینک (بالای صفحه)
function showSyncStatus() {
    const el = document.getElementById('syncStatus');
    if (el) {
        el.classList.remove('hidden');
        el.classList.add('flex');
        setTimeout(() => {
            el.classList.add('hidden');
            el.classList.remove('flex');
        }, 2000);
    }
}

function showSyncStatus() {
    const el = document.getElementById('syncStatus');
    if (el) {
        el.classList.remove('hidden');
        el.classList.add('flex');
        setTimeout(() => {
            el.classList.add('hidden');
            el.classList.remove('flex');
        }, 2000);
    }
}

// ═════════════════════════════════════════════════
// Refresh Functions
// ═════════════════════════════════════════════════
function refreshAll() {
    renderDashboard();
    renderCases();
    renderSchedule();
    renderFinance();
    renderLibrary();
    updateCaseSelects();
}

function updateCaseSelects() {
    const options = '<option value="">بدون پرونده</option>' + 
        db.cases.map(c => `<option value="${c.id}">${escapeHtml(c.name)} - ${escapeHtml(c.title)} ${c.archiveNo ? '('+escapeHtml(c.archiveNo)+')' : ''}</option>`).join('');
    
    const scheduleSelect = document.getElementById('scheduleCaseId');
    const financeSelect = document.getElementById('financeCaseId');

    if(scheduleSelect) scheduleSelect.innerHTML = options;
    if(financeSelect) financeSelect.innerHTML = options;
}

// ═════════════════════════════════════════════════
// Navigation & Theme
// ═════════════════════════════════════════════════
function setView(view) {
    // Hide all pages
    document.querySelectorAll('.page-view').forEach(v => {
        if (v) v.classList.add('hidden');
    });
    
    // Show target page
    const viewElement = document.getElementById('view-' + view);
    if (viewElement) {
        viewElement.classList.remove('hidden');
    } else {
        console.error('View element not found: view-' + view);
        return;
    }
    
    // Update bottom navigation
    document.querySelectorAll('.bottom-nav-item').forEach(item => {
        if (item) item.classList.remove('active');
    });
    
    const bottomNavItem = document.querySelector(`.bottom-nav-item[data-view="${view}"]`);
    if (bottomNavItem) {
        bottomNavItem.classList.add('active');
    }
    
    // Update desktop navigation
    document.querySelectorAll('.desktop-nav-item').forEach(item => {
        if (item) item.classList.remove('active');
    });
    
    const desktopNavItem = document.querySelector(`.desktop-nav-item[data-view="${view}"]`);
    if (desktopNavItem) {
        desktopNavItem.classList.add('active');
    }
    
    // Close user menu
    const userMenu = document.getElementById('userMenu');
    if (userMenu && !userMenu.classList.contains('hidden')) {
        userMenu.classList.add('hidden');
    }
    
    // Load data for specific views
    try {
        switch(view) {
            case 'dashboard': renderDashboard(); break;
            case 'cases': renderCases(); break;
            case 'schedule': renderSchedule(); break;
            case 'finance': renderFinance(); break;
            case 'library': renderLibrary(); break;
            case 'debtors': calculateDebtors(); renderDebtors(); break;
        }
    } catch (error) {
        console.error('Error rendering view:', error);
    }
}

function toggleTheme() {
    document.documentElement.classList.toggle('dark');
    const isDark = document.documentElement.classList.contains('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    
    if (charts.cases || charts.finance) {
        updateChartsTheme();
    }
}

function toggleUserMenu() {
    const menu = document.getElementById('userMenu');
    if (menu) {
        menu.classList.toggle('hidden');
    }
}

// ═════════════════════════════════════════════════
// Dashboard
// ═════════════════════════════════════════════════
function renderDashboard() {
    const today = getTodayPersian();
    
    // Stats
    const activeCases = db.cases.filter(c => c.status === 'جاری').length;
    const todaySchedules = db.schedule.filter(s => comparePersianDates(s.date, today) === 0).length;
    const income = db.finance.filter(f => f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
    const expense = db.finance.filter(f => f.type === 'expense').reduce((a, b) => a + Number(b.amount), 0);
    const totalCases = db.cases.length;
    
    // Calculate monthly comparison
    const currentMonth = getCurrentPersianMonth();
    const lastMonth = getLastPersianMonth();
    
    const currentMonthCases = db.cases.filter(c => {
        if (!c.updatedAt) return false;
        const caseMonth = c.updatedAt.split('/').slice(0, 2).join('/');
        return caseMonth === currentMonth;
    }).length;
    
    const lastMonthCases = db.cases.filter(c => {
        if (!c.updatedAt) return false;
        const caseMonth = c.updatedAt.split('/').slice(0, 2).join('/');
        return caseMonth === lastMonth;
    }).length;
    
    const monthlyChange = lastMonthCases > 0 ? 
        Math.round(((currentMonthCases - lastMonthCases) / lastMonthCases) * 100) : 
        (currentMonthCases > 0 ? 100 : 0);
    
    // Update UI elements
    const updates = {
        'stat-cases': activeCases,
        'stat-today': todaySchedules,
        'stat-income': formatNumber(income),
        'stat-balance': formatNumber(income - expense)
    };
    
    Object.entries(updates).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    });
    
    // Monthly comparison
    const monthlyComparisonEl = document.getElementById('monthly-comparison');
    if(monthlyComparisonEl) {
        const changeIcon = monthlyChange >= 0 ? 'fa-arrow-up' : 'fa-arrow-down';
        const changeClass = monthlyChange >= 0 ? 'text-emerald-600' : 'text-red-600';
        
        monthlyComparisonEl.innerHTML = `
            <span class="text-xs ${changeClass} font-medium">
                ${Math.abs(monthlyChange)}% <i class="fas ${changeIcon}"></i>
            </span>
            <span class="text-xs text-gray-500 mr-2">(کل : ${totalCases})</span>
        `;
    }
    
    // Upcoming schedules
    const upcoming = db.schedule
        .filter(s => comparePersianDates(s.date, today) >= 0 && !s.is_done)
        .sort((a, b) => {
            const dateCompare = comparePersianDates(a.date, b.date);
            if (dateCompare !== 0) return dateCompare;
            return (a.time || '').localeCompare(b.time || '');
        })
        .slice(0, 4);
    
    const upcomingListEl = document.getElementById('upcomingList');
    if(upcomingListEl) {
        upcomingListEl.innerHTML = upcoming.length ? upcoming.map(s => {
            const idx = db.schedule.findIndex(x => x.id === s.id);
            return `
            <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-800 rounded-xl cursor-pointer hover:bg-gray-100 dark:hover:bg-dark-700 transition" onclick="openScheduleModal(${idx})">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 bg-amber-100 dark:bg-amber-900/30 rounded-lg flex items-center justify-center">
                        <i class="fas fa-clock text-amber-600 dark:text-amber-400"></i>
                    </div>
                    <div>
                        <p class="font-medium text-gray-700 dark:text-gray-300">${escapeHtml(s.client) || 'بدون نام'}</p>
                        <p class="text-xs text-gray-400">${escapeHtml(s.label) || 'برنامه'}</p>
                    </div>
                </div>
                <div class="text-left">
                    <p class="font-mono text-sm font-bold text-primary-600 dark:text-gold-500">${s.date.split('/').slice(1).join('/')}</p>
                    <p class="text-xs text-gray-400">${s.time || ''}</p>
                </div>
            </div>
        `}).join('') : '<p class="text-center text-gray-400 py-4">برنامه‌ای نیست</p>';
    }
    
    // Recent cases
    const recentCasesListEl = document.getElementById('recentCasesList');
    if(recentCasesListEl) {
        recentCasesListEl.innerHTML = db.cases.slice(0, 4).map(c => `
            <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-800 rounded-xl cursor-pointer hover:bg-gray-100 dark:hover:bg-dark-700 transition" onclick="showCaseDetail(${c.id})">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 ${c.status === 'جاری' ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'} rounded-lg flex items-center justify-center">
                        <i class="fas fa-folder ${c.status === 'جاری' ? 'text-emerald-600' : 'text-red-600'}"></i>
                    </div>
                    <div>
                        <p class="font-medium text-gray-700 dark:text-gray-300">${escapeHtml(c.name)}</p>
                        <p class="text-xs text-gray-400">${escapeHtml(c.title)}</p>
                    </div>
                </div>
                <span class="${c.status === 'جاری' ? 'badge-success' : 'badge-danger'} text-xs px-2 py-1 rounded">${c.status}</span>
            </div>
        `).join('') || '<p class="text-center text-gray-400 py-4">پرونده‌ای نیست</p>';
    }
    
    // Recent finance
    const recentFinanceListEl = document.getElementById('recentFinanceList');
    if(recentFinanceListEl) {
        recentFinanceListEl.innerHTML = db.finance.slice(0, 4).map(f => {
            const cs = db.cases.find(c => c.id == f.caseId);
            const idx = db.finance.findIndex(x => x.id === f.id);
            return `
                <div class="flex items-center justify-between p-3 bg-gray-50 dark:bg-dark-800 rounded-xl cursor-pointer hover:bg-gray-100 dark:hover:bg-dark-700 transition" onclick="editFinance(${idx})">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 ${f.type === 'income' ? 'bg-emerald-100 dark:bg-emerald-900/30' : 'bg-red-100 dark:bg-red-900/30'} rounded-lg flex items-center justify-center">
                            <i class="fas ${f.type === 'income' ? 'fa-arrow-down text-emerald-600' : 'fa-arrow-up text-red-600'}"></i>
                        </div>
                        <div>
                            <p class="font-medium text-gray-700 dark:text-gray-300">${cs ? escapeHtml(cs.name) : 'بدون پرونده'}</p>
                            <p class="text-xs text-gray-400">${f.date || ''}</p>
                        </div>
                    </div>
                    <p class="font-mono font-bold ${f.type === 'income' ? 'text-emerald-600' : 'text-red-600'}" dir="ltr">${formatNumber(f.amount)}</p>
                </div>
            `;
        }).join('') || '<p class="text-center text-gray-400 py-4">تراکنشی نیست</p>';
    }
    
    // Update charts
    updateCharts();
}

// ═════════════════════════════════════════════════
// Charts
// ═════════════════════════════════════════════════
function initCharts() {
    const casesCtx = document.getElementById('casesChart')?.getContext('2d');
    const financeCtx = document.getElementById('financeChart')?.getContext('2d');
    
    if (!casesCtx || !financeCtx) return;

    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#94a3b8' : '#64748b';
    const gridColor = isDark ? '#1e293b' : '#f1f5f9';
    
    charts.cases = new Chart(casesCtx, {
        type: 'doughnut',
        data: {
            labels: ['جاری', 'مختومه'],
            datasets: [{
                data: [0, 0],
                backgroundColor: ['#10b981', '#ef4444'],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: textColor, font: { family: 'Vazirmatn' } }
                }
            }
        }
    });
    
    charts.finance = new Chart(financeCtx, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                { label: 'دریافت', data: [], backgroundColor: '#10b981' },
                { label: 'هزینه', data: [], backgroundColor: '#ef4444' }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'top',
                    labels: { color: textColor, font: { family: 'Vazirmatn' } }
                }
            },
            scales: {
                x: { grid: { color: gridColor }, ticks: { color: textColor, font: { family: 'Vazirmatn' } } },
                y: { grid: { color: gridColor }, ticks: { color: textColor } }
            }
        }
    });
    
    VakilYar.charts = charts;
}

function updateCharts() {
    if (!charts.cases || !charts.finance) return;
    
    // Cases chart
    const active = db.cases.filter(c => c.status === 'جاری').length;
    const closed = db.cases.filter(c => c.status === 'مختومه').length;
    charts.cases.data.datasets[0].data = [active, closed];
    charts.cases.update();
    
    // Finance chart - Last 6 months
    const months = {};
    db.finance.forEach(f => {
        if (!f.date) return;
        const month = f.date.split('/').slice(0, 2).join('/');
        if (!months[month]) months[month] = { income: 0, expense: 0 };
        if (f.type === 'income' || f.type === 'expense') {
            months[month][f.type] += Number(f.amount) || 0;
        }
    });
    
    const sortedMonths = Object.keys(months).sort().slice(-6);
    charts.finance.data.labels = sortedMonths;
    charts.finance.data.datasets[0].data = sortedMonths.map(m => months[m]?.income || 0);
    charts.finance.data.datasets[1].data = sortedMonths.map(m => months[m]?.expense || 0);
    charts.finance.update();
}

function updateChartsTheme() {
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#94a3b8' : '#64748b';
    const gridColor = isDark ? '#1e293b' : '#f1f5f9';
    
    if (charts.cases) {
        charts.cases.options.plugins.legend.labels.color = textColor;
        charts.cases.update();
    }
    
    if (charts.finance) {
        charts.finance.options.plugins.legend.labels.color = textColor;
        charts.finance.options.scales.x.grid.color = gridColor;
        charts.finance.options.scales.x.ticks.color = textColor;
        charts.finance.options.scales.y.grid.color = gridColor;
        charts.finance.options.scales.y.ticks.color = textColor;
        charts.finance.update();
    }
}

// ═════════════════════════════════════════════════
// Pagination Helper
// ═════════════════════════════════════════════════
function renderPagination(containerId, totalItems, currentPage, itemsPerPage, onPageChange) {
    const container = document.getElementById(containerId);
    if (!container) return;

    const totalPages = Math.ceil(totalItems / itemsPerPage);
    if (totalPages <= 1) {
        container.innerHTML = '';
        return;
    }
    
    let html = `
        <button onclick="${onPageChange}(${currentPage - 1})" ${currentPage === 1 ? 'disabled' : ''}>
            <i class="fas fa-chevron-right"></i>
        </button>
    `;
    
    if (currentPage > 3) {
        html += `<button onclick="${onPageChange}(1)">1</button>`;
        if (currentPage > 4) html += `<span class="px-2">...</span>`;
    }
    
    for (let i = Math.max(1, currentPage - 2); i <= Math.min(totalPages, currentPage + 2); i++) {
        html += `<button onclick="${onPageChange}(${i})" class="${i === currentPage ? 'active' : ''}">${i}</button>`;
    }
    
    if (currentPage < totalPages - 2) {
        if (currentPage < totalPages - 3) html += `<span class="px-2">...</span>`;
        html += `<button onclick="${onPageChange}(${totalPages})">${totalPages}</button>`;
    }
    
    html += `
        <button onclick="${onPageChange}(${currentPage + 1})" ${currentPage === totalPages ? 'disabled' : ''}>
            <i class="fas fa-chevron-left"></i>
        </button>
    `;
    
    container.innerHTML = html;
}

// ═════════════════════════════════════════════════
// Cases
// ═════════════════════════════════════════════════
function renderCases() {
    const search = document.getElementById('searchCases')?.value.toLowerCase() || '';
    const statusFilter = document.getElementById('filterCaseStatus')?.value || '';
    const typeFilter = document.getElementById('filterCaseType')?.value || '';
    
    const filtered = db.cases.filter(c => {
        if (search && !JSON.stringify(c).toLowerCase().includes(search)) return false;
        if (statusFilter && c.status !== statusFilter) return false;
        if (typeFilter && c.type !== typeFilter) return false;
        return true;
    }).sort((a, b) => (b.officeNo || 0) - (a.officeNo || 0));
    
    const { currentPage, itemsPerPage } = pagination.cases;
    const startIdx = (currentPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const paginatedItems = filtered.slice(startIdx, endIdx);
    
    const grid = document.getElementById('casesGrid');
    if(grid) {
        grid.className = "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 pb-4 content-start";
        grid.innerHTML = paginatedItems.map(c => {
            const tags = (c.tags && c.tags.trim()) ? c.tags.split(',').filter(t => t.trim()).slice(0, 2).map(t => 
                `<span class="inline-block px-1.5 py-0.5 text-[10px] rounded bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400">${escapeHtml(t.trim())}</span>`
            ).join('') : '';
            
            return `
                <div class="card p-3 cursor-pointer hover:border-primary-500 dark:hover:border-gold-500 transition group" onclick="showCaseDetail(${c.id})">
                    <div class="flex items-center justify-between mb-2">
                        <div class="flex items-center gap-2">
                            <div class="w-8 h-8 bg-primary-100 dark:bg-primary-900/30 rounded-lg flex items-center justify-center">
                                <i class="fas fa-user text-primary-600 dark:text-primary-400 text-sm"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-gray-800 dark:text-white text-sm">${escapeHtml(c.name)}</h4>
                                <p class="text-xs text-gray-400 font-mono">${escapeHtml(c.mobile)}</p>
                            </div>
                        </div>
                        <div class="flex items-center gap-1">
                            <span class="text-[10px] font-mono bg-gray-100 dark:bg-gray-700 text-gray-500 px-1.5 py-0.5 rounded border border-gray-200 dark:border-gray-600" title="شماره دفتر">
                                #${c.officeNo || '-'}
                            </span>
                            <span class="${c.status === 'جاری' ? 'badge-success' : 'badge-danger'} text-[10px] px-1.5 py-0.5 rounded">${c.status}</span>
                        </div>
                    </div>
                    
                    <p class="text-sm text-gray-700 dark:text-gray-300 mb-1 truncate font-bold">${escapeHtml(c.title)}</p>
                    
                    <div class="flex items-center justify-between text-[10px] text-gray-400">
                        <div class="flex items-center gap-2">
                            <span>${escapeHtml(c.type)}</span>
                            ${c.archiveNo ? `<span class="bg-amber-50 dark:bg-amber-900/20 text-amber-600 dark:text-amber-400 px-1 rounded font-mono dir-ltr">📁 ${escapeHtml(c.archiveNo)}</span>` : ''}
                        </div>
                        <div class="flex gap-1">
                            ${c.hasProsecutor ? '<span title="دادسرا">⚖️</span>' : ''}
                            ${c.hasExecution ? '<span title="اجرای احکام">📋</span>' : ''}
                        </div>
                    </div>
                    
                    ${tags ? `<div class="flex flex-wrap gap-1 mt-2">${tags}</div>` : ''}
                    
                    <div class="flex items-center justify-between mt-2 pt-2 border-t border-gray-100 dark:border-dark-700">
                        <span class="text-[10px] text-gray-400 font-mono">${c.updatedAt || '-'}</span>
                        <div class="flex gap-0.5 opacity-100 lg:opacity-0 group-hover:opacity-100 transition-opacity">
                            <button onclick="event.stopPropagation(); editCase(${c.id})" class="p-1.5 hover:bg-gray-100 dark:hover:bg-dark-700 rounded transition" title="ویرایش">
                                <i class="fas fa-edit text-gray-400 text-xs"></i>
                            </button>
                            <button onclick="event.stopPropagation(); deleteCase(${c.id})" class="p-1.5 hover:bg-red-50 dark:hover:bg-red-900/20 rounded transition" title="حذف">
                                <i class="fas fa-trash text-red-400 text-xs"></i>
                            </button>
                        </div>
                    </div>
                </div>
            `;
        }).join('') || '<div class="col-span-full text-center py-12 text-gray-400"><i class="fas fa-folder-open text-4xl mb-4"></i><p>پرونده‌ای یافت نشد</p></div>';
    }
    
    renderPagination('casesPagination', filtered.length, pagination.cases.currentPage, pagination.cases.itemsPerPage, 'goToCasesPage');
}

function goToCasesPage(page) {
    pagination.cases.currentPage = page;
    renderCases();
    document.getElementById('casesGrid')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function openCaseModal(id = null) {
    const form = document.getElementById('caseForm');
    if (form) form.reset();
    
    document.getElementById('caseId').value = '';
    const caseFormTitle = document.getElementById('caseFormTitle');
    if(caseFormTitle) caseFormTitle.innerHTML = '<i class="fas fa-folder-plus ml-2"></i> پرونده جدید';
    
    const prosecutorFields = document.getElementById('prosecutorFields');
    const executionFields = document.getElementById('executionFields');
    if(prosecutorFields) prosecutorFields.classList.add('hidden');
    if(executionFields) executionFields.classList.add('hidden');
    
    if (id) {
        const c = db.cases.find(x => x.id == id);
        if (c) {
            if(caseFormTitle) caseFormTitle.innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش پرونده';
            
            const fields = {
                'caseId': c.id,
                'caseName': c.name || '',
                'caseMobile': c.mobile || '',
                'caseNational': c.national || '',
                'caseBirth': c.birthDate || '',
                'caseAddress': c.address || '',
                'caseTitle': c.title || '',
                'caseType': c.type || 'حقوقی',
                'caseStatus': c.status || 'جاری',
                'caseBranch': c.branch || '',
                'caseArchiveNo': c.archiveNo || '',
                'caseOpponent': c.opponent || '',
                'caseContract': c.contract || '',
                'casePrice': formatNumber(c.totalPrice || ''),
                'caseProsecutorBranch': c.prosecutorBranch || '',
                'caseProsecutorArchive': c.prosecutorArchive || '',
                'caseExecutionBranch': c.executionBranch || '',
                'caseExecutionArchive': c.executionArchive || '',
                'caseTags': c.tags || '',
                'caseNotes': c.notes || ''
            };
            
            Object.entries(fields).forEach(([id, value]) => {
                const el = document.getElementById(id);
                if (el) el.value = value;
            });
            
            const hasProsecutorEl = document.getElementById('caseHasProsecutor');
            const hasExecutionEl = document.getElementById('caseHasExecution');
            
            if (hasProsecutorEl) hasProsecutorEl.checked = c.hasProsecutor || false;
            if (hasExecutionEl) hasExecutionEl.checked = c.hasExecution || false;
            
            if (c.hasProsecutor && prosecutorFields) prosecutorFields.classList.remove('hidden');
            if (c.hasExecution && executionFields) executionFields.classList.remove('hidden');
        }
    }
    
    setView('caseform');
}

function editCase(id) {
    openCaseModal(id);
}

async function saveCase(e) {
    e.preventDefault();
    
    const id = document.getElementById('caseId').value;
    
    let officeNo;
    if (id) {
        const existingCase = db.cases.find(c => c.id == id);
        officeNo = existingCase ? (existingCase.officeNo || '-') : '-';
    } else {
        const maxNo = db.cases.reduce((max, c) => Math.max(max, parseInt(c.officeNo || 0)), 0);
        officeNo = maxNo + 1;
    }

    const rawPrice = convertToEnglishNumbers(document.getElementById('casePrice').value);
    const cleanPrice = parseFormattedNumber(rawPrice);

    const item = {
        id: id || Date.now(),
        officeNo: officeNo,
        name: document.getElementById('caseName').value,
        mobile: convertToEnglishNumbers(document.getElementById('caseMobile').value),
        national: convertToEnglishNumbers(document.getElementById('caseNational').value),
        birthDate: convertToEnglishNumbers(document.getElementById('caseBirth').value),
        address: document.getElementById('caseAddress').value,
        title: document.getElementById('caseTitle').value,
        type: document.getElementById('caseType').value,
        status: document.getElementById('caseStatus').value,
        branch: document.getElementById('caseBranch').value,
        archiveNo: convertToEnglishNumbers(document.getElementById('caseArchiveNo').value),
        opponent: document.getElementById('caseOpponent').value,
        contract: convertToEnglishNumbers(document.getElementById('caseContract').value),
        totalPrice: cleanPrice,
        hasProsecutor: document.getElementById('caseHasProsecutor').checked,
        prosecutorBranch: document.getElementById('caseProsecutorBranch').value,
        prosecutorArchive: convertToEnglishNumbers(document.getElementById('caseProsecutorArchive').value),
        hasExecution: document.getElementById('caseHasExecution').checked,
        executionBranch: document.getElementById('caseExecutionBranch').value,
        executionArchive: convertToEnglishNumbers(document.getElementById('caseExecutionArchive').value),
        tags: document.getElementById('caseTags').value,
        notes: document.getElementById('caseNotes').value,
        updatedAt: new Date().toLocaleDateString('fa-IR')
    };
    
    if (id) {
        const idx = db.cases.findIndex(c => c.id == id);
        if (idx >= 0) db.cases[idx] = item;
    } else {
        db.cases.unshift(item);
    }
    
    refreshAll();
    await saveData('cases', item);
    
    Swal.fire({ icon: 'success', title: `ذخیره شد | شماره دفتر: ${officeNo}`, timer: 2000, showConfirmButton: false });
    setView('cases');
}

async function deleteCase(id) {
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف پرونده',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله، حذف شود',
        cancelButtonText: 'انصراف',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.cases = db.cases.filter(c => c.id != id);
        refreshAll();
        await saveData();
        setView('cases');
    }
}

function showCaseDetail(id) {
    const c = db.cases.find(x => x.id == id);
    if (!c) return;
    
    const tags = c.tags ? c.tags.split(',').filter(Boolean).map(t => 
        `<span class="tag">${escapeHtml(t.trim())}</span>`
    ).join('') : '<span class="text-gray-400">-</span>';
    
    // Calculate finances
    const finances = db.finance.filter(f => f.caseId == id);
    const income = finances.filter(f => f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
    const expense = finances.filter(f => f.type === 'expense').reduce((a, b) => a + Number(b.amount), 0);
    const totalPrice = parseFormattedNumber(c.totalPrice || 0);
    const debt = totalPrice - income;
    
    // Get recent schedules
    const recentSchedules = db.schedule
        .filter(s => s.caseId == id)
        .sort((a, b) => comparePersianDates(b.date, a.date))
        .slice(0, 3);
    
    // Multi-case check
    const personCases = db.cases.filter(cs => cs.name === c.name);
    let multiCaseInfo = '';
    if (personCases.length > 1) {
        const totalDebtAllCases = personCases.reduce((sum, cs) => {
            const caseIncome = db.finance.filter(f => f.caseId == cs.id && f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
            const casePrice = parseFormattedNumber(cs.totalPrice || 0);
            return sum + (casePrice - caseIncome);
        }, 0);
        
        multiCaseInfo = `
            <div class="col-span-full bg-amber-50 dark:bg-amber-900/10 p-4 rounded-xl border border-amber-200 dark:border-amber-900/30">
                <p class="text-sm text-amber-800 dark:text-amber-300 mb-2">
                    <i class="fas fa-info-circle ml-1"></i>
                    این شخص ${personCases.length} پرونده دارد
                </p>
                <div class="flex justify-between items-center">
                    <span class="text-sm text-amber-700 dark:text-amber-400">بدهی کل از همه پرونده‌ها:</span>
                    <span class="text-lg font-bold text-amber-600 dark:text-amber-400 font-mono" dir="ltr">${formatNumber(totalDebtAllCases)} تومان</span>
                </div>
            </div>
        `;
    }
    
    const caseDetailContent = document.getElementById('caseDetailContent');
    if(caseDetailContent) {
        caseDetailContent.innerHTML = `
            <div class="bg-gradient-to-r from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white p-6 rounded-t-2xl">
                <div class="flex items-center justify-between">
                    <div>
                        <h2 class="text-2xl font-bold mb-1">${escapeHtml(c.name)}</h2>
                        <div class="flex items-center gap-3 text-sm">
                            <span class="bg-white/20 px-3 py-1 rounded-full">پرونده شماره ${c.officeNo || '-'}</span>
                            <span class="bg-white/20 px-3 py-1 rounded-full">${c.status}</span>
                            <span class="bg-white/20 px-3 py-1 rounded-full">${c.type}</span>
                        </div>
                    </div>
                    <div class="text-right">
                        <p class="text-sm opacity-90">عنوان پرونده</p>
                        <p class="text-xl font-bold">${escapeHtml(c.title)}</p>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
                <div class="flex flex-wrap gap-2">
                    <button onclick="openCaseModal(${c.id})" class="px-4 py-2 bg-primary-100 dark:bg-primary-900/20 text-primary-600 dark:text-primary-400 rounded-lg hover:bg-primary-200 transition flex items-center gap-2">
                        <i class="fas fa-edit"></i> ویرایش
                    </button>
                    <button onclick="openFinanceModal()" class="px-4 py-2 bg-emerald-100 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-lg hover:bg-emerald-200 transition flex items-center gap-2">
                        <i class="fas fa-money-bill-wave"></i> ثبت پرداخت
                    </button>
                    <button onclick="openScheduleModal()" class="px-4 py-2 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg hover:bg-blue-200 transition flex items-center gap-2">
                        <i class="fas fa-calendar-plus"></i> افزودن برنامه
                    </button>
                    <a href="tel:${c.mobile}" class="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-200 transition flex items-center gap-2">
                        <i class="fas fa-phone"></i> تماس
                    </a>
                </div>
            </div>
            
            <!-- Financial Summary -->
            <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
                <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                    <i class="fas fa-chart-pie ml-2 text-primary-500"></i> خلاصه وضعیت مالی
                </h3>
                <div class="grid grid-cols-4 gap-4">
                    <div class="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-xl text-center">
                        <p class="text-xs text-blue-600 dark:text-blue-400 mb-1">حق‌الوکاله</p>
                        <p class="text-xl font-bold text-blue-600 dark:text-blue-400 font-mono" dir="ltr">${formatNumber(totalPrice)}</p>
                    </div>
                    <div class="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-xl text-center">
                        <p class="text-xs text-emerald-600 dark:text-emerald-400 mb-1">دریافتی</p>
                        <p class="text-xl font-bold text-emerald-600 dark:text-emerald-400 font-mono" dir="ltr">${formatNumber(income)}</p>
                    </div>
                    <div class="bg-red-50 dark:bg-red-900/20 p-4 rounded-xl text-center">
                        <p class="text-xs text-red-600 dark:text-red-400 mb-1">هزینه</p>
                        <p class="text-xl font-bold text-red-600 dark:text-red-400 font-mono" dir="ltr">${formatNumber(expense)}</p>
                    </div>
                    <div class="${debt > 0 ? 'bg-orange-50 dark:bg-orange-900/20' : 'bg-gray-50 dark:bg-gray-700'} p-4 rounded-xl text-center">
                        <p class="text-xs ${debt > 0 ? 'text-orange-600 dark:text-orange-400' : 'text-gray-600 dark:text-gray-400'} mb-1">مانده</p>
                        <p class="text-xl font-bold ${debt > 0 ? 'text-orange-600 dark:text-orange-400' : 'text-gray-600 dark:text-gray-400'} font-mono" dir="ltr">${formatNumber(debt)}</p>
                    </div>
                </div>
                ${multiCaseInfo}
            </div>
            
            <!-- Client Info -->
            <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
                <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                    <i class="fas fa-user ml-2 text-primary-500"></i> اطلاعات موکل
                </h3>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div><p class="text-xs text-gray-400 mb-1">کد ملی</p><p class="font-mono">${escapeHtml(c.national) || '-'}</p></div>
                    <div><p class="text-xs text-gray-400 mb-1">تاریخ تولد</p><p class="font-mono">${escapeHtml(c.birthDate) || '-'}</p></div>
                    <div><p class="text-xs text-gray-400 mb-1">شماره تماس</p><p class="font-mono">${escapeHtml(c.mobile)}</p></div>
                    <div><p class="text-xs text-gray-400 mb-1">آدرس</p><p class="text-sm">${escapeHtml(c.address) || '-'}</p></div>
                </div>
            </div>
            
            <!-- Case Info -->
            <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
                <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                    <i class="fas fa-folder-open ml-2 text-primary-500"></i> اطلاعات پرونده
                </h3>
                <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div><p class="text-xs text-gray-400 mb-1">شعبه</p><p>${escapeHtml(c.branch) || '-'}</p></div>
                    <div><p class="text-xs text-gray-400 mb-1">شماره بایگانی</p><p class="font-mono bg-amber-100 dark:bg-amber-900/30 text-amber-700 dark:text-amber-300 px-2 py-1 rounded inline-block">${escapeHtml(c.archiveNo) || '-'}</p></div>
                    <div><p class="text-xs text-gray-400 mb-1">طرف دعوی</p><p>${escapeHtml(c.opponent) || '-'}</p></div>
                    <div><p class="text-xs text-gray-400 mb-1">شماره قرارداد</p><p class="font-mono">${escapeHtml(c.contract) || '-'}</p></div>
                </div>
            </div>
            
            ${(c.hasProsecutor || c.hasExecution) ? `
            <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
                <h3 class="text-lg font-bold text-gray-800 dark:text-white mb-4 flex items-center">
                    <i class="fas fa-gavel ml-2 text-primary-500"></i> اطلاعات حقوقی
                </h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    ${c.hasProsecutor ? `
                    <div class="bg-orange-50 dark:bg-orange-900/10 p-4 rounded-xl border border-orange-200 dark:border-orange-900/30">
                        <p class="text-sm font-bold text-orange-700 dark:text-orange-400 mb-3"><i class="fas fa-balance-scale ml-1"></i> دادسرا</p>
                        <div class="grid grid-cols-2 gap-3">
                            <div><p class="text-xs text-gray-500">شعبه:</p><p>${escapeHtml(c.prosecutorBranch) || '-'}</p></div>
                            <div><p class="text-xs text-gray-500">بایگانی:</p><p class="font-mono">${escapeHtml(c.prosecutorArchive) || '-'}</p></div>
                        </div>
                    </div>
                    ` : ''}
                    ${c.hasExecution ? `
                    <div class="bg-purple-50 dark:bg-purple-900/10 p-4 rounded-xl border border-purple-200 dark:border-purple-900/30">
                        <p class="text-sm font-bold text-purple-700 dark:text-purple-400 mb-3"><i class="fas fa-gavel ml-1"></i> اجرای احکام</p>
                        <div class="grid grid-cols-2 gap-3">
                            <div><p class="text-xs text-gray-500">شعبه:</p><p>${escapeHtml(c.executionBranch) || '-'}</p></div>
                            <div><p class="text-xs text-gray-500">بایگانی:</p><p class="font-mono">${escapeHtml(c.executionArchive) || '-'}</p></div>
                        </div>
                    </div>
                    ` : ''}
                </div>
            </div>
            ` : ''}
            
            <!-- Tags & Notes -->
            <div class="bg-white dark:bg-dark-800 p-4 border-b border-gray-100 dark:border-dark-700">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div><h3 class="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">تگ‌ها</h3><div class="flex flex-wrap gap-2">${tags}</div></div>
                    <div><h3 class="text-sm font-bold text-gray-700 dark:text-gray-300 mb-2">یادداشت</h3><div class="bg-amber-50 dark:bg-amber-900/20 p-3 rounded-lg max-h-24 overflow-y-auto"><p class="text-sm whitespace-pre-wrap">${escapeHtml(c.notes) || 'یادداشتی ثبت نشده'}</p></div></div>
                </div>
            </div>
            
            <!-- Actions -->
            <div class="bg-gray-50 dark:bg-dark-800 p-4 rounded-b-2xl flex justify-between">
                <button onclick="setView('cases')" class="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-300 transition">
                    <i class="fas fa-arrow-right ml-2"></i> بازگشت
                </button>
                <div class="flex gap-2">
                    <button onclick="window.print()" class="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded-lg hover:bg-gray-300 transition">
                        <i class="fas fa-print ml-2"></i> چاپ
                    </button>
                    <button onclick="deleteCase(${c.id})" class="px-4 py-2 bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-400 rounded-lg hover:bg-red-200 transition">
                        <i class="fas fa-trash ml-2"></i> حذف
                    </button>
                </div>
            </div>
        `;
    }
    
    setView('casedetail');
}

function toggleProsecutor() {
    const checked = document.getElementById('caseHasProsecutor')?.checked;
    const fields = document.getElementById('prosecutorFields');
    if(fields) fields.classList.toggle('hidden', !checked);
}

function toggleExecution() {
    const checked = document.getElementById('caseHasExecution')?.checked;
    const fields = document.getElementById('executionFields');
    if(fields) fields.classList.toggle('hidden', !checked);
}

// ═════════════════════════════════════════════════
// Schedule
// ═════════════════════════════════════════════════
function renderSchedule() {
    if (currentCalendarView === 'month') {
        renderMonthCalendar();
        return;
    }
    
    const viewToggleBtn = document.getElementById('viewToggleBtn');
    if (viewToggleBtn) {
        viewToggleBtn.innerHTML = '<i class="fas fa-calendar-alt"></i>';
        viewToggleBtn.title = 'نمایش تقویم ماهانه';
    }
    
    const search = document.getElementById('searchSchedule')?.value.toLowerCase() || '';
    const labelFilter = document.getElementById('filterScheduleLabel')?.value || '';
    const today = getTodayPersian();
    
    const filtered = db.schedule.filter(s => {
        if (search && !JSON.stringify(s).toLowerCase().includes(search)) return false;
        if (labelFilter && s.label !== labelFilter) return false;
        return true;
    }).sort((a, b) => {
        const dateCompare = comparePersianDates(a.date, b.date);
        if (dateCompare !== 0) return dateCompare;
        return (a.time || '').localeCompare(b.time || '');
    });
    
    const todayItems = filtered.filter(s => comparePersianDates(s.date, today) === 0);
    const upcomingItems = filtered.filter(s => getDaysUntil(s.date) > 0 && getDaysUntil(s.date) <= 30);
    const pastItems = filtered.filter(s => comparePersianDates(s.date, today) < 0).reverse();
    
    const totalUpcoming = filtered.filter(s => getDaysUntil(s.date) > 0).length;
    const thisWeek = filtered.filter(s => {
        const d = getDaysUntil(s.date);
        return d >= 0 && d <= 7;
    }).length;
    
    const scheduleSummary = document.getElementById('scheduleSummary');
    if(scheduleSummary) {
        scheduleSummary.innerHTML = `
            <div class="flex flex-wrap items-center gap-4 mb-4 text-xs">
                <span class="px-3 py-2 bg-blue-50 dark:bg-blue-900/20 text-blue-600 dark:text-blue-400 rounded-lg flex items-center gap-2">
                    <i class="fas fa-calendar-week"></i> این هفته: <b>${thisWeek}</b>
                </span>
                <span class="px-3 py-2 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-600 dark:text-emerald-400 rounded-lg flex items-center gap-2">
                    <i class="fas fa-chart-line"></i> کل آینده: <b>${totalUpcoming}</b>
                </span>
            </div>
        `;
    }
    
    const todayScheduleList = document.getElementById('todayScheduleList');
    if(todayScheduleList) {
        todayScheduleList.innerHTML = renderScheduleItems(todayItems, 'today');
    }
    
    // Pagination for upcoming
    const { currentPage, itemsPerPage } = pagination.schedule;
    const startIdx = (currentPage - 1) * itemsPerPage;
    const paginatedUpcoming = upcomingItems.slice(startIdx, startIdx + itemsPerPage);
    
    const upcomingScheduleList = document.getElementById('upcomingScheduleList');
    if(upcomingScheduleList) {
        upcomingScheduleList.innerHTML = renderScheduleItems(paginatedUpcoming, 'upcoming');
        renderPagination('schedulePagination', upcomingItems.length, currentPage, itemsPerPage, 'goToSchedulePage');
    }
    
    const pastScheduleList = document.getElementById('pastScheduleList');
    if(pastScheduleList) {
        pastScheduleList.innerHTML = renderScheduleItems(pastItems.slice(0, 10), 'past');
    }
}

function goToSchedulePage(page) {
    pagination.schedule.currentPage = page;
    renderSchedule();
    document.getElementById('upcomingScheduleList')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
}

function renderScheduleItems(items, type) {
    if (!items.length) {
        const emptyTexts = { 'today': 'برنامه‌ای برای امروز نیست', 'upcoming': 'برنامه‌ای در آینده نیست', 'past': 'برنامه‌ای در گذشته نیست' };
        return `<div class="text-center py-8 text-gray-400"><i class="fas fa-calendar-times text-4xl mb-3"></i><p>${emptyTexts[type]}</p></div>`;
    }
    
    const labelColors = {
        'جلسه': 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
        'دادگاه': 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
        'تنظیم': 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
        'پیگیری': 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400'
    };
    
    const labelIcons = { 'جلسه': 'fa-users', 'دادگاه': 'fa-gavel', 'تنظیم': 'fa-file-contract', 'پیگیری': 'fa-phone-alt' };
    
    return items.map(s => {
        const cs = s.caseId ? db.cases.find(c => c.id == s.caseId) : null;
        const idx = db.schedule.findIndex(x => x.id === s.id);
        const daysLeft = getDaysUntil(s.date);
        const dayName = getPersianDayName(s.date);
        const icon = labelIcons[s.label] || 'fa-calendar-check';
        
        let daysLeftText = '', daysLeftClass = '';
        if (daysLeft === 0) { daysLeftText = 'امروز'; daysLeftClass = 'text-red-600 font-bold'; }
        else if (daysLeft === 1) { daysLeftText = 'فردا'; daysLeftClass = 'text-orange-600 font-bold'; }
        else if (daysLeft > 0) { daysLeftText = `${daysLeft} روز مانده`; daysLeftClass = 'text-emerald-600'; }
        else { daysLeftText = `${Math.abs(daysLeft)} روز قبل`; daysLeftClass = 'text-gray-400'; }
        
        let priorityClass = s.label === 'دادگاه' ? 'border-r-4 border-red-500' : s.label === 'جلسه' ? 'border-r-4 border-blue-500' : 'border-r-4 border-gray-300';
        
        return `
            <div class="card p-4 ${s.is_done ? 'opacity-50' : ''} ${priorityClass} transition-all group hover:shadow-lg">
                <div class="flex items-start gap-3">
                    <label class="cursor-pointer mt-1">
                        <input type="checkbox" class="hidden" onchange="toggleScheduleDone(${idx})" ${s.is_done ? 'checked' : ''}>
                        <div class="w-5 h-5 rounded-full border-2 ${s.is_done ? 'bg-emerald-500 border-emerald-500' : 'border-gray-300'} flex items-center justify-center transition">
                            ${s.is_done ? '<i class="fas fa-check text-white text-[10px]"></i>' : ''}
                        </div>
                    </label>
                    
                    <div class="flex-1 min-w-0 cursor-pointer" onclick="openScheduleModal(${idx})">
                        <div class="flex items-center gap-2 mb-2">
                            <i class="fas ${icon} text-gray-500"></i>
                            <h4 class="font-bold text-gray-800 dark:text-white text-sm ${s.is_done ? 'line-through' : ''}">${escapeHtml(s.client) || 'بدون نام'}</h4>
                            ${s.label ? `<span class="${labelColors[s.label] || 'bg-gray-100'} text-[10px] px-1.5 py-0.5 rounded-full">${s.label}</span>` : ''}
                        </div>
                        <p class="text-xs text-gray-500 mb-2 truncate">${escapeHtml(s.desc) || '-'}</p>
                        ${cs ? `<p class="text-[10px] text-primary-600 dark:text-gold-500 mb-2"><i class="fas fa-folder-open ml-1"></i>${escapeHtml(cs.name)}</p>` : ''}
                        ${s.result ? `<p class="text-[10px] text-emerald-600 bg-emerald-50 dark:bg-emerald-900/20 p-2 rounded"><i class="fas fa-check-double ml-1"></i>${escapeHtml(s.result)}</p>` : ''}
                    </div>
                    
                    <div class="text-left shrink-0">
                        <p class="text-xs font-bold text-gray-800 dark:text-white mb-1">${s.date}</p>
                        <p class="text-[10px] text-gray-400 mb-1">${dayName} - ${s.time || ''}</p>
                        <p class="text-[10px] ${daysLeftClass}">${daysLeftText}</p>
                    </div>
                    
                    <button onclick="event.stopPropagation(); deleteSchedule(${idx})" class="p-1.5 opacity-0 group-hover:opacity-100 hover:bg-red-50 rounded-lg transition" title="حذف">
                        <i class="fas fa-trash text-red-400 text-xs"></i>
                    </button>
                </div>
            </div>
        `;
    }).join('');
}

function togglePastSchedule() {
    const list = document.getElementById('pastScheduleList');
    const icon = document.getElementById('pastScheduleIcon');
    if(list && icon) {
        list.classList.toggle('hidden');
        icon.classList.toggle('fa-chevron-down');
        icon.classList.toggle('fa-chevron-up');
    }
}

function toggleCalendarView() {
    currentCalendarView = currentCalendarView === 'list' ? 'month' : 'list';
    VakilYar.state.currentCalendarView = currentCalendarView;
    
    const listViewContainer = document.getElementById('listViewContainer');
    const monthViewContainer = document.getElementById('monthCalendarContainer');
    
    if (currentCalendarView === 'list') {
        if (listViewContainer) listViewContainer.classList.remove('hidden');
        if (monthViewContainer) monthViewContainer.classList.add('hidden');
        renderSchedule();
    } else {
        if (!VakilYar.state.currentDisplayMonth) {
            VakilYar.state.currentDisplayMonth = getTodayPersian();
        }
        if (monthViewContainer) monthViewContainer.classList.remove('hidden');
        if (listViewContainer) listViewContainer.classList.add('hidden');
        renderMonthCalendar();
    }
}

function renderMonthCalendar() {
    const viewToggleBtn = document.getElementById('viewToggleBtn');
    if (viewToggleBtn) {
        viewToggleBtn.innerHTML = '<i class="fas fa-list"></i>';
        viewToggleBtn.title = 'نمایش لیست';
    }
    
    const container = document.getElementById('monthCalendarContainer');
    if (!container) return;
    
    const displayMonth = VakilYar.state.currentDisplayMonth || getTodayPersian();
    const [currentYear, currentMonth] = displayMonth.split('/').map(Number);
    
    const monthDays = getDaysInPersianMonth(currentYear, currentMonth);
    const firstDayOfWeek = getFirstDayOfWeek(currentYear, currentMonth);
    
    let html = `
        <div class="calendar-header flex justify-between items-center p-4 bg-gradient-to-r from-primary-500 to-primary-600 dark:from-gold-500 dark:to-gold-600 text-white rounded-t-xl">
            <button onclick="changeMonth(-1)" class="p-2 hover:bg-white/20 rounded-full transition"><i class="fas fa-chevron-right"></i></button>
            <div class="text-center">
                <h3 class="text-xl font-bold">${getPersianMonthName(currentMonth)} ${currentYear}</h3>
                <p class="text-xs opacity-80 mt-1">${monthDays} روز</p>
            </div>
            <button onclick="changeMonth(1)" class="p-2 hover:bg-white/20 rounded-full transition"><i class="fas fa-chevron-left"></i></button>
        </div>
        <div class="calendar-grid grid grid-cols-7 gap-1 p-2 bg-white dark:bg-dark-800 rounded-b-xl">
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">شنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">یکشنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">دوشنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">سه‌شنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">چهارشنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">پنجشنبه</div>
            <div class="text-center text-xs font-bold text-gray-500 p-2 border-b border-gray-200">جمعه</div>
    `;
    
    for (let i = 0; i < firstDayOfWeek; i++) {
        html += `<div class="p-2 h-24 bg-gray-50 dark:bg-dark-900/20 rounded"></div>`;
    }
    
    for (let day = 1; day <= monthDays; day++) {
        const dateStr = `${currentYear}/${currentMonth.toString().padStart(2, '0')}/${day.toString().padStart(2, '0')}`;
        const daySchedules = db.schedule.filter(s => comparePersianDates(s.date, dateStr) === 0);
        const isToday = comparePersianDates(dateStr, getTodayPersian()) === 0;
        
        html += `
            <div class="calendar-day border border-gray-200 dark:border-dark-700 p-2 h-24 overflow-hidden ${isToday ? 'bg-primary-50 dark:bg-primary-900/20 border-primary-500' : 'hover:bg-gray-50 dark:hover:bg-dark-700'} transition cursor-pointer rounded-lg relative" onclick="openDaySchedules('${dateStr}')">
                <div class="flex justify-between items-start mb-1">
                    <span class="text-sm font-bold ${isToday ? 'text-primary-600' : 'text-gray-700 dark:text-gray-300'}">${convertToPersianNumbers(day.toString())}</span>
                    ${daySchedules.length > 0 ? `<span class="event-count-badge">${daySchedules.length}</span>` : ''}
                </div>
                ${daySchedules.slice(0, 1).map(s => `<div class="text-xs truncate bg-gray-100 dark:bg-dark-700 px-1 rounded">${s.time || ''} ${escapeHtml(s.client) || ''}</div>`).join('')}
            </div>
        `;
    }
    
    html += `</div>`;
    container.innerHTML = html;
}

function changeMonth(direction) {
    let [year, month] = (VakilYar.state.currentDisplayMonth || getTodayPersian()).split('/').map(Number);
    month += direction;
    if (month > 12) { month = 1; year++; }
    else if (month < 1) { month = 12; year--; }
    VakilYar.state.currentDisplayMonth = `${year}/${month.toString().padStart(2, '0')}`;
    renderMonthCalendar();
}

function openDaySchedules(dateStr) {
    const daySchedules = db.schedule.filter(s => comparePersianDates(s.date, dateStr) === 0);
    
    if (daySchedules.length === 0) {
        Swal.fire({
            icon: 'info',
            title: 'رویدادی یافت نشد',
            html: `<p>در تاریخ ${dateStr} برنامه‌ای نیست.</p>`,
            showCancelButton: true,
            confirmButtonText: '<i class="fas fa-plus ml-2"></i>افزودن برنامه',
            cancelButtonText: 'انصراف'
        }).then((result) => {
            if (result.isConfirmed) {
                openScheduleModal();
                setTimeout(() => {
                    const dateInput = document.getElementById('scheduleDate');
                    if(dateInput) dateInput.value = dateStr;
                }, 100);
            }
        });
        return;
    }
    
    let schedulesHTML = daySchedules.map(s => {
        const idx = db.schedule.findIndex(x => x.id === s.id);
        return `
            <div class="border rounded-lg p-4 mb-3 ${s.is_done ? 'opacity-50' : ''} text-right">
                <div class="flex justify-between items-start mb-2">
                    <h4 class="font-bold ${s.is_done ? 'line-through' : ''}">${escapeHtml(s.client) || 'بدون نام'}</h4>
                    <span class="text-xs bg-gray-100 px-2 py-1 rounded">${s.label || ''}</span>
                </div>
                <p class="text-sm text-gray-600 mb-2">${s.time || ''} - ${escapeHtml(s.desc) || ''}</p>
                <div class="flex justify-end gap-2">
                    <button onclick="Swal.close(); toggleScheduleDone(${idx})" class="text-xs px-3 py-1.5 bg-emerald-100 text-emerald-600 rounded-lg">${s.is_done ? 'برگرداندن' : 'انجام شد'}</button>
                    <button onclick="Swal.close(); openScheduleModal(${idx})" class="text-xs px-3 py-1.5 bg-blue-100 text-blue-600 rounded-lg">ویرایش</button>
                    <button onclick="Swal.close(); deleteSchedule(${idx})" class="text-xs px-3 py-1.5 bg-red-100 text-red-600 rounded-lg">حذف</button>
                </div>
            </div>
        `;
    }).join('');
    
    Swal.fire({
        title: `برنامه‌های ${dateStr}`,
        html: `<div class="text-right max-h-96 overflow-y-auto">${schedulesHTML}</div>`,
        width: '600px',
        showConfirmButton: false,
        showCloseButton: true
    });
}

function suggestClients(input) {
    const val = input.value.toLowerCase();
    const box = document.getElementById('clientSuggestions');
    
    if (val.length < 1 || !box) {
        if(box) box.classList.add('hidden');
        return;
    }
    
    const clients = [...new Set(db.cases.map(c => c.name))];
    const matches = clients.filter(n => n.toLowerCase().includes(val));
    
    if (matches.length) {
        box.innerHTML = matches.map(name => `
            <div class="p-3 hover:bg-gray-50 dark:hover:bg-dark-800 cursor-pointer text-sm flex items-center gap-2" onclick="selectClient('${escapeHtml(name).replace(/'/g, "\\'")}')">
                <i class="fas fa-user text-gray-400"></i>${escapeHtml(name)}
            </div>
        `).join('');
        box.classList.remove('hidden');
    } else {
        box.classList.add('hidden');
    }
}

function selectClient(name) {
    const input = document.getElementById('scheduleClient');
    const box = document.getElementById('clientSuggestions');
    
    if(input) input.value = name;
    if(box) box.classList.add('hidden');
    filterRelatedCases(name);
}

function filterRelatedCases(clientName) {
    const relatedCases = db.cases.filter(c => c.name === clientName);
    const select = document.getElementById('scheduleCaseId');
    if (!select) return;
    
    let optionsHTML = '<option value="">بدون پرونده</option>';
    relatedCases.forEach(c => {
        optionsHTML += `<option value="${c.id}">${escapeHtml(c.title)} ${c.archiveNo ? '(📁' + escapeHtml(c.archiveNo) + ')' : ''}</option>`;
    });
    select.innerHTML = optionsHTML;
}

function searchCasesForSelect(input, suggestionsId, selectId) {
    const val = input.value.toLowerCase();
    const box = document.getElementById(suggestionsId);
    
    if (!box) return;
    
    if (val.length < 1) {
        box.classList.add('hidden');
        return;
    }
    
    const cases = db.cases.filter(c => 
        c.name.toLowerCase().includes(val) || 
        c.title.toLowerCase().includes(val) ||
        (c.archiveNo && c.archiveNo.includes(val))
    );
    
    if (cases.length) {
        box.innerHTML = cases.map(c => `
            <div class="p-3 hover:bg-gray-50 dark:hover:bg-dark-800 cursor-pointer text-sm flex items-center gap-2" onclick="selectCaseForSelect(${c.id}, '${selectId}', '${suggestionsId}')">
                <i class="fas fa-folder text-gray-400"></i>
                ${escapeHtml(c.name)} - ${escapeHtml(c.title)} ${c.archiveNo ? '('+escapeHtml(c.archiveNo)+')' : ''}
            </div>
        `).join('');
        box.classList.remove('hidden');
    } else {
        box.classList.add('hidden');
    }
}

function selectCaseForSelect(id, selectId, suggestionsId) {
    const select = document.getElementById(selectId);
    const box = document.getElementById(suggestionsId);
    
    if (select) select.value = id;
    if (box) box.classList.add('hidden');
}

function openScheduleModal(idx = null) {
    const form = document.getElementById('scheduleForm');
    if (form) form.reset();
    
    document.getElementById('scheduleId').value = '';
    document.getElementById('scheduleDate').value = new Date().toLocaleDateString('fa-IR');
    
    const title = document.getElementById('scheduleFormTitle');
    if(title) title.innerHTML = '<i class="fas fa-calendar-plus ml-2"></i> برنامه جدید';
    
    updateCaseSelects();
    
    if (idx !== null && db.schedule[idx]) {
        const s = db.schedule[idx];
        if(title) title.innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش برنامه';
        
        // ✅ اصلاح: ذخیره id به جای idx
        document.getElementById('scheduleId').value = s.id;
        document.getElementById('scheduleDate').value = s.date || '';
        document.getElementById('scheduleTime').value = s.time || '';
        document.getElementById('scheduleClient').value = s.client || '';
        document.getElementById('scheduleCaseId').value = s.caseId || '';
        document.getElementById('scheduleLabel').value = s.label || '';
        document.getElementById('scheduleDesc').value = s.desc || '';
        document.getElementById('scheduleResult').value = s.result || '';
    }
    
    setView('scheduleform');
}

async function saveSchedule(e) {
    e.preventDefault();
    
    const scheduleIdValue = document.getElementById('scheduleId').value;
    const isEditing = scheduleIdValue !== '';
    
    // ✅ اصلاح: جستجو با id نه idx
    let existingItem = null;
    let existingIndex = -1;
    
    if (isEditing) {
        existingIndex = db.schedule.findIndex(s => s.id == scheduleIdValue);
        if (existingIndex > -1) {
            existingItem = db.schedule[existingIndex];
        }
    }

    const item = {
        id: existingItem ? existingItem.id : Date.now(),
        date: convertToEnglishNumbers(document.getElementById('scheduleDate').value),
        time: document.getElementById('scheduleTime').value,
        client: document.getElementById('scheduleClient').value,
        caseId: document.getElementById('scheduleCaseId').value,
        label: document.getElementById('scheduleLabel').value,
        desc: document.getElementById('scheduleDesc').value,
        result: document.getElementById('scheduleResult').value,
        is_done: existingItem ? existingItem.is_done : false
    };
    
    if (item.caseId) {
        const cs = db.cases.find(c => c.id == item.caseId);
        if (cs) item.caseName = cs.name;
    }
    
    if (existingIndex > -1) {
        db.schedule[existingIndex] = item;
    } else {
        db.schedule.unshift(item);
    }
    
    refreshAll();
    await saveData('schedule', item);
    
    Swal.fire({ icon: 'success', title: 'ذخیره شد', timer: 1500, showConfirmButton: false });
    setView('schedule');
}

async function toggleScheduleDone(idx) {
    if (!db.schedule[idx]) return;
    db.schedule[idx].is_done = !db.schedule[idx].is_done;
    refreshAll();
    await saveData('schedule', db.schedule[idx]);
}

async function deleteSchedule(idx) {
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف برنامه',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.schedule.splice(idx, 1);
        refreshAll();
        await saveData();
        setView('schedule');
    }
}

// ═════════════════════════════════════════════════
// Finance
// ═════════════════════════════════════════════════
function renderFinance() {
    const search = document.getElementById('searchFinance')?.value.toLowerCase() || '';
    const typeFilter = document.getElementById('filterFinanceType')?.value || '';
    const dateFrom = convertToEnglishNumbers(document.getElementById('filterDateFrom')?.value || '');
    const dateTo = convertToEnglishNumbers(document.getElementById('filterDateTo')?.value || '');
    
    const filtered = db.finance.filter(f => {
        if (search && !JSON.stringify(f).toLowerCase().includes(search)) return false;
        if (typeFilter && f.type !== typeFilter) return false;
        if (dateFrom && comparePersianDates(f.date, dateFrom) < 0) return false;
        if (dateTo && comparePersianDates(f.date, dateTo) > 0) return false;
        return true;
    });
    
    const income = filtered.filter(f => f.type === 'income').reduce((a, b) => a + Number(b.amount), 0);
    const expense = filtered.filter(f => f.type === 'expense').reduce((a, b) => a + Number(b.amount), 0);
    
    const updates = {
        'totalIncome': formatNumber(income),
        'totalExpense': formatNumber(expense),
        'totalBalance': formatNumber(income - expense)
    };
    
    Object.entries(updates).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.textContent = value;
    });
    
    const { currentPage, itemsPerPage } = pagination.finance;
    const startIdx = (currentPage - 1) * itemsPerPage;
    const paginatedItems = filtered.slice(startIdx, startIdx + itemsPerPage);
    
    const tbody = document.getElementById('financeTableBody');
    if(tbody) {
        tbody.innerHTML = paginatedItems.map(f => {
            const cs = db.cases.find(c => c.id == f.caseId);
            const idx = db.finance.findIndex(x => x.id === f.id);
            
            return `
                <tr class="table-row">
                    <td class="p-4 font-mono text-sm text-gray-500">${f.date || ''}</td>
                    <td class="p-4">${cs ? `<span class="font-medium">${escapeHtml(cs.name)}</span>` : '<span class="text-gray-400">بدون پرونده</span>'}</td>
                    <td class="p-4"><span class="${f.type === 'income' ? 'badge-success' : 'badge-danger'} px-2 py-1 rounded text-xs">${f.type === 'income' ? 'دریافت' : 'هزینه'}</span></td>
                    <td class="p-4 font-mono font-bold ${f.type === 'income' ? 'text-emerald-600' : 'text-red-600'}" dir="ltr">${formatNumber(f.amount)}</td>
                    <td class="p-4 text-sm text-gray-500 max-w-[200px] truncate">${escapeHtml(f.desc) || '-'}</td>
                    <td class="p-4 text-center">
                        <button onclick="editFinance(${idx})" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-700 rounded-lg transition"><i class="fas fa-edit text-gray-400"></i></button>
                        <button onclick="deleteFinance(${idx})" class="p-2 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition"><i class="fas fa-trash text-red-400"></i></button>
                    </td>
                </tr>
            `;
        }).join('') || '<tr><td colspan="6" class="p-8 text-center text-gray-400">تراکنشی یافت نشد</td></tr>';
    }
    
    renderPagination('financePagination', filtered.length, currentPage, itemsPerPage, 'goToFinancePage');
}

function goToFinancePage(page) {
    pagination.finance.currentPage = page;
    renderFinance();
}

function clearDateFilters() {
    const from = document.getElementById('filterDateFrom');
    const to = document.getElementById('filterDateTo');
    if(from) from.value = '';
    if(to) to.value = '';
    renderFinance();
}

function openFinanceModal(idx = null) {
    const form = document.getElementById('financeForm');
    if (form) form.reset();
    
    document.getElementById('financeId').value = '';
    document.getElementById('financeDate').value = new Date().toLocaleDateString('fa-IR');
    
    const title = document.getElementById('financeFormTitle');
    if(title) title.innerHTML = '<i class="fas fa-money-bill-wave ml-2"></i> تراکنش جدید';
    
    updateCaseSelects();
    
    if (idx !== null && db.finance[idx]) {
        const f = db.finance[idx];
        if(title) title.innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش تراکنش';
        document.getElementById('financeId').value = idx;
        document.getElementById('financeCaseId').value = f.caseId || '';
        document.getElementById('financeType').value = f.type || 'income';
        document.getElementById('financeDate').value = f.date || '';
        document.getElementById('financeAmount').value = formatNumber(f.amount || '');
        document.getElementById('financeDesc').value = f.desc || '';
    }
    
    setView('financeform');
}

function editFinance(idx) {
    openFinanceModal(idx);
}

async function saveFinance(e) {
    e.preventDefault();
    
    const idx = document.getElementById('financeId').value;
    const rawAmount = convertToEnglishNumbers(document.getElementById('financeAmount').value);
    const cleanAmount = parseFormattedNumber(rawAmount);
    
    const item = {
        id: idx !== '' ? db.finance[idx].id : Date.now(),
        caseId: document.getElementById('financeCaseId').value,
        type: document.getElementById('financeType').value,
        date: convertToEnglishNumbers(document.getElementById('financeDate').value),
        amount: cleanAmount,
        desc: document.getElementById('financeDesc').value
    };
    
    if (item.caseId) {
        const cs = db.cases.find(c => c.id == item.caseId);
        if (cs) item.caseName = cs.name;
    }
    
    if (idx !== '') {
        db.finance[idx] = item;
    } else {
        db.finance.unshift(item);
    }
    
    refreshAll();
    await saveData('finance', item);
    
    Swal.fire({ icon: 'success', title: 'ذخیره شد', timer: 1500, showConfirmButton: false });
    setView('finance');
}

async function deleteFinance(idx) {
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف تراکنش',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.finance.splice(idx, 1);
        refreshAll();
        await saveData();
        setView('finance');
    }
}

// ═════════════════════════════════════════════════
// Debtors
// ═════════════════════════════════════════════════
let allDebtors = [];

function calculateDebtors() {
    allDebtors = [];
    let totalAllDebt = 0;
    
    db.cases.forEach(c => {
        const contractAmount = parseInt(c.totalPrice) || 0;
        if (contractAmount === 0) return;
        
        const paidAmount = db.finance
            .filter(f => f.caseId == c.id && f.type === 'income')
            .reduce((sum, f) => sum + (parseInt(f.amount) || 0), 0);
            
        const debt = contractAmount - paidAmount;
        
        if (debt > 0) {
            allDebtors.push({
                id: c.id, name: c.name, title: c.title,
                contract: contractAmount, paid: paidAmount, debt: debt,
                mobile: c.mobile, archiveNo: c.archiveNo, status: c.status
            });
            totalAllDebt += debt;
        }
    });
    
    allDebtors.sort((a, b) => b.debt - a.debt);
    const totalEl = document.getElementById('totalDebtAmount');
    if(totalEl) totalEl.innerText = formatNumber(totalAllDebt) + ' تومان';
}

function renderDebtors() {
    const search = document.getElementById('searchDebtors')?.value.toLowerCase() || '';
    
    let filtered = allDebtors.filter(d => {
        if (search && !JSON.stringify(d).toLowerCase().includes(search)) return false;
        return true;
    });
    
    const { currentPage, itemsPerPage } = pagination.debtors;
    const startIdx = (currentPage - 1) * itemsPerPage;
    const paginatedItems = filtered.slice(startIdx, startIdx + itemsPerPage);
    
    const container = document.getElementById('debtorsListContent');
    if(container) {
        if (paginatedItems.length === 0) {
            container.innerHTML = `<div class="text-center py-8 text-gray-400"><i class="fas fa-check-circle text-4xl mb-3 text-emerald-500"></i><p>بدهکاری یافت نشد!</p></div>`;
        } else {
            container.innerHTML = paginatedItems.map(d => {
                const percent = Math.min(100, Math.round((d.paid / d.contract) * 100));
                const urgency = d.debt > 5000000 ? 'high' : d.debt > 2000000 ? 'medium' : 'low';
                const urgencyColors = { high: 'border-red-500', medium: 'border-orange-500', low: 'border-amber-500' };
                
                return `
                <div class="card p-5 border-r-4 ${urgencyColors[urgency]} hover:shadow-lg transition">
                    <div class="flex justify-between items-start mb-3">
                        <div>
                            <h4 class="font-bold text-lg">${escapeHtml(d.name)}</h4>
                            <p class="text-sm text-gray-600">${escapeHtml(d.title)}</p>
                        </div>
                        <div class="text-left">
                            <p class="text-xs text-gray-400">مانده بدهی</p>
                            <p class="font-bold text-xl ${urgency === 'high' ? 'text-red-600' : urgency === 'medium' ? 'text-orange-600' : 'text-amber-600'} font-mono">${formatNumber(d.debt)}</p>
                        </div>
                    </div>
                    <div class="grid grid-cols-2 gap-4 mb-3">
                        <div><p class="text-xs text-gray-400">قرارداد</p><p class="font-mono">${formatNumber(d.contract)}</p></div>
                        <div><p class="text-xs text-gray-400">پرداخت شده</p><p class="font-mono">${formatNumber(d.paid)}</p></div>
                    </div>
                    <div class="w-full bg-gray-200 rounded-full h-2.5 mb-3">
                        <div class="bg-emerald-500 h-2.5 rounded-full transition-all" style="width: ${percent}%"></div>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-xs text-gray-500">${percent}% پرداخت شده</span>
                        <div class="flex gap-2">
                            <button onclick="showCaseDetail(${d.id})" class="text-xs text-blue-600 bg-blue-50 px-2 py-1 rounded hover:bg-blue-100"><i class="fas fa-folder-open ml-1"></i>پرونده</button>
                            <a href="tel:${d.mobile}" class="text-xs text-green-600 bg-green-50 px-2 py-1 rounded hover:bg-green-100"><i class="fas fa-phone ml-1"></i>تماس</a>
                        </div>
                    </div>
                </div>
                `;
            }).join('');
        }
    }
    
    renderPagination('debtorsPagination', filtered.length, currentPage, itemsPerPage, 'goToDebtorsPage');
}

function goToDebtorsPage(page) {
    pagination.debtors.currentPage = page;
    renderDebtors();
}

// ═════════════════════════════════════════════════
// Library
// ═════════════════════════════════════════════════
function renderLibrary() {
    const search = document.getElementById('searchLibrary')?.value.toLowerCase() || '';
    
    const filtered = db.library.filter(l => {
        if (search && !l.title.toLowerCase().includes(search) && !(l.content || '').toLowerCase().includes(search)) return false;
        return true;
    });
    
    const list = document.getElementById('libraryList');
    if(list) {
        list.innerHTML = filtered.map(l => `
            <div onclick="viewLibrary(${l.id})" class="p-4 rounded-xl cursor-pointer transition border ${currentLibraryId == l.id ? 'bg-primary-50 dark:bg-primary-900/20 border-primary-500' : 'bg-gray-50 dark:bg-dark-800 border-transparent hover:border-gray-200'}">
                <div class="flex items-start justify-between mb-2">
                    <h4 class="font-bold text-sm">${escapeHtml(l.title)}</h4>
                    <span class="tag text-xs">${escapeHtml(l.type)}</span>
                </div>
                <p class="text-xs text-gray-400 line-clamp-2">${escapeHtml((l.content || '').substring(0, 100))}...</p>
            </div>
        `).join('') || '<p class="text-center text-gray-400 py-8">متنی یافت نشد</p>';
    }
}

function viewLibrary(id) {
    const l = db.library.find(x => x.id == id);
    if (!l) return;
    
    currentLibraryId = id;
    VakilYar.state.currentLibraryId = id;
    
    const empty = document.getElementById('libraryEmpty');
    const content = document.getElementById('libraryContent');
    
    if(empty) empty.classList.add('hidden');
    if(content) content.classList.remove('hidden');
    
    const titleEl = document.getElementById('libraryViewTitle');
    const typeEl = document.getElementById('libraryViewType');
    const contentEl = document.getElementById('libraryViewContent');

    if(titleEl) titleEl.textContent = l.title;
    if(typeEl) typeEl.textContent = l.type;
    if(contentEl) contentEl.textContent = l.content || '';
    
    renderLibrary();
}

function openLibraryModal(id = null) {
    const form = document.getElementById('libraryForm');
    if (form) form.reset();
    
    document.getElementById('libraryId').value = '';
    const title = document.getElementById('libraryFormTitle');
    if(title) title.innerHTML = '<i class="fas fa-file-alt ml-2"></i> متن جدید';
    
    if (id) {
        const l = db.library.find(x => x.id == id);
        if (l) {
            if(title) title.innerHTML = '<i class="fas fa-edit ml-2"></i> ویرایش متن';
            document.getElementById('libraryId').value = l.id;
            document.getElementById('libraryTitle').value = l.title || '';
            document.getElementById('libraryType').value = l.type || 'لایحه';
            document.getElementById('libraryInputText').value = l.content || ''; 
        }
    }
    
    setView('libraryform');
}

function editLibrary() {
    if (currentLibraryId) openLibraryModal(currentLibraryId);
}

async function saveLibrary(e) {
    e.preventDefault();
    
    const id = document.getElementById('libraryId').value;
    const item = {
        id: id || Date.now(),
        title: document.getElementById('libraryTitle').value,
        type: document.getElementById('libraryType').value,
        content: document.getElementById('libraryInputText').value 
    };
    
    if (id) {
        const idx = db.library.findIndex(l => l.id == id);
        if (idx >= 0) db.library[idx] = item;
    } else {
        db.library.unshift(item);
    }
    
    refreshAll();
    viewLibrary(item.id);
    await saveData('library', item);
    
    Swal.fire({ icon: 'success', title: 'ذخیره شد', timer: 1500, showConfirmButton: false });
    setView('library');
}

async function deleteLibrary() {
    if (!currentLibraryId) return;
    
    const result = await Swal.fire({
        icon: 'warning',
        title: 'حذف متن',
        text: 'آیا مطمئن هستید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (result.isConfirmed) {
        db.library = db.library.filter(l => l.id != currentLibraryId);
        currentLibraryId = null;
        
        const empty = document.getElementById('libraryEmpty');
        const content = document.getElementById('libraryContent');
        if(empty) empty.classList.remove('hidden');
        if(content) content.classList.add('hidden');
        
        refreshAll();
        await saveData();
        setView('library');
    }
}

async function copyLibraryContent() {
    const content = document.getElementById('libraryViewContent')?.textContent;
    if(content) {
        await navigator.clipboard.writeText(content);
        Swal.fire({ icon: 'success', title: 'کپی شد!', timer: 1000, showConfirmButton: false, position: 'bottom-end', toast: true });
    }
}

// ═════════════════════════════════════════════════
// Backup & Restore
// ═════════════════════════════════════════════════
function downloadBackup() {
    const dataStr = JSON.stringify(db, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `backup_${new Date().toLocaleDateString('fa-IR').replace(/\//g, '-')}.json`;
    link.click();
    URL.revokeObjectURL(url);
    
    Swal.fire({ icon: 'success', title: 'بک‌آپ دانلود شد', timer: 2000, showConfirmButton: false });
}

async function restoreBackup(event) {
    const file = event.target.files[0];
    if (!file) return;
    
    const result = await Swal.fire({
        icon: 'warning',
        title: 'بازگردانی بک‌آپ',
        text: 'تمام داده‌های فعلی جایگزین می‌شوند. مطمئنید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر',
        confirmButtonColor: '#ef4444'
    });
    
    if (!result.isConfirmed) {
        event.target.value = '';
        return;
    }
    
    const reader = new FileReader();
    reader.onload = async (e) => {
        try {
            const restored = JSON.parse(e.target.result);
            if (restored.cases && restored.finance && restored.library && restored.schedule) {
                db = restored;
                VakilYar.db = db;
                await saveData();
                refreshAll();
                Swal.fire({ icon: 'success', title: 'بازگردانی موفق', confirmButtonText: 'باشه' });
            } else {
                throw new Error('فرمت نامعتبر');
            }
        } catch (err) {
            Swal.fire({ icon: 'error', title: 'خطا', text: 'فایل بک‌آپ معتبر نیست', confirmButtonText: 'باشه' });
        }
        event.target.value = '';
    };
    reader.readAsText(file);
}

// ═════════════════════════════════════════════════
// Google Sheet Sync
// ═════════════════════════════════════════════════
async function syncAllToGoogleSheet() {
    const result = await Swal.fire({
        icon: 'question',
        title: 'ارسال به گوگل شیت',
        text: 'ادامه می‌دهید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر'
    });
    
    if (!result.isConfirmed) return;
    
    Swal.fire({ title: 'در حال ارسال...', allowOutsideClick: false, didOpen: () => Swal.showLoading() });
    
    try {
        let count = 0;
        for (const item of db.cases) { await saveData('cases', item); count++; }
        for (const item of db.finance) { await saveData('finance', item); count++; }
        for (const item of db.schedule) { await saveData('schedule', item); count++; }
        for (const item of db.library) { await saveData('library', item); count++; }
        
        Swal.fire({ icon: 'success', title: 'ارسال موفق', text: `${count} مورد ارسال شد`, confirmButtonText: 'عالی' });
    } catch (err) {
        Swal.fire({ icon: 'error', title: 'خطا در ارسال', confirmButtonText: 'باشه' });
    }
}

async function testGoogleSheetConnection() {
    try {
        const res = await fetch('api.php?action=test_google');
        const data = await res.json();
        
        if (data.success) {
            Swal.fire({ icon: 'success', title: 'متصل است! ✅', confirmButtonText: 'عالی' });
        } else {
            Swal.fire({ icon: 'error', title: 'متصل نیست ❌', text: data.message || '', confirmButtonText: 'باشه' });
        }
    } catch (err) {
        Swal.fire({ icon: 'error', title: 'خطا', text: 'مشکل در ارتباط با سرور', confirmButtonText: 'باشه' });
    }
}

// ═════════════════════════════════════════════════
// Logout
// ═════════════════════════════════════════════════
async function logout() {
    const result = await Swal.fire({
        icon: 'question',
        title: 'خروج از سیستم',
        text: 'آیا می‌خواهید خارج شوید؟',
        showCancelButton: true,
        confirmButtonText: 'بله',
        cancelButtonText: 'خیر'
    });
    
    if (result.isConfirmed) {
        await fetch('api.php?action=logout');
        location.reload();
    }
}

// ═════════════════════════════════════════════════
// Date Helpers
// ═════════════════════════════════════════════════
function comparePersianDates(date1, date2) {
    const d1 = convertToEnglishNumbers(date1 || '');
    const d2 = convertToEnglishNumbers(date2 || '');
    
    const normalize = (d) => {
        const parts = d.split('/');
        if (parts.length !== 3) return 0;
        return parseInt(parts[0]) * 10000 + parseInt(parts[1]) * 100 + parseInt(parts[2]);
    };
    
    return normalize(d1) - normalize(d2);
}

function getTodayPersian() {
    return convertToEnglishNumbers(new Date().toLocaleDateString('fa-IR'));
}

function getDaysUntil(targetDate) {
    const today = getTodayPersian();
    const t = convertToEnglishNumbers(today).split('/').map(Number);
    const d = convertToEnglishNumbers(targetDate || '').split('/').map(Number);
    
    if (t.length !== 3 || d.length !== 3) return 0;
    
    const todayDays = t[0] * 365 + t[1] * 30 + t[2];
    const targetDays = d[0] * 365 + d[1] * 30 + d[2];
    
    return targetDays - todayDays;
}

function getPersianDayName(dateStr) {
    const days = ['یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه', 'شنبه'];
    
    try {
        const d = convertToEnglishNumbers(dateStr || '').split('/').map(Number);
        if (d.length !== 3) return '';
        
        const gYear = d[0] + 621;
        const gMonth = d[1] <= 6 ? d[1] + 3 : d[1] - 6;
        const gDay = d[2];
        
        const date = new Date(gYear, gMonth - 1, gDay);
        return days[date.getDay()];
    } catch {
        return '';
    }
}

function getPersianMonthName(month) {
    const months = ['', 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
    return months[month] || '';
}

function getDaysInPersianMonth(year, month) {
    if (month <= 6) return 31;
    if (month <= 11) return 30;
    return isPersianLeapYear(year) ? 30 : 29;
}

function isPersianLeapYear(year) {
    const remainder = year % 33;
    return [1, 5, 9, 13, 17, 22, 26, 30].includes(remainder);
}

function getFirstDayOfWeek(year, month) {
    const dateStr = `${year}/${month.toString().padStart(2, '0')}/01`;
    const dayName = getPersianDayName(dateStr);
    const days = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];
    return days.indexOf(dayName);
}

function getCurrentPersianMonth() {
    const today = new Date().toLocaleDateString('fa-IR');
    return today.split('/').slice(0, 2).join('/');
}

function getLastPersianMonth() {
    const today = new Date();
    const lastMonth = new Date(today);
    lastMonth.setMonth(today.getMonth() - 1);
    return lastMonth.toLocaleDateString('fa-IR').split('/').slice(0, 2).join('/');
}

function shamsiToMiladi(shamsiDate) {
    if(!shamsiDate) return null;
    const jalali = shamsiDate.split('/').map(Number);
    let jy = jalali[0], jm = jalali[1], jd = jalali[2];
    let gy = (jy <= 979) ? 621 : 1600;
    jy -= (jy <= 979) ? 0 : 979;
    let days = (365 * jy) + ((parseInt(jy / 33)) * 8) + parseInt(((jy % 33) + 3) / 4) + 78 + jd + ((jm < 7) ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    gy += 400 * parseInt(days / 146097);
    days %= 146097;
    if (days > 36524) {
        gy += 100 * parseInt(--days / 36524);
        days %= 36524;
        if (days >= 365) days++;
    }
    gy += 4 * parseInt((days) / 1461);
    days %= 1461;
    gy += parseInt((days - 1) / 365);
    if (days > 365) days = (days - 1) % 365;
    let gd = days + 1;
    let sal_a = [0, 31, ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0)) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    let gm;
    for (gm = 0; gm < 13; gm++) {
        let v = sal_a[gm];
        if (gd <= v) break;
        gd -= v;
    }
    return new Date(gy, gm - 1, gd);
}

// ═════════════════════════════════════════════════
// Notifications
// ═════════════════════════════════════════════════
function setupNotifications() {
    if (!("Notification" in window)) return;
    
    if (Notification.permission === "default") {
        setTimeout(() => {
            Notification.requestPermission();
        }, 3000);
    }
    
    // Check reminders every 5 minutes
    setInterval(checkReminders, 300000);
    
    // Initial check
    setTimeout(checkReminders, 5000);
}

function checkReminders() {
    if (Notification.permission !== "granted") return;

    const now = new Date();
    
    db.schedule.forEach(s => {
        if (s.is_done) return;
        
        const eventDate = shamsiToMiladi(s.date);
        if (!eventDate) return;
        
        const timeParts = s.time ? s.time.split(':') : ['09', '00'];
        eventDate.setHours(parseInt(timeParts[0]), parseInt(timeParts[1]), 0);
        
        const diffMs = eventDate - now;
        const diffHours = diffMs / (1000 * 60 * 60);

        const id24 = `notif_24_${s.id}`;
        const id1 = `notif_1_${s.id}`;

        // 24 hours before notification
        if (diffHours > 23 && diffHours < 24.1 && !localStorage.getItem(id24)) {
            sendNotification(
                `📅 یادآوری فردا: ${s.client || 'برنامه'}`, 
                `فردا ساعت ${s.time} برنامه "${s.label || 'جلسه'}" دارید.`
            );
            localStorage.setItem(id24, 'sent');
        }

        // 1 hour before notification
        if (diffHours > 0.8 && diffHours < 1.1 && !localStorage.getItem(id1)) {
            const urgency = s.label === 'دادگاه' ? '🚨 مهم: ' : '⏰ ';
            sendNotification(
                `${urgency}یک ساعت تا جلسه`, 
                `ساعت ${s.time} با ${s.client || 'موکل'} - ${s.desc || ''}`
            );
            localStorage.setItem(id1, 'sent');
        }
        
        // Overdue notification (for important events)
        if (diffHours < 0 && diffHours > -24 && !localStorage.getItem(`overdue_${s.id}`)) {
            if(s.label === 'دادگاه' || s.label === 'تنظیم') {
                sendNotification(
                    `⚠️ مهلت گذشت!`, 
                    `برنامه ${s.client || ''} در تاریخ ${s.date} انجام نشده است.`
                );
                localStorage.setItem(`overdue_${s.id}`, 'sent');
            }
        }
    });
}

function sendNotification(title, body) {
    try {
        const notif = new Notification(title, {
            body: body,
            icon: 'img/vakilyar.png',
            dir: 'rtl',
            tag: title, // Prevent duplicate notifications
            requireInteraction: false
        });
        
        // Auto close after 10 seconds
        setTimeout(() => {
            notif.close();
        }, 10000);
        
        // Handle click
        notif.onclick = function() {
            window.focus();
            setView('schedule');
            notif.close();
        };
    } catch (err) {
        console.error('Notification error:', err);
    }
}

// ═════════════════════════════════════════════════
// Service Worker Registration (PWA)
// ═════════════════════════════════════════════════
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('sw.js')
            .then(registration => {
                console.log('SW registered:', registration.scope);
            })
            .catch(error => {
                console.log('SW registration failed:', error);
            });
    });
}

// ═════════════════════════════════════════════════
// Global Error Handler
// ═════════════════════════════════════════════════
window.onerror = function(message, source, lineno, colno, error) {
    console.error('Global error:', { message, source, lineno, colno, error });
    return false;
};

window.addEventListener('unhandledrejection', function(event) {
    console.error('Unhandled promise rejection:', event.reason);
});

// ═════════════════════════════════════════════════
// Expose functions to global scope (for onclick handlers)
// ═════════════════════════════════════════════════
window.setView = setView;
window.toggleTheme = toggleTheme;
window.toggleUserMenu = toggleUserMenu;
window.logout = logout;

// Cases
window.renderCases = renderCases;
window.debouncedRenderCases = debouncedRenderCases;
window.goToCasesPage = goToCasesPage;
window.openCaseModal = openCaseModal;
window.editCase = editCase;
window.saveCase = saveCase;
window.deleteCase = deleteCase;
window.showCaseDetail = showCaseDetail;
window.toggleProsecutor = toggleProsecutor;
window.toggleExecution = toggleExecution;

// Schedule
window.renderSchedule = renderSchedule;
window.debouncedRenderSchedule = debouncedRenderSchedule;
window.goToSchedulePage = goToSchedulePage;
window.togglePastSchedule = togglePastSchedule;
window.toggleCalendarView = toggleCalendarView;
window.changeMonth = changeMonth;
window.openDaySchedules = openDaySchedules;
window.openScheduleModal = openScheduleModal;
window.saveSchedule = saveSchedule;
window.toggleScheduleDone = toggleScheduleDone;
window.deleteSchedule = deleteSchedule;
window.debouncedSuggestClients = debouncedSuggestClients;
window.suggestClients = suggestClients;
window.selectClient = selectClient;
window.debouncedSearchScheduleCases = debouncedSearchScheduleCases;
window.selectCaseForSelect = selectCaseForSelect;

// Finance
window.renderFinance = renderFinance;
window.debouncedRenderFinance = debouncedRenderFinance;
window.goToFinancePage = goToFinancePage;
window.clearDateFilters = clearDateFilters;
window.openFinanceModal = openFinanceModal;
window.editFinance = editFinance;
window.saveFinance = saveFinance;
window.deleteFinance = deleteFinance;
window.debouncedSearchFinanceCases = debouncedSearchFinanceCases;

// Debtors
window.calculateDebtors = calculateDebtors;
window.renderDebtors = renderDebtors;
window.debouncedRenderDebtors = debouncedRenderDebtors;
window.goToDebtorsPage = goToDebtorsPage;

// Library
window.renderLibrary = renderLibrary;
window.debouncedRenderLibrary = debouncedRenderLibrary;
window.viewLibrary = viewLibrary;
window.openLibraryModal = openLibraryModal;
window.editLibrary = editLibrary;
window.saveLibrary = saveLibrary;
window.deleteLibrary = deleteLibrary;
window.copyLibraryContent = copyLibraryContent;

// Backup & Sync
window.downloadBackup = downloadBackup;
window.restoreBackup = restoreBackup;
window.syncAllToGoogleSheet = syncAllToGoogleSheet;
window.testGoogleSheetConnection = testGoogleSheetConnection;

// ═════════════════════════════════════════════════
// End of app.js
// ═════════════════════════════════════════════════
console.log('App.js fully loaded and ready!');