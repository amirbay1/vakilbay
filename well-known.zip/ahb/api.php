<?php
// api.php
// جلوگیری از چاپ هرگونه خطا که باعث خرابی JSON شود
error_reporting(0);
ini_set('display_errors', 0);

session_start();
header('Content-Type: application/json; charset=utf-8');

define('SECURE_ACCESS', true);
// اتصال فایل کانفیگ
$config = require 'config.php';

// تابع استاندارد ارسال پاسخ به فرمت JSON
function response($success, $msg = '', $data = []) {
    echo json_encode(['success' => (bool)$success, 'message' => $msg, 'data' => $data]);
    exit;
}

// ---------------------------------------------------------
// 1. لاگین (بدون نیاز به بررسی توکن)
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login') {
    $pass = $_POST['password'] ?? '';
    // رمز عبور (در اینجا ثابت است، می‌توانید تغییر دهید)
    if ($pass === 'admin') { 
        $_SESSION['logged_in'] = true;
        response(true, 'ورود موفقیت آمیز بود');
    }
    response(false, 'رمز عبور اشتباه است');
}

// ---------------------------------------------------------
// 2. بررسی امنیتی (آیا کاربر لاگین است؟)
// ---------------------------------------------------------
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    http_response_code(403);
    response(false, 'دسترسی غیرمجاز. لطفا مجدد وارد شوید');
}

// ---------------------------------------------------------
// 3. درخواست خروج (Logout)
// ---------------------------------------------------------
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    response(true, 'خروج انجام شد');
}

// مدیریت فایل دیتابیس
$dbFile = $config['db_path'];

// اگر فایل وجود ندارد، آن را بساز
if (!file_exists($dbFile)) {
    if(!is_dir(dirname($dbFile))) mkdir(dirname($dbFile), 0755, true);
    file_put_contents($dbFile, json_encode(['cases' => [], 'finance' => [], 'library' => []]));
}

// ---------------------------------------------------------
// 4. دریافت اطلاعات (GET)
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'get_data') {
    $content = file_get_contents($dbFile);
    $data = json_decode($content, true);
    // اگر فایل خالی بود یا جیسون خراب بود، آرایه خالی برگردان
    if (!$data) $data = ['cases' => [], 'finance' => [], 'library' => []];
    response(true, '', $data);
}

// ---------------------------------------------------------
// 5. ذخیره اطلاعات و سینک گوگل (POST)
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // دریافت دیتای خام JSON از بدنه درخواست
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (isset($input['db'])) {
        // الف) ذخیره در فایل هاست (با قفل امنیتی File Locking)
        $fp = fopen($dbFile, 'c+');
        if (flock($fp, LOCK_EX)) { // قفل انحصاری
            ftruncate($fp, 0); // پاک کردن محتوای قبلی
            fwrite($fp, json_encode($input['db'], JSON_UNESCAPED_UNICODE));
            fflush($fp);
            flock($fp, LOCK_UN); // باز کردن قفل
        } else {
            fclose($fp);
            response(false, 'Database locked, try again (تداخل در ذخیره سازی)');
        }
        fclose($fp);

        // ب) ارسال به گوگل شیت (اگر تنظیمات وجود داشته باشد)
        if (isset($input['syncItem']) && !empty($config['google']['refresh_token'])) {
            syncToGoogle($input['syncItem'], $input['syncType'], $config);
        }

        response(true, 'اطلاعات با موفقیت ذخیره شد');
    }
}

// ---------------------------------------------------------
// توابع کمکی (Google Sync)
// ---------------------------------------------------------
function syncToGoogle($item, $type, $conf) {
    // 1. دریافت Access Token جدید با استفاده از Refresh Token
    $ch = curl_init('https://oauth2.googleapis.com/token');
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        'client_id' => $conf['google']['client_id'],
        'client_secret' => $conf['google']['client_secret'],
        'refresh_token' => $conf['google']['refresh_token'],
        'grant_type' => 'refresh_token'
    ]));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $res = json_decode(curl_exec($ch), true);
    curl_close($ch);
    
    // اگر توکن دریافت نشد، ادامه نده
    if (!isset($res['access_token'])) return;
    $token = $res['access_token'];

    // 2. آماده‌سازی داده‌ها برای ارسال
    $values = [];
    $range = '';

    if($type === 'cases') {
        $range = 'Sheet1!A1:append';
        
        // تبدیل لیست روند کار به یک رشته متنی برای ذخیره در سلول اکسل
        $workflowStr = '';
        if(isset($item['workflow']) && is_array($item['workflow'])){
            foreach($item['workflow'] as $wf){
                // فرمت: [تاریخ - وضعیت: توضیح]
                $workflowStr .= "[" . ($wf['date'] ?? '-') . " - " . ($wf['status'] ?? '') . ": " . ($wf['desc'] ?? '') . "] \n";
            }
        }

        // ترتیب ستون‌ها در گوگل شیت
        $values = [[
            $item['id'],
            $item['name'],
            $item['national'],
            $item['mobile'],
            $item['birthDate'],
            $item['address'],
            $item['title'],
            $item['type'],
            $item['status'],
            $item['branch'],
            $item['opponent'],
            $item['contract'],
            $item['tags'],
            $item['notes'],
            $item['updatedAt'],
            $workflowStr // ستون جدید: روند کار
        ]];

    } elseif ($type === 'finance') {
        $range = 'Finance!A1:append';
        // برای تراکنش مالی در سرور نام پرونده را نداریم (چون فقط ID داریم)
        // پس یک placeholder می‌گذاریم یا در سمت کلاینت هندل می‌شود.
        $values = [[ 
            $item['id'], 
            $item['date'], 
            $item['caseId'], 
            'ServerSynced', 
            $item['type'], 
            $item['amount'], 
            $item['desc'] 
        ]];
    }

    // 3. ارسال به گوگل شیت
    if (!empty($values)) {
        $url = "https://sheets.googleapis.com/v4/spreadsheets/{$conf['google']['sheet_id']}/values/{$range}?valueInputOption=USER_ENTERED";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode(['values' => $values]));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json', 
            "Authorization: Bearer $token"
        ]);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_exec($ch);
        curl_close($ch);
    }
}
?>