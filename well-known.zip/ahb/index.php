<?php session_start(); define('SECURE_ACCESS', true); 
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");

// PWA Manifest
if (isset($_GET['manifest'])) {
    header('Content-Type: application/json');
    echo json_encode([
        "name" => "وکیل‌یار", "short_name" => "وکیل‌یار", "start_url" => ".", "display" => "standalone", 
        "background_color" => "#0A192F", "theme_color" => "#0A192F",
        "icons" => [["src" => "https://img.icons8.com/fluency/192/law.png", "sizes" => "192x192", "type" => "image/png"]]
    ]); exit;
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>LawOffice | دستیار هوشمند</title>
    <link rel="manifest" href="?manifest=1">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: { 'dark-navy': '#0A192F', 'gold-accent': '#D4AF37' },
                    fontFamily: { sans: ['Vazirmatn', 'sans-serif'] }
                }
            }
        }
    </script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <style>
        body { background-color: #f8fafc; overflow: hidden; height: 100vh; margin: 0; user-select: none; }
        
        /* Dark Mode */
        .dark body { background-color: #0A192F; color: #e2e8f0; }
        .dark .sidebar { background-color: #020c1b; border-left: 1px solid #233554; }
        .dark header { background-color: #0A192F; border-bottom: 1px solid #233554; }
        .dark .bg-white { background-color: #112240; border-color: #233554; }
        .dark .win-input { background-color: #112240; border-color: #233554; color: white; }
        .dark .modal-window { background-color: #112240; color: white; border: 1px solid #233554; }
        
        /* UI Elements */
        .win-input { width: 100%; background: #ffffff; border: 1px solid #d1d5db; padding: 0.7rem 1rem; border-radius: 0.75rem; outline: none; transition: 0.2s; font-size: 0.95rem; }
        .win-input:focus { border-color: #D4AF37; box-shadow: 0 0 0 3px rgba(212, 175, 55, 0.15); }
        .form-label { display: block; font-size: 0.8rem; font-weight: bold; color: #64748b; margin-bottom: 0.4rem; }
        .dark .form-label { color: #94a3b8; }

        /* Sidebar */
        .sidebar { position: fixed; top: 0; right: 0; height: 100vh; width: 260px; background: #1e293b; z-index: 40; transition: transform 0.3s ease; display: flex; flex-direction: column; box-shadow: -4px 0 15px rgba(0,0,0,0.1); }
        .sidebar.closed { transform: translateX(100%); }
        @media (min-width: 768px) { .sidebar { position: static; transform: none; } .sidebar.closed { transform: none; } }
        .sidebar-item { padding: 1rem 1.5rem; cursor: pointer; display: flex; align-items: center; gap: 0.8rem; transition: 0.2s; color: #94a3b8; border-right: 4px solid transparent; }
        .sidebar-item:hover, .sidebar-item.active { background: #0f172a; color: white; border-right-color: #D4AF37; }
        .sidebar-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.5); z-index: 30; display: none; }
        .sidebar-overlay.show { display: block; }

        /* Modals & Tables */
        .modal-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.7); z-index: 50; display: none; align-items: flex-start; justify-content: center; padding-top: 3rem; backdrop-filter: blur(4px); overflow-y: auto; padding-bottom: 4rem; }
        .modal-window { background: white; width: 95%; max-width: 600px; border-radius: 1.5rem; box-shadow: 0 25px 50px -12px rgba(0,0,0,0.35); animation: zoomIn 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275); position: relative;}
        .modal-overlay.show { display: flex; }
        @keyframes zoomIn { from{transform:scale(0.9) translateY(20px);opacity:0} to{transform:scale(1) translateY(0);opacity:1} }
        .table-container { overflow-x: auto; -webkit-overflow-scrolling: touch; }

        /* Task Specifics */
        .task-done { opacity: 0.5; background-color: #f0fdf4 !important; }
        .dark .task-done { background-color: #064e3b !important; }
        .task-done .task-title { text-decoration: line-through; }
        .search-select-dropdown { position: absolute; width: 100%; max-height: 180px; overflow-y: auto; background: white; border: 1px solid #e2e8f0; z-index: 20; display: none; box-shadow: 0 10px 15px -3px rgba(0,0,0,0.1); border-radius: 0 0 0.75rem 0.75rem; }
        .dark .search-select-dropdown { background-color: #112240; border-color: #233554; }
    </style>
</head>
<body class="text-gray-700 dark:text-gray-200 transition-colors duration-300">

<?php if(!isset($_SESSION['logged_in'])): ?>
    <div class="fixed inset-0 bg-dark-navy flex items-center justify-center z-[100]">
        <div class="bg-white/5 backdrop-blur-md border border-white/10 p-8 rounded-3xl shadow-2xl w-full max-w-sm text-center mx-4">
            <div class="w-20 h-20 bg-gold-accent rounded-full mx-auto mb-6 flex items-center justify-center text-4xl shadow-lg border-4 border-dark-navy text-dark-navy">⚖️</div>
            <h2 class="text-white text-xl font-bold mb-6">سیستم هوشمند وکالت</h2>
            <form onsubmit="doLogin(event)">
                <input type="password" id="loginPass" class="w-full px-5 py-4 rounded-xl bg-black/30 border border-white/10 text-white text-center text-lg focus:ring-2 focus:ring-gold-accent outline-none mb-4 placeholder-gray-400" placeholder="رمز عبور">
                <button type="submit" class="w-full bg-gold-accent hover:bg-yellow-500 text-dark-navy font-bold py-4 rounded-xl shadow-lg transition transform active:scale-95">ورود امن</button>
            </form>
        </div>
    </div>
    <script>async function doLogin(e){e.preventDefault();const fd=new FormData();fd.append('action','login');fd.append('password',document.getElementById('loginPass').value);try{const r=await fetch('api.php',{method:'POST',body:fd});const j=await r.json();if(j.success)location.reload();else Swal.fire('خطا',j.message,'error');}catch(e){Swal.fire('Error','Server Error','error');}}</script>
<?php else: ?>

    <div class="flex h-screen overflow-hidden relative">
        <div id="sidebarOverlay" class="sidebar-overlay md:hidden" onclick="toggleSidebar()"></div>

        <!-- Sidebar -->
        <aside id="mainSidebar" class="sidebar closed">
            <div class="h-20 flex items-center gap-3 px-6 bg-slate-900 dark:bg-black/30 text-white font-bold border-b border-gray-800 shrink-0">
                <div class="w-10 h-10 rounded-xl bg-indigo-600 dark:bg-gold-accent dark:text-dark-navy flex items-center justify-center shadow-lg"><i class="fas fa-scale-balanced text-xl"></i></div>
                <div><h1 class="text-lg tracking-tight">وکیل‌یار</h1><span class="text-[10px] text-gray-400 uppercase tracking-widest">Ultimate Edition</span></div>
            </div>
            <nav class="flex-1 py-6 space-y-2 overflow-y-auto">
                <div class="sidebar-item active" onclick="setView('dashboard', this)"><i class="fas fa-th-large w-5"></i> داشبورد</div>
                <div class="sidebar-item" onclick="setView('cases', this)"><i class="fas fa-folder-open w-5"></i> پرونده‌ها</div>
                <div class="sidebar-item" onclick="setView('schedule', this)"><i class="fas fa-calendar-check w-5 text-gold-accent"></i> تقویم کاری</div>
                <div class="sidebar-item" onclick="setView('finance', this)"><i class="fas fa-wallet w-5"></i> امور مالی</div>
                <div class="sidebar-item" onclick="setView('library', this)"><i class="fas fa-book-reader w-5"></i> بانک لوایح</div>
                <div class="mt-8 px-6 text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">سیستم</div>
                <div class="sidebar-item text-red-400 hover:text-red-300" onclick="logout()"><i class="fas fa-power-off w-5"></i> خروج امن</div>
            </nav>
        </aside>

        <!-- Content -->
        <main class="flex-1 flex flex-col bg-gray-50 dark:bg-dark-navy overflow-hidden w-full transition-colors duration-300">
            <header class="h-16 flex items-center justify-between px-4 md:px-8 shadow-sm z-10 shrink-0 bg-white dark:bg-dark-navy dark:border-b dark:border-gray-800">
                <div class="flex items-center gap-4">
                    <button onclick="toggleSidebar()" class="md:hidden text-gray-500 dark:text-gray-300 p-2"><i class="fas fa-bars text-xl"></i></button>
                    <h2 id="pgTitle" class="font-bold text-gray-800 dark:text-white text-lg">داشبورد</h2>
                </div>
                <div class="flex items-center gap-4">
                    <button onclick="toggleTheme()" class="w-10 h-10 rounded-full bg-gray-100 dark:bg-white/10 flex items-center justify-center text-blue-600 dark:text-gold-accent hover:bg-gray-200 transition"><i class="fas fa-moon"></i></button>
                    <div class="hidden md:flex flex-col items-end">
                        <span id="headerDate" class="text-xs font-bold text-gray-500 dark:text-gray-400">---</span>
                        <div class="flex items-center gap-1.5"><span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> <span class="text-[10px] font-bold text-emerald-600 dark:text-emerald-400">آنلاین</span></div>
                    </div>
                </div>
            </header>
            
            <div id="content-body" class="flex-1 overflow-y-auto p-4 md:p-6 relative text-gray-800 dark:text-gray-200">
                
                <!-- 1. DASHBOARD -->
                <div id="view-dashboard" class="page-view">
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
                         <div class="bg-white dark:bg-white/5 p-6 rounded-2xl shadow-sm border-r-4 border-r-indigo-500 dark:border-r-indigo-400 flex justify-between items-center transform hover:-translate-y-1 transition">
                             <div><div class="text-xs text-gray-400 font-bold mb-1 uppercase tracking-wide">پرونده‌های جاری</div><div id="d-cases" class="text-4xl font-black text-gray-800 dark:text-white mt-2">0</div></div>
                             <div class="w-14 h-14 bg-indigo-50 dark:bg-indigo-900/20 text-indigo-500 dark:text-indigo-400 rounded-2xl flex items-center justify-center text-2xl"><i class="fas fa-folder"></i></div>
                         </div>
                         <div class="bg-white dark:bg-white/5 p-6 rounded-2xl shadow-sm border-r-4 border-r-slate-500 dark:border-r-gold-accent flex justify-between items-center transform hover:-translate-y-1 transition">
                             <div><div class="text-xs text-gray-400 font-bold mb-1 uppercase tracking-wide">برنامه امروز</div><div id="d-today" class="text-4xl font-black text-slate-700 dark:text-gold-accent mt-2">0</div></div>
                             <div class="w-14 h-14 bg-slate-100 dark:bg-gold-accent/10 text-slate-600 dark:text-gold-accent rounded-2xl flex items-center justify-center text-2xl"><i class="fas fa-calendar-day"></i></div>
                         </div>
                         <div class="bg-white dark:bg-white/5 p-6 rounded-2xl shadow-sm border-r-4 border-r-emerald-500 flex justify-between items-center transform hover:-translate-y-1 transition">
                             <div><div class="text-xs text-gray-400 font-bold mb-1 uppercase tracking-wide">تراز مالی</div><div id="d-finance" class="text-xl font-black text-emerald-600 dark:text-emerald-400 font-mono mt-2" dir="ltr">0</div></div>
                             <div class="w-14 h-14 bg-emerald-50 dark:bg-emerald-900/20 text-emerald-500 rounded-2xl flex items-center justify-center text-2xl"><i class="fas fa-coins"></i></div>
                         </div>
                    </div>

                    <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div class="lg:col-span-2 bg-white dark:bg-white/5 rounded-2xl border dark:border-gray-800 shadow-sm p-6">
                            <div class="flex justify-between items-center mb-6"><h3 class="font-bold flex items-center gap-2"><i class="fas fa-history text-gray-400"></i> آخرین پرونده‌ها</h3><button onclick="setView('cases')" class="text-xs bg-gray-100 dark:bg-white/10 px-3 py-1 rounded font-bold hover:bg-gray-200">مشاهده همه</button></div>
                            <div class="overflow-x-auto"><table class="w-full text-sm text-right"><tbody id="dash-recent-cases" class="divide-y divide-gray-100 dark:divide-gray-800"></tbody></table></div>
                        </div>
                        <div class="bg-white dark:bg-white/5 rounded-2xl border dark:border-gray-800 shadow-sm p-6">
                            <h3 class="font-bold mb-6 flex items-center gap-2"><i class="fas fa-bell text-gold-accent"></i> برنامه‌های فوری</h3>
                            <div id="dash-sched-list" class="space-y-3"></div>
                        </div>
                        <div class="lg:col-span-3 bg-white dark:bg-white/5 rounded-2xl border dark:border-gray-800 shadow-sm p-6">
                             <h3 class="font-bold mb-4 flex items-center gap-2"><i class="fas fa-receipt text-emerald-500"></i> تراکنش‌های اخیر</h3>
                             <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4" id="dash-fin-list"></div>
                        </div>
                    </div>
                </div>

                <!-- 2. CASES (Original) -->
                <div id="view-cases" class="page-view hidden h-full flex flex-col">
                    <div class="bg-white dark:bg-white/5 rounded-2xl shadow border border-gray-200 dark:border-gray-800 h-full flex flex-col overflow-hidden">
                        <div class="p-5 border-b border-gray-100 dark:border-gray-800 flex flex-col md:flex-row justify-between items-center gap-3">
                            <div class="relative w-full md:w-auto"><i class="fas fa-search absolute right-3 top-3.5 text-gray-400"></i><input id="searchCase" onkeyup="renderCases()" placeholder="جستجو (نام، شماره، عنوان...)" class="win-input pr-10 md:w-80 border-gray-300"></div>
                            <button onclick="openModal('caseModal')" class="bg-indigo-600 dark:bg-gold-accent dark:text-dark-navy text-white px-5 py-3 rounded-xl shadow-lg border border-transparent font-bold flex items-center gap-2 hover:scale-105 transition"><i class="fas fa-plus"></i> پرونده جدید</button>
                        </div>
                        <div class="flex-1 overflow-auto table-container">
                            <table class="w-full text-right p-2 whitespace-nowrap">
                                <thead class="bg-gray-50 dark:bg-white/5 text-gray-500 dark:text-gray-400 border-b dark:border-gray-800 font-bold text-xs uppercase"><tr><th class="p-4">#</th><th>موکل</th><th>عنوان</th><th>وضعیت</th><th class="text-center">مدیریت</th></tr></thead>
                                <tbody id="tbody-cases" class="divide-y divide-gray-100 dark:divide-gray-800"></tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- 3. SCHEDULE (Redesigned & Fixed) -->
                <div id="view-schedule" class="page-view hidden h-full pb-24">
                    <button onclick="openSchModal()" class="fixed bottom-8 left-8 w-16 h-16 bg-blue-600 dark:bg-gold-accent text-white dark:text-dark-navy rounded-full shadow-2xl flex items-center justify-center text-3xl z-30 transition transform hover:scale-110 active:scale-95 shadow-blue-500/40 dark:shadow-black/50"><i class="fas fa-plus"></i></button>
                    
                    <div class="max-w-2xl mx-auto">
                        <div class="flex flex-col gap-4 mb-6">
                            <div class="flex items-center justify-between">
                                <h2 class="text-lg font-bold flex items-center gap-2"><i class="fas fa-calendar-check text-blue-600 dark:text-gold-accent"></i> برنامه جاری و آینده</h2>
                                <span id="sch-count" class="text-xs bg-blue-100 dark:bg-gold-accent/20 text-blue-800 dark:text-gold-accent px-3 py-1 rounded-full font-bold">0</span>
                            </div>
                            <div class="relative">
                                <input id="schSearch" onkeyup="renderSmartSchedule()" placeholder="جستجو در برنامه‌ها (نام، تاریخ یا توضیحات...)" class="win-input pl-10 bg-transparent border-gray-300 dark:border-gray-700">
                                <i class="fas fa-search absolute left-3 top-3.5 text-gray-400"></i>
                            </div>
                        </div>

                        <div id="schedule-list" class="space-y-2"></div>

                        <div class="pt-8 border-t border-gray-200 dark:border-gray-700 mt-10">
                            <button onclick="document.getElementById('archiveList').classList.toggle('hidden')" class="w-full py-4 bg-gray-100 dark:bg-white/5 text-gray-500 dark:text-gray-400 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-gray-200 dark:hover:bg-white/10 transition"><i class="fas fa-box-archive"></i> مشاهده بایگانی گذشته</button>
                            <div id="archiveList" class="hidden mt-6 space-y-4 opacity-75 grayscale hover:grayscale-0 transition duration-500"></div>
                        </div>
                    </div>
                </div>

                <!-- 4. FINANCE (With Edit) -->
                <div id="view-finance" class="page-view hidden">
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="font-bold text-lg text-gray-700 dark:text-gray-200">مدیریت مالی</h3>
                        <button onclick="openFinModal()" class="bg-emerald-600 dark:bg-emerald-500 text-white px-6 py-2.5 rounded-xl shadow-lg border border-transparent font-bold hover:scale-105 transition flex gap-2 items-center"><i class="fas fa-plus"></i> تراکنش جدید</button>
                    </div>
                    <div class="bg-white dark:bg-white/5 rounded-2xl shadow border border-gray-200 dark:border-gray-800 overflow-hidden">
                        <table class="w-full text-right"><thead class="bg-gray-50 dark:bg-white/5 border-b dark:border-gray-800"><tr><th class="p-4">تاریخ</th><th>پرونده</th><th>نوع</th><th>مبلغ</th><th>توضیحات</th><th class="text-center">عملیات</th></tr></thead><tbody id="tbody-finance" class="divide-y divide-gray-100 dark:divide-gray-800"></tbody></table>
                    </div>
                </div>

                <!-- 5. LIBRARY (View Mode / Edit Mode) -->
                <div id="view-library" class="page-view hidden h-full">
                    <div class="flex flex-col md:flex-row gap-6 h-full">
                        <div class="w-full md:w-1/3 bg-white dark:bg-white/5 rounded-2xl border border-gray-200 dark:border-gray-800 flex flex-col shadow-sm h-[40vh] md:h-full">
                             <div class="p-4 border-b dark:border-gray-800">
                                 <button onclick="newLib()" class="w-full bg-indigo-50 dark:bg-white/10 text-indigo-700 dark:text-gold-accent py-3 rounded-xl font-bold mb-3 border border-indigo-100 dark:border-transparent transition hover:bg-indigo-100 dark:hover:bg-white/20"><i class="fas fa-plus"></i> متن جدید</button>
                                 <div class="relative"><i class="fas fa-search absolute left-3 top-3.5 text-gray-400"></i><input id="searchLib" onkeyup="renderLib()" placeholder="جستجو..." class="win-input m-0 pl-10"></div>
                             </div>
                             <div id="lib-list" class="flex-1 overflow-y-auto p-2 space-y-2 custom-scrollbar"></div>
                        </div>
                        <div class="w-full md:w-2/3 bg-white dark:bg-white/5 rounded-2xl border border-gray-200 dark:border-gray-800 p-6 flex flex-col shadow-sm flex-1 relative">
                            <!-- Editor (Hidden by default) -->
                            <div id="libEditorArea" class="flex flex-col h-full hidden">
                                <input type="hidden" id="libId">
                                <div class="flex gap-3 mb-4"><input id="libTitle" placeholder="عنوان..." class="flex-1 text-xl font-bold bg-transparent border-b outline-none dark:text-white dark:border-gray-700 pb-2"><select id="libType" class="win-input w-40"><option>لایحه</option><option>دادخواست</option><option>قرارداد</option><option>اظهارنامه</option><option>سایر</option></select></div>
                                <textarea id="libText" class="flex-1 w-full bg-gray-50 dark:bg-black/30 p-4 rounded-xl border border-gray-200 dark:border-gray-700 outline-none resize-none font-mono leading-7 text-sm" placeholder="متن حقوقی..."></textarea>
                                <div class="mt-4 flex justify-end gap-3"><button onclick="newLib()" class="text-gray-400 hover:text-gray-600 font-bold px-4">انصراف</button><button onclick="saveLib()" class="bg-indigo-600 dark:bg-gold-accent dark:text-dark-navy text-white px-8 py-2.5 rounded-xl font-bold shadow-lg hover:-translate-y-0.5 transition">ذخیره تغییرات</button></div>
                            </div>
                            <!-- View Overlay (Default) -->
                            <div id="libViewOverlay" class="absolute inset-0 z-10 flex flex-col p-8 items-center justify-center text-center">
                                <div class="text-gray-300 dark:text-gray-600 mb-4"><i class="fas fa-book-open text-6xl"></i></div>
                                <p class="text-gray-400 font-bold">متنی را از لیست انتخاب کنید یا جدید بسازید</p>
                            </div>
                            <!-- Content Viewer -->
                            <div id="libContentArea" class="absolute inset-0 bg-white dark:bg-[#112240] z-20 flex flex-col p-6 hidden rounded-2xl">
                                <div class="flex justify-between items-start mb-6 border-b pb-4 dark:border-gray-700">
                                    <h2 id="viewLibTitle" class="text-2xl font-black text-slate-800 dark:text-white"></h2>
                                    <div class="flex gap-2">
                                        <button onclick="copyLibText()" class="text-gray-500 hover:text-indigo-600 dark:text-gray-400 dark:hover:text-gold-accent p-2 rounded-lg border dark:border-gray-700" title="کپی"><i class="fas fa-copy"></i></button>
                                        <button onclick="editLibMode()" class="bg-indigo-50 text-indigo-700 dark:bg-white/10 dark:text-white px-4 py-1.5 rounded-lg text-sm font-bold hover:bg-indigo-100">ویرایش</button>
                                        <button onclick="delLib()" class="text-red-400 hover:text-red-600 p-2"><i class="fas fa-trash"></i></button>
                                    </div>
                                </div>
                                <div class="flex-1 overflow-y-auto bg-slate-50 dark:bg-black/20 p-5 rounded-xl border border-gray-100 dark:border-gray-700 text-justify leading-8 whitespace-pre-wrap text-sm font-light text-slate-700 dark:text-gray-300" id="viewLibContent"></div>
                                <button onclick="newLib()" class="mt-4 text-xs text-gray-400 hover:text-gray-600 self-end">بستن</button>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <!-- MODALS -->
    
    <!-- Advanced Schedule Modal (With Search & Logic) -->
    <div id="schModal" class="modal-overlay">
        <div class="modal-window max-w-lg">
            <div class="flex justify-between items-center mb-6 p-6 pb-0">
                <h3 class="text-xl font-bold text-slate-800 dark:text-white flex items-center gap-2"><i class="fas fa-calendar-plus text-blue-600 dark:text-gold-accent"></i> <span id="schModalTitle">برنامه جدید</span></h3>
                <button onclick="closeModal('schModal')" class="w-8 h-8 rounded-full bg-gray-100 dark:bg-white/10 flex items-center justify-center text-gray-500 dark:text-white hover:bg-red-500 hover:text-white transition">&times;</button>
            </div>
            <form id="schForm" onsubmit="saveSchedule(event)" class="p-6 space-y-5">
                <input type="hidden" id="sIdx">
                
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 block">تاریخ</label>
                        <input id="sDate" class="win-input text-center font-bold tracking-wider" placeholder="1403/01/01" required>
                    </div>
                    <div>
                        <label class="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 block">ساعت</label>
                        <input type="time" id="sTime" class="win-input text-center font-bold" required>
                    </div>
                </div>

                <div class="relative">
                    <label class="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 block">موکل / طرف حساب</label>
                    <input id="sClient" class="win-input pr-10" placeholder="نام را تایپ کنید..." autocomplete="off" onkeyup="suggestClients(this)">
                    <i class="fas fa-user absolute right-3 top-9 text-gray-400"></i>
                    <div id="clientSuggestions" class="search-select-dropdown w-full absolute top-full left-0 z-50 rounded-lg shadow-xl hidden"></div>
                </div>

                <div>
                    <label class="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1.5 block">شرح کار</label>
                    <textarea id="sDesc" rows="2" class="win-input resize-none" placeholder="توضیحات کامل..."></textarea>
                </div>

                <div class="pt-4 border-t border-gray-100 dark:border-gray-700">
                    <label class="text-xs font-bold text-emerald-600 mb-1.5 block flex items-center gap-1"><i class="fas fa-check-double"></i> نتیجه (اختیاری)</label>
                    <textarea id="sResult" rows="1" class="win-input bg-emerald-50 dark:bg-emerald-900/10 border-emerald-100 dark:border-emerald-900/30 dark:text-white" placeholder="نتیجه نهایی چه شد؟"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4 pt-2">
                    <select id="sLabel" class="win-input cursor-pointer">
                        <option value="">برچسب (عادی)</option><option value="جلسه">🔵 جلسه</option><option value="دادگاه">🔴 دادگاه</option><option value="تنظیم">🟣 تنظیم</option><option value="پیگیری">🟠 پیگیری</option>
                    </select>
                    <button type="submit" class="w-full bg-blue-600 dark:bg-gold-accent dark:text-dark-navy text-white rounded-xl font-bold shadow-lg hover:shadow-xl transition transform active:scale-95">ذخیره برنامه</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Case Modal -->
    <div id="caseModal" class="modal-overlay"><div class="modal-window"><div class="bg-gray-900 dark:bg-black/40 text-white px-6 py-4 flex justify-between items-center rounded-t-2xl"><h3 class="font-bold text-lg"><span id="modal-title">پرونده جدید</span></h3><button onclick="closeModal('caseModal')"><i class="fas fa-times text-xl"></i></button></div><form id="caseForm" onsubmit="saveCase(event)" class="p-6 md:p-8 max-h-[85vh] overflow-y-auto custom-scrollbar"><input type="hidden" id="cIdx"><div class="grid grid-cols-1 md:grid-cols-3 gap-5"><div class="md:col-span-3 text-indigo-600 dark:text-gold-accent font-bold text-sm border-b dark:border-gray-700 pb-2 mb-2 flex items-center gap-2"><i class="fas fa-user"></i> اطلاعات موکل</div><div><label class="form-label">نام و نام خانوادگی *</label><input id="cName" class="win-input" required></div><div><label class="form-label">تماس *</label><input id="cMobile" class="win-input font-mono dir-ltr" required></div><div><label class="form-label">کد ملی</label><input id="cNational" class="win-input font-mono dir-ltr"></div><div><label class="form-label">تاریخ تولد</label><input id="cBirth" class="win-input text-center"></div><div class="md:col-span-2"><label class="form-label">آدرس</label><input id="cAddress" class="win-input"></div><div class="md:col-span-3 text-indigo-600 dark:text-gold-accent font-bold text-sm border-b dark:border-gray-700 pb-2 mb-2 mt-4 flex items-center gap-2"><i class="fas fa-folder-open"></i> مشخصات پرونده</div><div><label class="form-label">عنوان *</label><input id="cTitle" class="win-input" required></div><div><label class="form-label">نوع</label><select id="cType" class="win-input cursor-pointer"><option>حقوقی</option><option>کیفری</option><option>خانواده</option><option>ملکی</option><option>ثبتی</option></select></div><div><label class="form-label">وضعیت</label><select id="cStatus" class="win-input cursor-pointer"><option>جاری</option><option>مختومه</option></select></div><div><label class="form-label">شعبه</label><input id="cBranch" class="win-input"></div><div><label class="form-label">طرف دعوی</label><input id="cOpponent" class="win-input"></div><div><label class="form-label">شماره قرارداد</label><input id="cContract" class="win-input font-mono dir-ltr"></div><div class="md:col-span-3 mt-2"><label class="form-label">تگ‌ها</label><input id="cTags" class="win-input"></div><div class="md:col-span-3"><label class="form-label">یادداشت</label><textarea id="cNotes" class="win-input" rows="2"></textarea></div></div><div class="mt-8 flex justify-end gap-3 pt-6 border-t dark:border-gray-700"><button type="button" onclick="closeModal('caseModal')" class="bg-gray-100 dark:bg-white/10 px-6 py-3 rounded-xl font-bold text-gray-500 dark:text-gray-300 hover:bg-gray-200">انصراف</button><button type="submit" class="bg-indigo-600 dark:bg-gold-accent dark:text-dark-navy text-white px-8 py-3 rounded-xl font-bold shadow-lg hover:-translate-y-0.5 transition">ثبت و ذخیره</button></div></form></div></div>

    <!-- Quick View -->
    <div id="quickViewModal" class="modal-overlay"><div class="modal-window max-w-3xl overflow-hidden pb-6"><div class="bg-gray-800 dark:bg-black/40 text-white p-5 flex justify-between items-center"><h3 class="font-bold text-lg">جزئیات پرونده</h3><button onclick="closeModal('quickViewModal')"><i class="fas fa-times text-xl"></i></button></div><div class="p-8 text-gray-700 dark:text-gray-300"><div class="grid grid-cols-2 md:grid-cols-4 gap-6 mb-8 border-b dark:border-gray-700 pb-8"><div class="col-span-2 md:col-span-1"><span class="text-xs text-gray-400 block mb-1">موکل</span><span id="qv-name" class="font-black text-xl"></span></div><div><span class="text-xs text-gray-400 block mb-1">تماس</span><span id="qv-mobile" class="font-mono text-lg"></span></div><div><span class="text-xs text-gray-400 block mb-1">کد ملی</span><span id="qv-national" class="font-mono"></span></div><div><span class="text-xs text-gray-400 block mb-1">تولد</span><span id="qv-birth" class="font-mono"></span></div><div class="col-span-2 md:col-span-1"><span class="text-xs text-gray-400 block mb-1">عنوان پرونده</span><span id="qv-title" class="font-bold text-indigo-600 dark:text-gold-accent text-lg"></span></div><div><span class="text-xs text-gray-400 block mb-1">نوع</span><span id="qv-type"></span></div><div><span class="text-xs text-gray-400 block mb-1">شعبه</span><span id="qv-branch"></span></div><div><span class="text-xs text-gray-400 block mb-1">کد قرارداد</span><span id="qv-contract" class="font-mono bg-amber-100 dark:bg-amber-900/30 text-amber-800 dark:text-amber-200 px-2 rounded"></span></div><div class="col-span-2"><span class="text-xs text-gray-400 block mb-1">طرف دعوی</span><span id="qv-opponent"></span></div><div class="col-span-2"><span class="text-xs text-gray-400 block mb-1">آدرس</span><span id="qv-address" class="text-sm"></span></div></div><div class="bg-gray-50 dark:bg-white/5 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 mb-6 flex justify-between items-center"><div class="flex flex-col"><span class="text-sm font-bold opacity-70">تراز مالی کل</span><span id="qv-total-balance" class="text-2xl font-black font-mono tracking-tight" dir="ltr">0</span></div><div class="text-right text-sm space-y-1"><div><span class="text-gray-400">دریافت:</span> <span id="qv-total-inc" class="font-mono font-bold text-emerald-500">0</span></div><div><span class="text-gray-400">هزینه:</span> <span id="qv-total-exp" class="font-mono font-bold text-rose-500">0</span></div></div></div><h4 class="font-bold text-sm mb-2 text-gray-500">یادداشت‌های پرونده</h4><p id="qv-notes" class="text-sm bg-yellow-50 dark:text-black dark:bg-gold-accent/80 p-4 rounded-xl border border-yellow-100 min-h-[60px]"></p></div></div></div>

    <!-- Finance Modal -->
    <div id="finModal" class="modal-overlay"><div class="modal-window max-w-md bg-white dark:bg-dark-navy"><div class="bg-emerald-700 text-white p-5 flex justify-between items-center rounded-t-2xl"><h3 class="font-bold text-lg">تراکنش مالی</h3><button onclick="closeModal('finModal')"><i class="fas fa-times text-xl"></i></button></div><form id="finForm" onsubmit="saveFin(event)" class="p-6 space-y-5"><input type="hidden" id="fIdx"><div class="relative"><label class="form-label">جستجوی پرونده *</label><input type="hidden" id="fCaseId"><input type="text" id="fCaseSearch" class="win-input font-bold" placeholder="تایپ کنید..." onkeyup="filterCasesSelect()" onfocus="filterCasesSelect()"><div id="caseDropdown" class="search-select-dropdown absolute bg-white dark:bg-dark-navy border w-full max-h-40 overflow-y-auto hidden z-20 rounded-b-lg shadow-xl"></div></div><div class="grid grid-cols-2 gap-3"><div><label class="form-label">نوع</label><select id="fType" class="win-input"><option value="income">دریافت (+)</option><option value="expense">هزینه (-)</option></select></div><div><label class="form-label">تاریخ</label><input id="fDate" class="win-input text-center"></div></div><div><label class="form-label">مبلغ (تومان)</label><input type="number" id="fAmnt" class="win-input text-center text-xl font-black tracking-widest" required></div><div><label class="form-label">توضیحات</label><input id="fDesc" class="win-input"></div><button type="submit" class="w-full bg-emerald-600 text-white py-3.5 rounded-xl font-bold shadow-lg hover:shadow-xl transition mt-2">ثبت نهایی</button></form></div></div>

    <script>
        let db = {cases:[], finance:[], library:[], schedule:[]};
        
        window.onload = async () => {
           const today = new Date().toLocaleDateString('fa-IR');
           if(document.getElementById('fDate')) document.getElementById('fDate').value = today;
           if(document.getElementById('sDate')) document.getElementById('sDate').value = today;
           document.getElementById('headerDate').innerText = new Date().toLocaleDateString('fa-IR', {weekday:'long', day:'numeric', month:'long'});
           
           await loadData();
           if(localStorage.getItem('theme') === 'dark') document.documentElement.classList.add('dark');
           
           // Close Dropdowns on Click Outside
           document.addEventListener('click', (e) => { 
               if (!e.target.closest('#caseDropdown') && e.target.id !== 'fCaseSearch') document.getElementById('caseDropdown').style.display = 'none';
               if (!e.target.closest('#clientSuggestions') && e.target.id !== 'sClient') document.getElementById('clientSuggestions').style.display = 'none';
           });
        };

        function toggleTheme() { document.documentElement.classList.toggle('dark'); localStorage.setItem('theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light'); }
        function toggleSidebar(){ document.querySelector('#mainSidebar').classList.toggle('closed'); document.querySelector('#sidebarOverlay').classList.toggle('show'); }

        async function loadData(){
            try {
                const res = await fetch('api.php?action=get_data');
                const j = await res.json();
                if(j.success) { db = j.data; if(!db.schedule) db.schedule=[]; refreshUI(); }
            } catch(e) { console.error(e); }
        }

        async function syncSave(item, type){ await fetch('api.php', { method: 'POST', body: JSON.stringify({ db: db, syncItem: item, syncType: type }) }); }
        function refreshUI(){ renderCases(); renderFinanceUI(); renderLib(); renderSmartSchedule(); updateDash(); }

        // --- DASHBOARD ---
        function updateDash(){ 
            document.getElementById('d-cases').innerText = db.cases.filter(x=>x.status=='جاری').length;
            const sum = db.finance.reduce((a,b)=>a+(b.type=='income'?+b.amount:-b.amount),0); document.getElementById('d-finance').innerText=sum.toLocaleString();
            
            // Recent Cases (List)
            const rc = db.cases.slice(0, 5);
            const rcHtml = rc.map(c => `<tr class="border-b dark:border-gray-800 last:border-0"><td class="p-3 font-bold text-gray-700 dark:text-gray-300">${c.name}</td><td class="p-3 text-xs text-gray-500">${c.title}</td><td class="p-3 text-xs font-mono text-gray-400">${c.updatedAt}</td></tr>`).join('');
            document.getElementById('dash-recent-cases').innerHTML = rcHtml || '<tr><td class="p-4 text-center text-gray-400">موردی نیست</td></tr>';

            // Upcoming Schedule (List)
            const today = new Date().toLocaleDateString('fa-IR');
            const upc = db.schedule.filter(s=>s.date >= today && !s.is_done).sort((a,b)=>a.date.localeCompare(b.date)).slice(0,4);
            const scHtml = upc.map(s => `
                <div class="flex justify-between items-center text-sm bg-gray-50 dark:bg-white/5 p-3 rounded-xl border border-gray-100 dark:border-gray-800">
                    <div class="flex flex-col"><span class="font-bold text-gray-700 dark:text-white">${s.client}</span><span class="text-[10px] text-gray-400">${s.label}</span></div>
                    <div class="flex flex-col items-end"><span class="font-bold text-indigo-500 font-mono">${s.date.split('/')[1]}/${s.date.split('/')[2]}</span><span class="text-xs font-mono text-gray-400">${s.time}</span></div>
                </div>`).join('');
            document.getElementById('dash-sched-list').innerHTML = scHtml || '<div class="text-center text-gray-400 text-sm py-4">برنامه‌ای نیست</div>';
            document.getElementById('d-today').innerText = db.schedule.filter(s=>s.date===today).length;

            // Finance (Cards)
            const rf = db.finance.slice(0, 4);
            const rfHtml = rf.map(f => `<div class="p-4 rounded-2xl border dark:border-gray-800 ${f.type=='income'?'bg-emerald-50 dark:bg-emerald-900/10 border-emerald-100 dark:border-emerald-900/30':'bg-rose-50 dark:bg-rose-900/10 border-rose-100 dark:border-rose-900/30'} flex flex-col justify-between h-24"> <div class="flex justify-between text-xs opacity-70 font-bold mb-1"><span>${f.type=='income'?'دریافت':'هزینه'}</span><span class="font-mono">${f.date}</span></div> <div class="font-black font-mono text-lg ${f.type=='income'?'text-emerald-700 dark:text-emerald-400':'text-rose-700 dark:text-rose-400'}">${parseInt(f.amount).toLocaleString()}</div> </div>`).join('');
            document.getElementById('dash-fin-list').innerHTML = rfHtml;
        }

        // --- SCHEDULE (Intelligent) ---
        function renderSmartSchedule() {
            const list = document.getElementById('schedule-list'); const archive = document.getElementById('archiveList');
            if(!list || !archive) return; list.innerHTML=''; archive.innerHTML='';
            
            const q = document.getElementById('schSearch') ? document.getElementById('schSearch').value.toLowerCase() : '';
            const today = new Date().toLocaleDateString('fa-IR');
            const sorted = [...db.schedule].sort((a,b) => (a.date + a.time).localeCompare(b.date + b.time));
            let upcomingCount = 0; let groupDate = '';

            sorted.forEach((item, idx) => {
                if(q && !item.client.toLowerCase().includes(q) && !item.desc.toLowerCase().includes(q)) return;
                
                const isPast = item.date < today;
                const container = isPast ? archive : list;
                if(!isPast) upcomingCount++;

                // Days Calc
                let daysText='', daysColor='bg-gray-100 text-gray-500';
                if(item.date===today) { daysText='امروز'; daysColor='bg-red-100 text-red-600 dark:bg-red-900/30 dark:text-red-400'; }
                else if(item.date > today) { 
                    // Simple logic for "Tomorrow"
                    // Real diff calc is complex without libs in Jalali, assuming sorted is enough text:
                    daysText='آینده'; daysColor='bg-blue-100 text-blue-600 dark:bg-blue-900/30 dark:text-blue-400'; 
                } else { daysText='گذشته'; }

                // Group Header
                let header = '';
                if(groupDate !== item.date && !q) {
                    const wd = getDayNameValue(item.date); // Helper below
                    header = `<div class="flex items-center gap-3 mb-3 mt-6 px-1"><span class="font-black text-xl dark:text-white tracking-tight">${item.date}</span><span class="text-sm text-gray-400 font-normal">(${wd})</span><span class="text-[10px] font-bold px-2 py-0.5 rounded ${daysColor}">${daysText}</span></div>`;
                    groupDate = item.date;
                }

                const gLink = createGoogleLink(item.date, item.time, `وکالت: ${item.client} (${item.label})`, `${item.desc}\nنتیجه: ${item.result||''}`);
                const doneCls = item.is_done ? 'task-done' : '';
                const checked = item.is_done ? 'checked' : '';

                container.insertAdjacentHTML('beforeend', `
                ${header}
                <div class="bg-white dark:bg-dark-navy rounded-2xl p-5 shadow-sm border border-gray-200 dark:border-gray-800 flex gap-4 transition-all ${doneCls} mb-3 group hover:border-blue-400 dark:hover:border-gold-accent relative overflow-hidden">
                    <div class="w-1 absolute left-0 top-0 bottom-0 ${item.is_done?'bg-green-500':'bg-blue-500 dark:bg-gold-accent'}"></div>
                    <label class="checkbox-wrapper cursor-pointer mt-1 pt-1 z-10"><input type="checkbox" class="hidden" onchange="toggleSchDone(${idx})" ${checked}><div class="w-6 h-6 border-2 border-gray-300 dark:border-gray-600 rounded-full flex items-center justify-center transition-colors bg-transparent"><i class="fa-solid fa-check text-white text-xs hidden"></i></div></label>
                    <div class="flex-1 min-w-0 cursor-pointer z-10" onclick="editSch(${idx})">
                        <div class="flex justify-between items-start mb-2"><h3 class="font-bold text-slate-800 dark:text-white task-title text-base line-clamp-1">${item.client || 'بدون نام'}</h3><span class="font-mono text-xs font-bold text-blue-700 bg-blue-50 dark:bg-blue-900/50 dark:text-blue-200 px-2 py-1 rounded-lg">${item.time}</span></div>
                        <p class="text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-3 line-clamp-2">${item.desc}</p>
                        <div class="flex flex-wrap gap-2 items-center">${item.label ? `<span class="text-[10px] px-2 py-1 rounded bg-gray-100 dark:bg-white/10 text-gray-500 dark:text-gray-300 border dark:border-gray-700 font-bold"><i class="fas fa-tag mr-1"></i>${item.label}</span>` : ''} ${item.result?`<div class="text-xs bg-emerald-50 text-emerald-700 px-2 py-1 rounded border border-emerald-100 flex items-center gap-1"><i class="fas fa-check-double"></i> ${item.result}</div>`:''}</div>
                    </div>
                    <div class="flex flex-col gap-1 items-center justify-start pt-1 z-10">
                        <a href="${gLink}" target="_blank" class="text-gray-300 hover:text-orange-500 p-1.5" title="Google Cal"><i class="fa-brands fa-google text-lg"></i></a>
                        <button onclick="delSch(${idx})" class="text-gray-300 hover:text-red-500 p-1.5"><i class="fa-solid fa-trash"></i></button>
                    </div>
                </div>`);
            });
            if(document.getElementById('sch-count')) document.getElementById('sch-count').innerText = upcomingCount;
        }

        // Suggest Clients
        function suggestClients(input) {
            const val = input.value.toLowerCase(); const box = document.getElementById('clientSuggestions'); box.innerHTML='';
            if(val.length < 1) { box.style.display='none'; return; }
            // Get clients from existing cases
            const uniqueClients = [...new Set(db.cases.map(c => c.name))];
            const matches = uniqueClients.filter(n => n.toLowerCase().includes(val));
            if(matches.length > 0) {
                box.style.display='block';
                matches.forEach(name => {
                    box.innerHTML += `<div class="p-3 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-white/10 cursor-pointer font-bold text-sm" onclick="setSchClient('${name}')">${name}</div>`;
                });
            } else box.style.display='none';
        }
        function setSchClient(name){ document.getElementById('sClient').value = name; document.getElementById('clientSuggestions').style.display='none'; }

        // --- Standard Logic ---
        function getDayNameValue(dateStr){ const names=['یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنج‌شنبه','جمعه','شنبه']; try{ const p=dateStr.split('/'); const g=jalaliToGregorian(parseInt(p[0]),parseInt(p[1]),parseInt(p[2])); const d=new Date(g[0],g[1]-1,g[2]); return names[d.getDay()]; } catch(e){return '';} }
        function openSchModal(){ document.getElementById('schForm').reset(); document.getElementById('sIdx').value=''; document.getElementById('schModalTitle').innerText="برنامه جدید"; openModal('schModal'); }
        function editSch(sortIdx) {
            const sorted=[...db.schedule].sort((a,b) => (a.date+a.time).localeCompare(b.date+b.time)); const item=sorted[sortIdx]; const realIdx=db.schedule.indexOf(item);
            document.getElementById('schModalTitle').innerText = "ویرایش برنامه";
            document.getElementById('sIdx').value = realIdx; document.getElementById('sDate').value = item.date;
            document.getElementById('sTime').value = item.time; document.getElementById('sClient').value = item.client;
            document.getElementById('sLabel').value = item.label; document.getElementById('sDesc').value = item.desc;
            document.getElementById('sResult').value = item.result || ''; openModal('schModal');
        }
        async function saveSchedule(e){
            e.preventDefault(); const idx=document.getElementById('sIdx').value; const item={date:document.getElementById('sDate').value, time:document.getElementById('sTime').value, client:document.getElementById('sClient').value, label:document.getElementById('sLabel').value, desc:document.getElementById('sDesc').value, result:document.getElementById('sResult').value, is_done:idx!==""?db.schedule[idx].is_done:false};
            if(idx!=="")db.schedule[idx]=item;else db.schedule.push(item); closeModal('schModal'); refreshUI(); await syncSave(item,'schedule');
        }
        async function toggleSchDone(sortIdx){ const sorted=[...db.schedule].sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)); const realIdx=db.schedule.indexOf(sorted[sortIdx]); db.schedule[realIdx].is_done=!db.schedule[realIdx].is_done; refreshUI(); await syncSave(null,null); }
        async function delSch(sortIdx){ if(!confirm('حذف؟'))return; const sorted=[...db.schedule].sort((a,b)=>(a.date+a.time).localeCompare(b.date+b.time)); const realIdx=db.schedule.indexOf(sorted[sortIdx]); db.schedule.splice(realIdx,1); refreshUI(); await syncSave(null,null); }
        function createGoogleLink(jDate,time,title,desc){ const p=jDate.split('/').map(Number); const g=jalaliToGregorian(p[0],p[1],p[2]); const y=g[0],m=String(g[1]).padStart(2,'0'),d=String(g[2]).padStart(2,'0'); const tStart=time.replace(':','')+"00"; const hEnd=String(parseInt(time.split(':')[0])+1).padStart(2,'0'); const tEnd=hEnd+time.split(':')[1]+"00"; return `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(title)}&details=${encodeURIComponent(desc)}&dates=${y}${m}${d}T${tStart}/${y}${m}${d}T${tEnd}&sf=true&output=xml`; }
        function jalaliToGregorian(j_y,j_m,j_d){ j_y+=1595; let days=-355668+(365*j_y)+(~~(j_y/33)*8)+~~(((j_y%33)+3)/4)+j_d+((j_m<7)?(j_m-1)*31:((j_m-7)*30)+186); let g_y = 400 * ~~(days / 146097); days %= 146097; if(days>36524){g_y+=100*~~(--days/36524);days%=36524;if(days>=365)days++;} g_y+=4*~~(days/1461); days%=1461; if(days>365){g_y+=~~((days-1)/365);days=(days-1)%365;} let g_d=days+1; const sal_a=[0,31,((g_y%4===0&&g_y%100!==0)||(g_y%400===0))?29:28,31,30,31,30,31,31,30,31,30,31]; let g_m=0; while(g_m<13 && g_d>sal_a[g_m]) g_d-=sal_a[g_m++]; return [g_y,g_m,g_d]; }

        // --- CASES ---
        function renderCases(){
            const sb=document.getElementById('searchCase'); const q=sb?sb.value.toLowerCase():''; const tb=document.getElementById('tbody-cases'); tb.innerHTML='';
            db.cases.forEach((c, i) => {
                if(q&&!JSON.stringify(c).toLowerCase().includes(q))return;
                let stClass=c.status=='مختومه'?'bg-red-50 text-red-600 dark:bg-red-900/30 dark:text-red-400':'bg-emerald-50 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400';
                tb.innerHTML+=`<tr class="group hover:bg-gray-50 dark:hover:bg-white/5 border-b dark:border-gray-800 last:border-0"><td class="text-xs text-gray-400 p-4 font-mono">${c.id}</td><td onclick="showQuickView(${i})" class="cursor-pointer p-4"><div class="font-bold text-sm text-gray-700 dark:text-gray-200 hover:text-indigo-600 transition">${c.name}</div><div class="text-xs text-gray-400 font-mono mt-1">${c.mobile}</div></td><td class="p-4"><div class="font-bold text-sm text-gray-600 dark:text-gray-300">${c.title}</div><div class="text-xs text-gray-400">${c.type}</div></td><td class="p-4"><span class="${stClass} text-xs px-2 py-1 rounded font-bold border dark:border-transparent">${c.status}</span></td><td class="p-3 text-center"><button onclick="editCase(${i})" class="text-blue-400 hover:text-blue-600 bg-blue-50 dark:bg-blue-900/20 p-2 rounded-lg mx-1"><i class="fas fa-edit"></i></button><button onclick="delCase(${i})" class="text-red-400 hover:text-red-600 bg-red-50 dark:bg-red-900/20 p-2 rounded-lg mx-1"><i class="fas fa-trash"></i></button></td></tr>`;
            });
        }
        // ... (Cases Functions Same as Before)
        function showQuickView(idx){
            const c=db.cases[idx]; ['name','mobile','national','birth','title','type','branch','contract','opponent','address','notes'].forEach(id=>{const el=document.getElementById('qv-'+id);if(el)el.innerText=c[id]||'-'});
            const related=db.cases.filter(x=>x.name===c.name); let inc=0,exp=0; related.forEach(rc=>{const fins=db.finance.filter(f=>f.caseId==rc.id);fins.forEach(f=>f.type=='income'?inc+=Number(f.amount):exp+=Number(f.amount))});
            document.getElementById('qv-total-inc').innerText=inc.toLocaleString(); document.getElementById('qv-total-exp').innerText=exp.toLocaleString(); document.getElementById('qv-total-balance').innerText=(inc-exp).toLocaleString();
            openModal('quickViewModal');
        }
        async function saveCase(e){
            e.preventDefault(); const i=document.getElementById('cIdx').value;
            const newItem={id:i!==""?db.cases[i].id:(db.cases.length?Math.max(...db.cases.map(x=>parseInt(x.id)))+1:1),name:document.getElementById('cName').value,mobile:document.getElementById('cMobile').value,national:document.getElementById('cNational').value,birthDate:document.getElementById('cBirth').value,address:document.getElementById('cAddress').value,title:document.getElementById('cTitle').value,type:document.getElementById('cType').value,status:document.getElementById('cStatus').value,branch:document.getElementById('cBranch').value,opponent:document.getElementById('cOpponent').value,contract:document.getElementById('cContract').value,tags:document.getElementById('cTags').value,notes:document.getElementById('cNotes').value,updatedAt:new Date().toLocaleDateString('fa-IR')};
            if(i!=="")db.cases[i]=newItem;else db.cases.unshift(newItem); closeModal('caseModal'); refreshUI(); await syncSave(newItem,'cases');
        }
        function editCase(i){const c=db.cases[i];document.getElementById('cIdx').value=i;['Name','Mobile','National','Birth','Address','Title','Type','Status','Branch','Opponent','Contract','Tags','Notes'].forEach(k=>document.getElementById('c'+k).value=c[k.toLowerCase().replace('birth','birthDate')]||'');document.getElementById('modal-title').innerText="ویرایش";openModal('caseModal');}
        async function delCase(i){if(confirm('حذف؟')){db.cases.splice(i,1);refreshUI();await syncSave(null,null);}}

        // --- FINANCE: Added Edit Functionality ---
        function filterCasesSelect(){ const val=document.getElementById('fCaseSearch').value.toLowerCase(); const box=document.getElementById('caseDropdown'); box.innerHTML=''; const res=db.cases.filter(c=>c.name.toLowerCase().includes(val)||c.title.includes(val)); if(res.length===0){box.style.display='none';return;} box.style.display='block'; res.forEach(c=>{box.innerHTML+=`<div class="search-select-item p-3 border-b dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-white/10 cursor-pointer text-sm" onclick="selectCase(${c.id},'${c.name}','${c.title}')"><span class="font-bold text-gray-800 dark:text-white">${c.name}</span> <span class="text-xs text-gray-400">(${c.title})</span></div>`;});}
        function selectCase(id,n,t){document.getElementById('fCaseId').value=id;document.getElementById('fCaseSearch').value=n+" ("+t+")";document.getElementById('caseDropdown').style.display='none';}
        function openFinModal(){ document.getElementById('finForm').reset(); document.getElementById('fIdx').value=''; document.getElementById('caseDropdown').style.display='none'; openModal('finModal'); }
        
        function editFin(i) {
            const f = db.finance[i];
            const c = db.cases.find(x => x.id == f.caseId) || {name:'Unknown', title:''};
            document.getElementById('fIdx').value = i;
            document.getElementById('fCaseId').value = f.caseId;
            document.getElementById('fCaseSearch').value = c.name + " ("+(c.title||'-')+")";
            document.getElementById('fType').value = f.type;
            document.getElementById('fDate').value = f.date;
            document.getElementById('fAmnt').value = f.amount;
            document.getElementById('fDesc').value = f.desc;
            openModal('finModal');
        }
        
        async function saveFin(e){
            e.preventDefault(); const cid = document.getElementById('fCaseId').value; if(!cid) return Swal.fire('خطا', 'پرونده را انتخاب کنید', 'warning');
            const idx = document.getElementById('fIdx').value;
            const item = {id: idx!==""?db.finance[idx].id:Date.now(), caseId:cid, type:document.getElementById('fType').value, amount:document.getElementById('fAmnt').value, date:document.getElementById('fDate').value, desc:document.getElementById('fDesc').value};
            if(idx!=="") db.finance[idx]=item; else db.finance.unshift(item);
            closeModal('finModal'); refreshUI(); await syncSave(item, 'finance');
        }
        function renderFinanceUI(){const tb=document.getElementById('tbody-finance');tb.innerHTML='';db.finance.forEach((f,i)=>{const c=db.cases.find(x=>x.id==f.caseId)||{name:'-',title:''};tb.innerHTML+=`<tr class="border-b dark:border-gray-800"><td class="text-sm text-gray-500 py-4 font-mono">${f.date}</td><td class="font-bold text-sm text-gray-700 dark:text-gray-300">${c.name}</td><td><span class="text-xs px-2 py-1 rounded font-bold ${f.type=='income'?'bg-emerald-50 text-emerald-700':'bg-rose-50 text-rose-700'}">${f.type=='income'?'دریافت':'هزینه'}</span></td><td class="font-mono text-gray-800 dark:text-white font-black" dir="ltr">${parseInt(f.amount).toLocaleString()}</td><td class="text-xs text-gray-500 max-w-[150px] truncate">${f.desc}</td><td class="text-center"><button onclick="editFin(${i})" class="text-blue-400 hover:text-blue-600 bg-blue-50 dark:bg-blue-900/20 p-2 rounded-lg"><i class="fas fa-edit"></i></button></td></tr>`;});}

        // --- LIBRARY (Read-only + Edit) ---
        async function saveLib(){ const id=document.getElementById('libId').value||Date.now(); const item={id:id,title:document.getElementById('libTitle').value,content:document.getElementById('libText').value,type:document.getElementById('libType').value}; if(!item.title) return Swal.fire('خطا','عنوان؟','warning'); const idx=db.library.findIndex(z=>z.id==id); if(idx>=0)db.library[idx]=item;else db.library.push(item); newLib(); renderLib(); await syncSave(null,null); }
        function renderLib(){ const q=document.getElementById('searchLib').value.toLowerCase(); const el=document.getElementById('lib-list'); el.innerHTML=''; db.library.forEach(l=>{ if(q&&!l.title.toLowerCase().includes(q))return; el.innerHTML+=`<div onclick="viewLib(${l.id})" class="bg-white dark:bg-white/5 p-4 rounded-xl border border-gray-100 dark:border-gray-800 shadow-sm cursor-pointer hover:border-indigo-300 dark:hover:border-gold-accent transition group"><div class="flex justify-between mb-2"><span class="font-bold text-sm text-gray-800 dark:text-gray-200 group-hover:text-indigo-600 dark:group-hover:text-gold-accent">${l.title}</span><span class="text-[10px] px-2 py-0.5 rounded bg-gray-100 dark:bg-white/10 text-gray-500 font-bold">${l.type}</span></div><div class="text-xs text-gray-400 truncate font-mono">${l.content.substring(0,40)}...</div></div>`; }); }
        
        function viewLib(id) {
            const l = db.library.find(x=>x.id==id);
            document.getElementById('libViewOverlay').classList.add('hidden'); // Hide placeholder
            document.getElementById('libEditorArea').classList.add('hidden'); // Hide editor
            document.getElementById('libContentArea').classList.remove('hidden'); // Show viewer
            document.getElementById('viewLibTitle').innerText = l.title;
            document.getElementById('viewLibContent').innerText = l.content;
            document.getElementById('libId').value = l.id;
        }
        function editLibMode() {
            const id = document.getElementById('libId').value;
            const l = db.library.find(x=>x.id==id);
            document.getElementById('libTitle').value = l.title;
            document.getElementById('libText').value = l.content;
            document.getElementById('libType').value = l.type;
            
            document.getElementById('libContentArea').classList.add('hidden'); // Hide viewer
            document.getElementById('libEditorArea').classList.remove('hidden'); // Show editor
        }
        async function copyLibText() { await navigator.clipboard.writeText(document.getElementById('viewLibContent').innerText); Swal.fire({position:'bottom-end',icon:'success',title:'کپی شد',showConfirmButton:false,timer:1000,toast:true}); }
        function newLib(){ document.getElementById('libViewOverlay').classList.remove('hidden'); document.getElementById('libEditorArea').classList.add('hidden'); document.getElementById('libContentArea').classList.add('hidden'); document.getElementById('libId').value=''; document.getElementById('libTitle').value=''; document.getElementById('libText').value=''; }
        async function delLib(){ if(confirm('حذف؟')){ db.library=db.library.filter(x=>x.id!=document.getElementById('libId').value); newLib(); renderLib(); await syncSave(null,null); } }

        function openModal(id){ document.getElementById(id).classList.add('show'); if(id=='caseModal' && !document.getElementById('cIdx').value) { document.getElementById('caseForm').reset(); document.getElementById('modal-title').innerText="پرونده جدید"; } }
        function closeModal(id){ document.getElementById(id).classList.remove('show'); if(id=='caseModal')document.getElementById('caseForm').reset(); }
        function setView(v,el){document.querySelectorAll('.page-view').forEach(x=>x.classList.add('hidden'));document.getElementById('view-'+v).classList.remove('hidden');document.querySelectorAll('.sidebar-item').forEach(x=>x.classList.remove('active'));if(el)el.classList.add('active');if(window.innerWidth<768)toggleSidebar();}
        async function logout(){await fetch('api.php?action=logout');location.reload();}
    </script>
<?php endif; ?>
</body>
</html>