<?php

/**
 * سامانه تحلیل هوشمند مواد قانونی - نسخه با زبان ساده
 */

// فعال سازی خطایابی
error_reporting(E_ALL);
ini_set('display_errors', 1);

// ========================================================================
// بخش ۱: پیکربندی و تنظیمات کش
// ========================================================================

define('CACHE_DIR', __DIR__ . '/cache');
define('CACHE_EXPIRY', 365 * 24 * 60 * 60); // 24 ساعت

if (!file_exists(CACHE_DIR)) {
    mkdir(CACHE_DIR, 0755, true);
}

// ========================================================================
// بخش ۲: توابع مدیریت کش
// ========================================================================

function generateCacheKey($lawTitle, $articleNumber, $articleText) {
    $content = $lawTitle . '|' . $articleNumber . '|' . $articleText;
    return 'legal_analysis_' . md5($content);
}

function saveToCache($cacheKey, $analysisData) {
    $cacheFile = CACHE_DIR . '/' . $cacheKey . '.json';
    $cacheData = [
        'data' => $analysisData,
        'created_at' => time(),
        'expires_at' => time() + CACHE_EXPIRY
    ];
    
    return file_put_contents($cacheFile, json_encode($cacheData, JSON_UNESCAPED_UNICODE));
}

function getFromCache($cacheKey) {
    $cacheFile = CACHE_DIR . '/' . $cacheKey . '.json';
    
    if (!file_exists($cacheFile)) {
        return null;
    }
    
    $cacheContent = file_get_contents($cacheFile);
    $cacheData = json_decode($cacheContent, true);
    
    if (!$cacheData || !isset($cacheData['expires_at']) || time() > $cacheData['expires_at']) {
        unlink($cacheFile);
        return null;
    }
    
    return $cacheData['data'];
}

function getCacheStats() {
    $stats = [
        'total_files' => 0,
        'total_size' => 0,
        'oldest_file' => null,
        'newest_file' => null
    ];
    
    if (!file_exists(CACHE_DIR)) {
        return $stats;
    }
    
    $files = glob(CACHE_DIR . '/*.json');
    $stats['total_files'] = count($files);
    
    foreach ($files as $file) {
        $stats['total_size'] += filesize($file);
        
        $fileTime = filemtime($file);
        if (!$stats['oldest_file'] || $fileTime < $stats['oldest_file']) {
            $stats['oldest_file'] = $fileTime;
        }
        if (!$stats['newest_file'] || $fileTime > $stats['newest_file']) {
            $stats['newest_file'] = $fileTime;
        }
    }
    
    $stats['total_size_mb'] = round($stats['total_size'] / (1024 * 1024), 2);
    
    return $stats;
}

function cleanupExpiredCache() {
    $files = glob(CACHE_DIR . '/*.json');
    $deletedCount = 0;
    
    foreach ($files as $file) {
        $content = file_get_contents($file);
        $cacheData = json_decode($content, true);
        
        if (!$cacheData || !isset($cacheData['expires_at']) || time() > $cacheData['expires_at']) {
            unlink($file);
            $deletedCount++;
        }
    }
    
    return $deletedCount;
}

// ========================================================================
// بخش ۳: بررسی پیش نیازهای حیاتی سرور
// ========================================================================

if (!function_exists('renderFatalErrorPage')) {
    function renderFatalErrorPage($title, $message) {
        header('Content-Type: text/html; charset=utf-8');
        http_response_code(500);
        die('<!DOCTYPE html><html lang="fa" dir="rtl"><head><title>خطای پیکربندی سرور</title><style>body{font-family: sans-serif; display: flex; justify-content: center; align-items: center; height: 100vh; margin: 0; background-color: #f8d7da;} .box{padding: 40px; border-radius: 10px; background: #f5c6cb; border: 2px solid #dc3545; text-align: center; max-width: 600px;} h1{color: #721c24;} p{font-size: 18px;} code{background: #eee; padding: 2px 5px; border-radius: 3px;}</style></head><body><div class="box"><h1>' . htmlspecialchars($title) . '</h1><p>' . $message . '</p></div></body></html>');
    }
}

if (!function_exists('curl_init')) {
    renderFatalErrorPage('افزونه cURL فعال نیست!', 'اسکریپت برای ارتباط با سرویس‌های هوش مصنوعی به افزونه <strong>cURL</strong> نیاز دارد.');
}

if (!function_exists('mb_strlen')) {
    renderFatalErrorPage('افزونه mbstring فعال نیست!', 'اسکریپت برای پردازش صحیح متون فارسی به افزونه <strong>mbstring</strong> نیاز دارد.');
}

// ========================================================================
// بخش ۴: مدیریت CORS و حالت تست
// ========================================================================

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit;
}

// تابع ایجاد صفحه تست
function generateTestPageContent() {
    $cleanedCount = cleanupExpiredCache();
    $cacheStats = getCacheStats();
    
    $apiProviders = [
        [ 
            'name' => 'Gemini (Google)', 
            'type' => 'gemini', 
            'endpoint' => 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent', 
            'apiKey' => 'AIzaSyBRofclyNEsB86YWmMi4NVTOnQG7QvJiQ4'
        ],
        [ 
            'name' => 'ChatGPT (OpenAI)', 
            'type' => 'openai', 
            'endpoint' => 'https://api.openai.com/v1/chat/completions', 
            'apiKey' => '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', 
            'model' => 'gpt-4o-mini' 
        ],
        [ 
            'name' => 'Cohere', 
            'type' => 'cohere', 
            'endpoint' => 'https://api.cohere.ai/v1/chat', 
            'apiKey' => '2WW4B2zcDuP7g39pKuugBV6atSBcRyVXBr5DeUfm', 
            'model' => 'command-r-plus' 
        ],
        [ 
            'name' => 'Groq', 
            'type' => 'groq', 
            'endpoint' => 'https://api.groq.com/openai/v1/chat/completions', 
            'apiKey' => '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', 
            'model' => 'llama-3.1-8b-instant' 
        ]
    ];

    $html = '<!DOCTYPE html><html lang="fa" dir="rtl"><head>
    <meta charset="UTF-8">
    <title>گزارش تست اتصال - سیستم تحلیل حقوقی با زبان ساده</title>
    <style>
        body {
            font-family: Tahoma, sans-serif;
            padding: 20px;
            line-height: 1.6;
            background-color: #f8f9fa;
            color: #333;
        }
        .container {
            max-width: 1000px;
            margin: auto;
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        h1 {
            color: #2c3e50;
            text-align: center;
            margin-bottom: 10px;
            font-size: 28px;
        }
        .subtitle {
            text-align: center;
            color: #7f8c8d;
            margin-bottom: 30px;
            font-size: 16px;
        }
        .result {
            border: 1px solid #e1e8ed;
            padding: 20px;
            margin-bottom: 15px;
            border-radius: 8px;
            background: #fff;
            transition: all 0.3s ease;
        }
        .result:hover {
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .success {
            background-color: #d4edda;
            border-left: 5px solid #28a745;
            color: #155724;
        }
        .failure {
            background-color: #f8d7da;
            border-left: 5px solid #dc3545;
            color: #721c24;
        }
        h3 {
            margin-top: 0;
            color: #2c3e50;
            font-size: 18px;
        }
        pre {
            white-space: pre-wrap;
            word-wrap: break-word;
            background: #f8f9fa;
            padding: 12px;
            border-radius: 6px;
            font-size: 12px;
            border: 1px solid #e9ecef;
            direction: ltr;
        }
        .info {
            background-color: #e3f2fd;
            border-left: 5px solid #2196F3;
            padding: 15px;
            margin: 15px 0;
            border-radius: 6px;
        }
        .provider-info {
            background: #f8f9fa;
            padding: 10px;
            margin: 8px 0;
            border-radius: 6px;
            font-size: 13px;
            border: 1px solid #e9ecef;
        }
        .stats {
            background: #fff3cd;
            border-left: 5px solid #ffc107;
            padding: 15px;
            margin: 20px 0;
            border-radius: 6px;
        }
        .cache-stats {
            background: #d1ecf1;
            border-left: 5px solid #17a2b8;
            padding: 15px;
            margin: 20px 0;
            border-radius: 6px;
        }
        .free-badge {
            background: #28a745;
            color: white;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 11px;
            margin-right: 8px;
            font-weight: bold;
        }
        .paid-badge {
            background: #007bff;
            color: white;
            padding: 3px 10px;
            border-radius: 15px;
            font-size: 11px;
            margin-right: 8px;
            font-weight: bold;
        }
        .response-time {
            background: #6c757d;
            color: white;
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 11px;
            margin-right: 5px;
        }
        .status-success {
            color: #28a745;
            font-weight: bold;
        }
        .status-failure {
            color: #dc3545;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🔧 گزارش کامل سیستم تحلیل حقوقی</h1>
        <div class="subtitle">تحلیل مواد قانونی با زبان ساده و قابل فهم برای عموم مردم</div>
        
        <div class="cache-stats">
            <h3>📊 آمار سیستم کش</h3>
            <strong>تعداد فایل‌های کش:</strong> ' . $cacheStats['total_files'] . ' | 
            <strong>حجم کل:</strong> ' . $cacheStats['total_size_mb'] . ' مگابایت | 
            <strong>کش‌های پاک‌شده:</strong> ' . $cleanedCount . ' فایل منقضی
        </div>

        <div class="info">
            <h3>🎯 سیستم جدید تحلیل با زبان ساده</h3>
            <strong>ویژگی‌های جدید:</strong><br>
            • توضیح مواد قانونی به زبان بسیار ساده<br>
            • مثال‌های واقعی از زندگی روزمره مردم<br>
            • مناسب برای افراد بدون دانش حقوقی<br>
            • اولویت‌بندی: Gemini → ChatGPT → Cohere → Groq<br>
            • پاسخ‌های کاربردی و قابل فهم برای عموم
        </div>';

    // تابع تماس با API برای تست
    function callAiProviderTest($provider, $prompt) {
        $ch = curl_init(); 
        $headers = ['Content-Type: application/json']; 
        $postData = [];
        
        switch ($provider['type']) {
            case 'groq':
            case 'openai':
                $headers[] = 'Authorization: Bearer ' . $provider['apiKey']; 
                $postData = [
                    'model' => $provider['model'], 
                    'messages' => [['role' => 'user', 'content' => $prompt]], 
                    'max_tokens' => 100,
                    'temperature' => 0.3
                ]; 
                break;
            case 'cohere':
                $headers[] = 'Authorization: Bearer ' . $provider['apiKey']; 
                $postData = [
                    'model' => $provider['model'], 
                    'message' => $prompt,
                    'max_tokens' => 100,
                    'temperature' => 0.3
                ]; 
                break;
            case 'gemini': 
                $provider['endpoint'] .= '?key=' . $provider['apiKey']; 
                $postData = ['contents' => [['parts' => [['text' => $prompt]]]]]; 
                break;
        }
        
        curl_setopt_array($ch, [
            CURLOPT_URL => $provider['endpoint'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($postData),
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false
        ]);
        
        $response = curl_exec($ch); 
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);
        curl_close($ch);
        
        if ($curl_error) { 
            throw new Exception("cURL Error: " . $curl_error);
        }
        
        if ($http_code >= 400) {
            throw new Exception("HTTP Error {$http_code}");
        }
        
        $data = json_decode($response, true);
        
        switch ($provider['type']) {
            case 'groq':
            case 'openai':
                return isset($data['choices'][0]['message']['content']) ? $data['choices'][0]['message']['content'] : null;
            case 'cohere':
                return isset($data['text']) ? $data['text'] : null;
            case 'gemini':
                return isset($data['candidates'][0]['content']['parts'][0]['text']) ? $data['candidates'][0]['content']['parts'][0]['text'] : null;
        }
        
        return null;
    }

    // آمار تست
    $total_providers = count($apiProviders);
    $success_count = 0;
    $failed_count = 0;

    // تست هر ارائه دهنده
    foreach ($apiProviders as $provider) {
        $html .= '<div class="result">';
        $badge = in_array($provider['name'], ['Gemini (Google)', 'Cohere', 'Groq']) ? 
                '<span class="free-badge">رایگان</span>' : 
                '<span class="paid-badge">پرداختی</span>';
        
        $html .= "<h3>🔄 تست اتصال به: {$provider['name']} {$badge}</h3>";
        $html .= "<div class='provider-info'>";
        $html .= "<strong>اولویت:</strong> " . (array_search($provider, $apiProviders) + 1) . " | ";
        $html .= "<strong>نوع سرویس:</strong> {$provider['type']} | ";
        if (isset($provider['model'])) {
            $html .= "<strong>مدل:</strong> {$provider['model']} | ";
        }
        $html .= "<strong>آدرس:</strong> " . parse_url($provider['endpoint'], PHP_URL_HOST);
        $html .= "</div>";
        
        try {
            $start_time = microtime(true);
            $response = callAiProviderTest($provider, 'سلام! لطفاً پاسخ کوتاه "تست موفق" را برگردان.');
            $response_time = round((microtime(true) - $start_time) * 1000, 2);
            
            if(empty($response)) throw new Exception("پاسخ خالی دریافت شد.");
            
            $success_count++;
            $html .= '<div class="success">';
            $html .= '<span class="status-success">✅ اتصال موفق</span> | ';
            $html .= '<span class="response-time">' . $response_time . 'ms</span>';
            $html .= '</div>';
            $html .= '<strong>پاسخ دریافت شده:</strong><pre>' . htmlspecialchars(mb_substr($response, 0, 200)) . '...</pre>';
        } catch (Exception $e) {
            $failed_count++;
            $html .= '<div class="failure">';
            $html .= '<span class="status-failure">❌ اتصال ناموفق</span>';
            $html .= '</div>';
            $html .= '<strong>پیام خطا:</strong><pre>' . htmlspecialchars($e->getMessage()) . '</pre>';
        }
        $html .= '</div>';
    }
    
    // نمایش آمار
    $html .= '<div class="stats">';
    $html .= "<h3>📊 آمار کلی تست API های فعال</h3>";
    $html .= "<strong>کل سرویس‌ها:</strong> {$total_providers} | ";
    $html .= "<strong>موفق:</strong> <span style='color: #28a745; font-weight: bold;'>{$success_count}</span> | ";
    $html .= "<strong>ناموفق:</strong> <span style='color: #dc3545; font-weight: bold;'>{$failed_count}</span> | ";
    $success_rate = $total_providers > 0 ? round(($success_count / $total_providers) * 100, 1) : 0;
    $html .= "<strong>میزان موفقیت:</strong> <span style='color: #007bff; font-weight: bold;'>{$success_rate}%</span>";
    
    if ($success_count >= 3) {
        $html .= "<br><span style='color: #28a745; font-weight: bold; font-size: 16px;'>✅ سیستم کاملاً آماده استفاده است!</span>";
    } elseif ($success_count >= 2) {
        $html .= "<br><span style='color: #ffc107; font-weight: bold;'>⚠️ سیستم قابل استفاده است</span>";
    } else {
        $html .= "<br><span style='color: #dc3545; font-weight: bold;'>❌ نیاز به تنظیم مجدد</span>";
    }
    
    $html .= '</div></div></body></html>';
    return $html;
}

// حالت تست
if ($_SERVER['REQUEST_METHOD'] == 'GET') {
    if (isset($_GET['test']) && isset($_GET['pass']) && $_GET['pass'] === '123456') {
        if (isset($_GET['clear_cache'])) {
            $files = glob(CACHE_DIR . '/*.json');
            $deleted = 0;
            foreach ($files as $file) {
                if (unlink($file)) $deleted++;
            }
            echo "<script>alert('کش با موفقیت پاک شد! ({$deleted} فایل)'); window.location.href='?test=1&pass=123456';</script>";
            exit;
        }
        
        $testContent = generateTestPageContent();
        header('Content-Type: text/html; charset=utf-8');
        echo $testContent;
        exit;
    } else {
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['success' => true, 'message' => 'API فعال است. برای استفاده، درخواست POST ارسال کنید.'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// ========================================================================
// بخش ۵: منطق اصلی برنامه برای درخواست های POST
// ========================================================================

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'error' => 'Invalid request method.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (!$input || !isset($input['articleText'], $input['articleNumber'], $input['lawTitle'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'اطلاعات ارسالی ناقص است.']);
    exit;
}

$articleText = trim($input['articleText']);
$articleNumber = trim($input['articleNumber']);
$lawTitle = trim($input['lawTitle']);

// تولید کلید کش
$cacheKey = generateCacheKey($lawTitle, $articleNumber, $articleText);

// بررسی کش قبل از ارسال به API
$cachedResult = getFromCache($cacheKey);
if ($cachedResult) {
    $finalResponse = [ 
        'success' => true, 
        'data' => $cachedResult,
        'cached' => true,
        'cache_info' => [
            'message' => 'این تحلیل از کش بازیابی شد',
            'saved_time' => date('Y-m-d H:i:s'),
            'cache_key' => $cacheKey
        ]
    ];
    echo json_encode($finalResponse, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    exit;
}

// لیست API های فعال با اولویت‌بندی جدید
$apiProviders = [
    [ 
        'name' => 'Gemini', 
        'type' => 'gemini', 
        'endpoint' => 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent', 
        'apiKey' => 'AIzaSyBRofclyNEsB86YWmMi4NVTOnQG7QvJiQ4'
    ],
    [ 
        'name' => 'ChatGPT', 
        'type' => 'openai', 
        'endpoint' => 'https://api.openai.com/v1/chat/completions', 
        'apiKey' => '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', 
        'model' => 'gpt-4o-mini' 
    ],
    [ 
        'name' => 'Cohere', 
        'type' => 'cohere', 
        'endpoint' => 'https://api.cohere.ai/v1/chat', 
        'apiKey' => '2WW4B2zcDuP7g39pKuugBV6atSBcRyVXBr5DeUfm', 
        'model' => 'command-r-plus' 
    ],
    [ 
        'name' => 'Groq', 
        'type' => 'groq', 
        'endpoint' => 'https://api.groq.com/openai/v1/chat/completions', 
        'apiKey' => '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', 
        'model' => 'llama-3.1-8b-instant' 
    ]
];

// پرامپت جدید با زبان ساده
function buildPrompt($lawTitle, $articleNumber, $articleText) {
    return "شما یک وکیل باتجربه و مدرس حقوق هستید. وظیفه شما توضیح ماده قانونی زیر به زبان بسیار ساده و قابل فهم برای عموم مردم است:

📜 **تحلیل ماده {$articleNumber} {$lawTitle}**

متن ماده: «{$articleText}»

لطفاً این ماده قانونی را در چهار بخش زیر توضیح دهید:

🔍 معنی و مفهوم این ماده چیست؟
- به زبان ساده بگویید این ماده چه می‌گوید؟
- چه کسی را خطاب قرار داده؟
- در چه شرایطی اجرا می‌شود؟

🎯 نکات مهمی که باید بدانید:
- مهم‌ترین چیزهایی که از این ماده باید فهمید
- اگر این ماده رعایت نشود چه اتفاقی می‌افتد؟
- چه حقوقی به افراد می‌دهد یا چه تکالیفی ایجاد می‌کند؟

💡 مثال‌های واقعی از زندگی روزمره:

مثال ۱: [یک مثال ساده از زندگی عادی مردم]
مثال ۲: [یک مثال از محیط کار یا کسب‌وکار]
مثال ۳: [یک مثال از روابط خانوادگی یا اجتماعی]

✅ خلاصه و نتیجه‌گیری:
- این ماده در یک جمله چه می‌گوید؟
- چه کسانی بیشتر باید این ماده را بدانند؟
- آیا استثنایی دارد؟

---
توجه: 
- مثل یک معلم دلسوز و باتجربه توضیح دهید
- از اصطلاحات پیچیده حقوقی استفاده نکنید
- برای افراد عادی که دانش حقوقی ندارند بنویسید
- مثال‌ها باید از زندگی واقعی مردم ایران باشد";
}

// سیستم ارزیابی جدید برای زبان ساده
function validateAnalysis($analysisText, $articleNumber) {
    $score = 0;
    
    // بررسی بخش‌های اصلی
    if (strpos($analysisText, 'معنی و مفهوم') !== false) $score += 25;
    if (strpos($analysisText, 'نکات مهم') !== false) $score += 25;
    if (strpos($analysisText, 'مثال') !== false) $score += 25;
    if (strpos($analysisText, 'خلاصه') !== false) $score += 15;
    
    // بررسی سادگی زبان (کم کردن امتیاز برای اصطلاحات پیچیده)
    $complexTerms = ['اصطلاحاً', 'به موجب', 'مستنبط', 'مقرره', 'تشریفات', 'حقوق موضوعه', 'مرجع صالح'];
    $complexCount = 0;
    foreach ($complexTerms as $term) {
        if (strpos($analysisText, $term) !== false) $complexCount++;
    }
    if ($complexCount == 0) $score += 10;
    
    // بررسی کیفیت محتوا
    if (mb_strlen($analysisText, 'UTF-8') > 400) $score += 10;
    
    return min(100, $score);
}

function callAiProviderMain($provider, $prompt) {
    $ch = curl_init(); 
    $headers = ['Content-Type: application/json']; 
    $postData = [];
    
    switch ($provider['type']) {
        case 'groq':
        case 'openai':
            $headers[] = 'Authorization: Bearer ' . $provider['apiKey']; 
            $postData = [
                'model' => $provider['model'], 
                'messages' => [['role' => 'user', 'content' => $prompt]], 
                'max_tokens' => 3000, 
                'temperature' => 0.3
            ]; 
            break;
        case 'cohere':
            $headers[] = 'Authorization: Bearer ' . $provider['apiKey']; 
            $postData = [
                'model' => $provider['model'], 
                'message' => $prompt,
                'max_tokens' => 3000,
                'temperature' => 0.3
            ]; 
            break;
        case 'gemini': 
            $provider['endpoint'] .= '?key=' . $provider['apiKey']; 
            $postData = ['contents' => [['parts' => [['text' => $prompt]]]]]; 
            break;
    }
    
    curl_setopt_array($ch, [
        CURLOPT_URL => $provider['endpoint'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($postData),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 60,
        CURLOPT_SSL_VERIFYPEER => false
    ]);
    
    $response = curl_exec($ch); 
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if (curl_errno($ch) || $http_code >= 400) { 
        $error_msg = curl_error($ch) ?: "HTTP Error {$http_code}";
        curl_close($ch); 
        throw new Exception($error_msg); 
    }
    
    curl_close($ch); 
    $data = json_decode($response, true);
    
    switch ($provider['type']) {
        case 'groq':
        case 'openai':
            return isset($data['choices'][0]['message']['content']) ? $data['choices'][0]['message']['content'] : null;
        case 'cohere':
            return isset($data['text']) ? $data['text'] : null;
        case 'gemini':
            return isset($data['candidates'][0]['content']['parts'][0]['text']) ? $data['candidates'][0]['content']['parts'][0]['text'] : null;
    }
    
    return null;
}

// منطق اصلی برنامه
$mainPrompt = buildPrompt($lawTitle, $articleNumber, $articleText);
$bestResult = null; 
$bestProviderName = null; 
$bestScore = 0;

foreach ($apiProviders as $provider) {
    try {
        $responseText = callAiProviderMain($provider, $mainPrompt);
        if (empty($responseText) || mb_strlen($responseText, 'UTF-8') < 150) continue;
        
        $score = validateAnalysis($responseText, $articleNumber);
        if ($score > $bestScore) {
            $bestScore = $score; 
            $bestResult = $responseText; 
            $bestProviderName = $provider['name'];
        }
        
        // اگر امتیاز خوبی گرفتیم، ادامه ندهیم
        if ($bestScore >= 80) break;
    } catch (Exception $e) {
        error_log("API Error for {$provider['name']}: " . $e->getMessage());
        continue;
    }
}

// ارسال پاسخ نهایی
if ($bestResult) {
    $analysisData = [ 
        'answer' => $bestResult, 
        'provider' => $bestProviderName, 
        'timestamp' => date('c'), 
        'articleNumber' => $articleNumber, 
         'lawTitle' => $lawTitle, // این خط را اضافه کنید
        'accuracyScore' => $bestScore,
        'analysisType' => 'تحلیل ساده و کاربردی'
    ];
    
    // ذخیره در کش
    saveToCache($cacheKey, $analysisData);
    
    $finalResponse = [ 
        'success' => true, 
        'data' => $analysisData,
        'cached' => false,
        'cache_info' => [
            'message' => 'این تحلیل جدید است و در کش ذخیره شد',
            'cache_key' => $cacheKey,
            'expires_in' => '24 ساعت'
        ]
    ];
} else {
    http_response_code(503);
    $finalResponse = [ 
        'success' => false, 
        'error' => 'متاسفانه در حال حاضر هیچ‌کدام از سرویس‌های هوش مصنوعی پاسخگو نبودند. لطفاً چند دقیقه دیگر دوباره تلاش کنید.' 
    ];
}

echo json_encode($finalResponse, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>