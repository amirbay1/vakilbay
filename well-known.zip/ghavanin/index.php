<!doctype html>
<html lang="fa" dir="rtl">
 <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>سامانه قوانین جمهوری اسلامی ایران | وکیل بای - bayvakil.ir
</title>
   <!-- === تغییرات PWA - شروع === -->
  <meta name="theme-color" content="#1e40af"/>
  <link rel="manifest" href="manifest.json">
  <link rel="apple-touch-icon" href="icon-192x192.png">
  <!-- === تغییرات PWA - پایان === -->
  <!-- SEO Meta Tags -->
  <meta name="description" content="دسترسی آسان و سریع به قوانین جمهوری اسلامی ایران شامل قانون مدنی، آیین دادرسی، تجارت و مجازات اسلامی. تحلیل هوش مصنوعی مواد قانونی با صحت‌سنجی.">
  <meta name="keywords" content="قانون مدنی, آیین دادرسی, قانون تجارت, مجازات اسلامی, وکیل, حقوق, قوانین ایران, bayvakil">
  <meta name="author" content="وکیل بای - bayvakil.ir">
  <meta name="robots" content="index, follow">
  <meta name="language" content="fa"><!-- Open Graph Meta Tags -->
  <meta property="og:title" content="سامانه قوانین جمهوری اسلامی ایران | وکیل بای">
  <meta property="og:description" content="دسترسی آسان به قوانین ایران با تحلیل هوش مصنوعی و صحت‌سنجی. قانون مدنی، آیین دادرسی، تجارت و بیشتر.">
  <meta property="og:type" content="website">
  <meta property="og:url" content="https://bayvakil.ir">
  <meta property="og:site_name" content="وکیل بای">
  <meta property="og:locale" content="fa_IR"><!-- Twitter Card Meta Tags -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:title" content="سامانه قوانین جمهوری اسلامی ایران">
  <meta name="twitter:description" content="دسترسی آسان به قوانین ایران با تحلیل هوش مصنوعی"><!-- Canonical URL -->
<link rel="canonical" href="" id="dynamic-canonical">

<script>
    // ساخت کنونیکال به صورت خودکار با جاوا اسکریپت
    var canonicalLink = document.getElementById("dynamic-canonical");
    canonicalLink.href = window.location.href.split('?')[0]; // آدرس تمیز بدون پارامترهای اضافی
</script>
<script type="application/ld+json">
    {
        "@context": "https://schema.org",
        "@type": "WebApplication",
        "name": "سامانه قوانین جمهوری اسلامی ایران",
        "description": "دسترسی آسان و سریع به قوانین جمهوری اسلامی ایران",
        "url": "https://bayvakil.ir",
        "applicationCategory": "LegalApplication",
        "operatingSystem": "Web Browser",
        "offers": {
            "@type": "Offer",
            "price": "0",
            "priceCurrency": "IRR"
        },
        "provider": {
            "@type": "Organization",
            "name": "وکیل بای",
            "url": "https://bayvakil.ir"
        }
    }
    </script>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<link rel="preload" href="/fonts/Vazirmatn.woff2" as="font" type="font/woff2" crossorigin fetchpriority="high">

<style>
@font-face {
  font-family: 'Vazirmatn';
  src: url('/fonts/Vazirmatn.woff2') format('woff2-variations'),
       url('/fonts/Vazirmatn.woff2') format('woff2');
  font-weight: 100 900;
  font-style: normal;
  font-display: swap;
}

/* فونت پیش‌فرض برای کل سایت */
body {
  font-family: 'Vazirmatn', sans-serif;
}
</style>
  <style>
        body {
            box-sizing: border-box;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-color: #1e40af;
            --secondary-color: #f1f5f9;
            --text-color: #0f172a;
            --border-color: #cbd5e1;
            --success-color: #059669;
            --warning-color: #d97706;
            --error-color: #dc2626;
            --accent-color: #7c3aed;
            --shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        [data-theme="dark"] {
            --primary-color: #3b82f6;
            --secondary-color: #1e293b;
            --text-color: #f1f5f9;
            --border-color: #334155;
            --success-color: #22c55e;
            --warning-color: #fbbf24;
            --error-color: #f87171;
        }

        body {
            font-family: 'Vazirmatn', sans-serif;
            background: linear-gradient(135deg, var(--secondary-color) 0%, #e2e8f0 100%);
            color: var(--text-color);
            min-height: 100%;
            transition: var(--transition);
        }

        .app-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            min-height: 100vh;
        }

        .header {
            background: white;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
            transition: var(--transition);
        }

        [data-theme="dark"] .header {
            background: #334155;
            border-color: var(--border-color);
        }

        .header-top {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .app-title {
            font-size: 28px;
            font-weight: 700;
            color: var(--primary-color);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .controls {
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }

        .theme-toggle, .pwa-install {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 10px 16px;
            border-radius: 8px;
            cursor: pointer;
            font-family: inherit;
            font-size: 14px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .theme-toggle:hover, .pwa-install:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .search-container {
            position: relative;
            margin-bottom: 20px;
        }

        .search-input {
            width: 100%;
            padding: 16px 50px 16px 20px;
            border: 2px solid var(--border-color);
            border-radius: 12px;
            font-size: 16px;
            font-family: inherit;
            background: white;
            color: var(--text-color);
            transition: var(--transition);
        }

        [data-theme="dark"] .search-input {
            background: #475569;
            border-color: var(--border-color);
        }

        .search-input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
        }

        .search-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #64748b;
        }

        .law-selector {
            display: flex;
            gap: 8px;
            margin-bottom: 20px;
            flex-wrap: wrap;
            overflow-x: auto;
            padding-bottom: 8px;
            scrollbar-width: thin;
            scrollbar-color: var(--primary-color) transparent;
        }

        .law-selector::-webkit-scrollbar {
            height: 4px;
        }

        .law-selector::-webkit-scrollbar-track {
            background: transparent;
        }

        .law-selector::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 2px;
        }

        .law-card {
            background: white;
            border: 2px solid var(--border-color);
            border-radius: 12px;
            padding: 12px 16px;
            cursor: pointer;
            transition: var(--transition);
            text-align: center;
            min-width: 140px;
            flex: 1;
            position: relative;
            overflow: hidden;
        }

        [data-theme="dark"] .law-card {
            background: #475569;
            border-color: var(--border-color);
        }

        .law-card:hover {
            border-color: var(--primary-color);
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .law-card.active {
            border-color: var(--primary-color);
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.15) 0%, rgba(37, 99, 235, 0.05) 100%);
            box-shadow: 0 4px 12px rgba(37, 99, 235, 0.2);
        }

        .law-card.active::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-color) 0%, #1d4ed8 100%);
        }

        .law-card h3 {
            font-size: 13px;
            font-weight: 600;
            color: var(--text-color);
            margin: 0;
            line-height: 1.3;
        }

        .law-card.active h3 {
            color: var(--primary-color);
            font-weight: 700;
        }

        /* موبایل - نمایش عمودی */
        @media (max-width: 768px) {
            .law-selector {
                display: grid;
                grid-template-columns: 1fr;
                gap: 8px;
                overflow-x: visible;
                padding-bottom: 0;
            }
            
            .law-card {
                min-width: auto;
                padding: 16px 20px;
                display: flex;
                align-items: center;
                justify-content: space-between;
                text-align: right;
            }

            .law-card h3 {
                font-size: 15px;
                flex: 1;
            }

            .law-card.active::after {
                content: '✓';
                color: var(--primary-color);
                font-weight: bold;
                font-size: 18px;
                margin-left: 12px;
            }

            .law-card::before {
                content: '';
                width: 8px;
                height: 8px;
                border-radius: 50%;
                background: var(--border-color);
                margin-left: 12px;
                transition: var(--transition);
            }

            .law-card.active::before {
                background: var(--primary-color);
                box-shadow: 0 0 8px rgba(37, 99, 235, 0.4);
            }
        }

        /* تبلت - نمایش دو ستونه */
        @media (min-width: 769px) and (max-width: 1024px) {
            .law-selector {
                display: grid;
                grid-template-columns: repeat(2, 1fr);
                gap: 12px;
            }
            
            .law-card {
                min-width: auto;
            }
        }

        .main-content {
            max-width: 100%;
        }

        .tools-bar {
            background: white;
            border-radius: 12px;
            padding: 16px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
            display: flex;
            gap: 12px;
            align-items: center;
            flex-wrap: wrap;
        }

        [data-theme="dark"] .tools-bar {
            background: #334155;
            border-color: var(--border-color);
        }

        .tool-group {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .tool-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 8px;
            cursor: pointer;
            font-family: inherit;
            font-size: 14px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .tool-btn:hover {
            transform: translateY(-1px);
            box-shadow: var(--shadow);
        }

        .tool-btn.secondary {
            background: var(--secondary-color);
            color: var(--text-color);
            border: 1px solid var(--border-color);
        }

        .jump-input {
            padding: 8px 12px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-family: inherit;
            background: white;
            color: var(--text-color);
            width: 120px;
        }

        [data-theme="dark"] .jump-input {
            background: #475569;
            border-color: var(--border-color);
        }

        .bookmarks-dropdown {
            position: relative;
        }

        .bookmarks-menu {
            position: absolute;
            top: 100%;
            right: 0;
            background: white;
            border: 1px solid var(--border-color);
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            min-width: 250px;
            max-height: 300px;
            overflow-y: auto;
            z-index: 1000;
            display: none;
        }

        [data-theme="dark"] .bookmarks-menu {
            background: #334155;
            border-color: var(--border-color);
        }

        .bookmarks-menu.show {
            display: block;
        }

        .bookmark-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 16px;
            border-bottom: 1px solid var(--border-color);
            cursor: pointer;
            transition: var(--transition);
        }

        .bookmark-item:hover {
            background: rgba(37, 99, 235, 0.1);
        }

        .bookmark-item:last-child {
            border-bottom: none;
        }

        .bookmark-remove {
            background: none;
            border: none;
            color: var(--error-color);
            cursor: pointer;
            padding: 4px;
            border-radius: 4px;
            font-size: 16px;
        }

        .articles-container {
            background: white;
            border-radius: 16px;
            padding: 24px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
        }

        [data-theme="dark"] .articles-container {
            background: #334155;
            border-color: var(--border-color);
        }

        .article-card {
            border: 2px solid var(--border-color);
            border-radius: 12px;
            margin-bottom: 20px;
            overflow: hidden;
            transition: var(--transition);
            background: white;
        }

        [data-theme="dark"] .article-card {
            background: #475569;
            border-color: var(--border-color);
        }

        .article-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1d4ed8 100%);
            color: white;
            padding: 16px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .article-number {
            font-size: 18px;
            font-weight: 600;
        }

        .article-actions {
            display: flex;
            gap: 8px;
        }

        .action-btn {
            background: rgba(255, 255, 255, 0.2);
            border: none;
            color: white;
            padding: 8px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 12px;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .action-btn:hover {
            background: rgba(255, 255, 255, 0.3);
        }

        .action-btn.active {
            background: rgba(255, 255, 255, 0.4);
        }

        .article-content {
            padding: 20px;
        }

        .article-text {
            line-height: 1.8;
            font-size: 20px;
            margin-bottom: 16px;
            text-align: justify;
            font-weight: bolder;
        }

        .notes-section {
            margin-top: 16px;
            padding-top: 16px;
            border-top: 1px solid var(--border-color);
        }

        .notes-textarea {
            width: 100%;
            min-height: 80px;
            padding: 12px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-family: inherit;
            resize: vertical;
            background: white;
            color: var(--text-color);
        }

        [data-theme="dark"] .notes-textarea {
            background: #64748b;
            border-color: var(--border-color);
        }



        .loading {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px;
            color: #64748b;
        }

        .spinner {
            width: 32px;
            height: 32px;
            border: 3px solid var(--border-color);
            border-top: 3px solid var(--primary-color);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-left: 12px;
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: var(--success-color);
            color: white;
            padding: 12px 20px;
            border-radius: 8px;
            box-shadow: var(--shadow-lg);
            transform: translateX(100%);
            transition: var(--transition);
            z-index: 1000;
        }

        .toast.show {
            transform: translateX(0);
        }

        .toast.error {
            background: var(--error-color);
        }

        .no-results {
            text-align: center;
            padding: 40px;
            color: #64748b;
        }

        .highlight {
            background: yellow;
            padding: 2px 4px;
            border-radius: 3px;
        }

        [data-theme="dark"] .highlight {
            background: #fbbf24;
            color: #000;
        }

        /* دکمه رفتن به بالا */
        .scroll-to-top {
            position: fixed;
            bottom: 20px;
            left: 20px;
            background: var(--primary-color);
            color: white;
            border: none;
            width: 50px;
            height: 50px;
            border-radius: 50%;
            cursor: pointer;
            font-size: 18px;
            box-shadow: var(--shadow-lg);
            transition: var(--transition);
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
        }

        .scroll-to-top.show {
            opacity: 1;
            visibility: visible;
        }

        .scroll-to-top:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.4);
        }

        /* اطلاعات وکیل */
        .lawyer-info {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
            box-shadow: var(--shadow);
            border: 1px solid var(--border-color);
            text-align: center;
            transition: var(--transition);
        }

        [data-theme="dark"] .lawyer-info {
            background: #334155;
            border-color: var(--border-color);
        }

        .lawyer-info:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
        }

        /* AI Modal Styles */
        .ai-modal {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            z-index: 2000;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .ai-modal-content {
            background: white;
            border-radius: 16px;
            max-width: 800px;
            width: 100%;
            max-height: 90vh;
            overflow-y: auto;
            box-shadow: var(--shadow-lg);
        }

        [data-theme="dark"] .ai-modal-content {
            background: #334155;
        }

        .ai-modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px 24px;
            border-bottom: 1px solid var(--border-color);
        }

        .ai-modal-header h3 {
            margin: 0;
            color: var(--primary-color);
            font-size: 20px;
        }

        .ai-modal-close {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #64748b;
            padding: 4px;
            border-radius: 4px;
            transition: var(--transition);
        }

        .ai-modal-close:hover {
            background: rgba(0, 0, 0, 0.1);
        }

        .ai-modal-body {
            padding: 24px;
        }

        .ai-input-section {
            margin-bottom: 24px;
        }

        .ai-input-section label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--text-color);
        }

        #ai-question {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            font-family: inherit;
            font-size: 14px;
            resize: vertical;
            background: white;
            color: var(--text-color);
            margin-bottom: 16px;
        }

        [data-theme="dark"] #ai-question {
            background: #475569;
            border-color: var(--border-color);
        }

        .ai-context-options {
            display: flex;
            gap: 16px;
            margin-bottom: 16px;
            flex-wrap: wrap;
        }

        .ai-context-options label {
            display: flex;
            align-items: center;
            gap: 6px;
            font-weight: normal;
            font-size: 14px;
            cursor: pointer;
        }

        .ai-analyze-btn {
            background: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 24px;
            border-radius: 8px;
            cursor: pointer;
            font-family: inherit;
            font-size: 16px;
            font-weight: 600;
            transition: var(--transition);
            display: flex;
            align-items: center;
            gap: 8px;
            min-width: 120px;
            justify-content: center;
        }

        .ai-analyze-btn:hover:not(:disabled) {
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .ai-analyze-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
        }

        .ai-spinner {
            width: 16px;
            height: 16px;
            border: 2px solid rgba(255, 255, 255, 0.3);
            border-top: 2px solid white;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        .ai-status {
            margin-bottom: 16px;
            padding: 12px;
            border-radius: 8px;
            font-size: 14px;
            display: none;
        }

        .ai-status.show {
            display: block;
        }

        .ai-status.info {
            background: rgba(37, 99, 235, 0.1);
            color: var(--primary-color);
            border: 1px solid rgba(37, 99, 235, 0.2);
        }

        .ai-status.error {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error-color);
            border: 1px solid rgba(239, 68, 68, 0.2);
        }

        .ai-result {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.05) 0%, rgba(37, 99, 235, 0.05) 100%);
            border: 2px solid rgba(16, 185, 129, 0.2);
            border-radius: 16px;
            padding: 24px;
            margin-top: 20px;
            display: none;
            line-height: 1.8;
            box-shadow: var(--shadow);
        }

        .ai-result.show {
            display: block;
            animation: slideInUp 0.5s ease-out;
        }

        @keyframes slideInUp {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .ai-result-header {
            display: flex;
            align-items: center;
            gap: 12px;
            margin-bottom: 20px;
            padding: 16px 20px;
            border-radius: 12px;
            background: linear-gradient(135deg, var(--success-color) 0%, #16a34a 100%);
            color: white;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }

        .ai-result-header h4 {
            color: white;
            margin: 0;
            font-size: 20px;
            font-weight: 700;
        }

        .ai-result-badge {
            background: var(--success-color);
            color: white;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .badges-container {
            display: flex;
            gap: 8px;
            align-items: center;
            flex-wrap: wrap;
        }

        .accuracy-badge {
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 4px;
        }

        .accuracy-badge.excellent {
            background: var(--success-color);
            color: white;
        }

        .accuracy-badge.good {
            background: #22c55e;
            color: white;
        }

        .accuracy-badge.fair {
            background: var(--warning-color);
            color: white;
        }

        .accuracy-badge.poor {
            background: var(--error-color);
            color: white;
        }

        .ai-result-header.excellent {
            background: linear-gradient(135deg, var(--success-color) 0%, #16a34a 100%);
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }

        .ai-result-header.good {
            background: linear-gradient(135deg, #22c55e 0%, var(--success-color) 100%);
            box-shadow: 0 4px 12px rgba(34, 197, 94, 0.3);
        }

        .ai-result-header.fair {
            background: linear-gradient(135deg, var(--warning-color) 0%, #ea580c 100%);
            box-shadow: 0 4px 12px rgba(217, 119, 6, 0.3);
        }

        .ai-result-header.poor {
            background: linear-gradient(135deg, var(--error-color) 0%, #b91c1c 100%);
            box-shadow: 0 4px 12px rgba(220, 38, 38, 0.3);
        }

        .ai-result-content {
            color: var(--text-color);
            font-size: 16px;
            line-height: 1.8;
            margin-bottom: 20px;
        }

        .ai-result-content h5 {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1d4ed8 100%);
            color: white;
            font-size: 16px;
            font-weight: 600;
            margin: 20px 0 16px 0;
            padding: 12px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 2px 4px rgba(37, 99, 235, 0.2);
        }

        .ai-result-content h5 i {
            font-size: 14px;
            opacity: 0.9;
        }

        .ai-result-content .section-content {
            background: rgba(248, 250, 252, 0.8);
            border: 1px solid rgba(37, 99, 235, 0.1);
            border-radius: 8px;
            padding: 16px;
            margin-bottom: 16px;
            line-height: 1.7;
        }

        [data-theme="dark"] .ai-result-content .section-content {
            background: rgba(71, 85, 105, 0.3);
            border-color: rgba(37, 99, 235, 0.2);
        }

        .ai-result-content ul {
            margin: 12px 0;
            padding-right: 20px;
            list-style: none;
        }

        .ai-result-content li {
            margin-bottom: 10px;
            position: relative;
            padding-right: 20px;
            line-height: 1.6;
        }

        .ai-result-content li::before {
            content: "▪";
            color: var(--primary-color);
            font-weight: bold;
            position: absolute;
            right: 0;
            font-size: 16px;
        }

        .ai-result-content p {
            margin-bottom: 12px;
            text-align: justify;
            line-height: 1.7;
        }

        .ai-result-content strong {
            color: var(--primary-color);
            font-weight: 600;
            background: rgba(37, 99, 235, 0.1);
            padding: 2px 6px;
            border-radius: 4px;
        }

        .ai-result-content .highlight-box {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.1) 0%, rgba(37, 99, 235, 0.1) 100%);
            border-right: 4px solid var(--success-color);
            padding: 16px;
            margin: 16px 0;
            border-radius: 0 8px 8px 0;
            font-style: italic;
        }

        .ai-result-content .related-articles {
            background: rgba(16, 185, 129, 0.05);
            border: 2px solid rgba(16, 185, 129, 0.2);
            border-radius: 12px;
            padding: 16px;
            margin: 16px 0;
        }

        .ai-result-content .related-articles h6 {
            color: var(--success-color);
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 12px 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        .ai-result-content .article-ref {
            display: inline-block;
            background: var(--success-color);
            color: white;
            padding: 4px 8px;
            border-radius: 16px;
            font-size: 12px;
            font-weight: 600;
            margin: 2px 4px 2px 0;
            text-decoration: none;
        }

        .ai-result-content .warning-box {
            background: rgba(245, 158, 11, 0.1);
            border: 2px solid rgba(245, 158, 11, 0.3);
            border-radius: 8px;
            padding: 16px;
            margin: 16px 0;
        }

        .ai-result-content .warning-box h6 {
            color: var(--warning-color);
            font-size: 14px;
            font-weight: 600;
            margin: 0 0 8px 0;
            display: flex;
            align-items: center;
            gap: 6px;
        }

        /* استایل‌های جدید برای تحلیل حقوقی */
        .analysis-header {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1d4ed8 100%);
            color: white;
            padding: 20px 24px;
            border-radius: 12px 12px 0 0;
            margin-bottom: 0;
        }

        .analysis-header h4 {
            margin: 0;
            font-size: 20px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .main-analysis-section {
            background: linear-gradient(135deg, rgba(16, 185, 129, 0.08) 0%, rgba(37, 99, 235, 0.08) 100%);
            border: 2px solid rgba(16, 185, 129, 0.2);
            border-radius: 0 0 12px 12px;
            padding: 24px;
            margin-bottom: 20px;
        }

        .main-analysis-section h5 {
            background: linear-gradient(135deg, var(--success-color) 0%, #16a34a 100%);
            color: white;
            font-size: 18px;
            font-weight: 600;
            margin: 0 0 20px 0;
            padding: 14px 18px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            gap: 10px;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
        }

        .analysis-content {
            line-height: 1.8;
            font-size: 16px;
            color: var(--text-color);
        }

        .advisory-section {
            background: linear-gradient(135deg, rgba(37, 99, 235, 0.05) 0%, rgba(16, 185, 129, 0.05) 100%);
            border: 2px solid rgba(37, 99, 235, 0.2);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }

        .advisory-section h5 {
            background: linear-gradient(135deg, var(--primary-color) 0%, #1d4ed8 100%);
            color: white;
            font-size: 16px;
            font-weight: 600;
            margin: 0 0 16px 0;
            padding: 12px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 2px 4px rgba(37, 99, 235, 0.2);
        }

        .advisory-content {
            margin-top: 12px;
        }

        .advisory-item {
            background: rgba(255, 255, 255, 0.7);
            border-right: 4px solid var(--primary-color);
            padding: 12px 16px;
            margin: 12px 0;
            border-radius: 0 8px 8px 0;
            line-height: 1.6;
        }

        [data-theme="dark"] .advisory-item {
            background: rgba(71, 85, 105, 0.4);
        }

        .advisory-date {
            background: var(--primary-color);
            color: white;
            padding: 4px 10px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            margin-right: 8px;
            display: inline-flex;
            align-items: center;
            gap: 4px;
        }

        .key-points-section {
            background: rgba(248, 250, 252, 0.9);
            border: 2px solid rgba(37, 99, 235, 0.15);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 20px;
        }

        [data-theme="dark"] .key-points-section {
            background: rgba(71, 85, 105, 0.3);
            border-color: rgba(37, 99, 235, 0.3);
        }

        .key-points-section h5 {
            background: linear-gradient(135deg, var(--warning-color) 0%, #ea580c 100%);
            color: white;
            font-size: 16px;
            font-weight: 600;
            margin: 0 0 16px 0;
            padding: 12px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 2px 4px rgba(217, 119, 6, 0.2);
        }

        .key-point-item {
            display: flex;
            align-items: flex-start;
            gap: 12px;
            margin: 12px 0;
            padding: 12px 16px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
            border-right: 3px solid var(--success-color);
        }

        [data-theme="dark"] .key-point-item {
            background: rgba(51, 65, 85, 0.6);
        }

        .key-point-item i {
            color: var(--success-color);
            font-size: 16px;
            margin-top: 2px;
            flex-shrink: 0;
        }

        .examples-section {
            background: rgba(248, 250, 252, 0.8);
            border: 2px solid rgba(16, 185, 129, 0.2);
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
        }

        [data-theme="dark"] .examples-section {
            background: rgba(71, 85, 105, 0.3);
            border-color: rgba(16, 185, 129, 0.3);
        }

        .examples-section h5 {
            background: linear-gradient(135deg, var(--accent-color) 0%, #6d28d9 100%);
            color: white;
            font-size: 16px;
            font-weight: 600;
            margin: 0 0 16px 0;
            padding: 12px 16px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 2px 4px rgba(124, 58, 237, 0.2);
        }

        .example-item {
            background: white;
            border: 1px solid rgba(16, 185, 129, 0.2);
            border-radius: 12px;
            margin: 16px 0;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }

        [data-theme="dark"] .example-item {
            background: rgba(51, 65, 85, 0.6);
            border-color: rgba(16, 185, 129, 0.3);
        }

        .example-header {
            background: linear-gradient(135deg, var(--success-color) 0%, #16a34a 100%);
            color: white;
            padding: 12px 16px;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .example-number {
            background: rgba(255, 255, 255, 0.2);
            color: white;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 14px;
            flex-shrink: 0;
        }

        .example-title {
            font-weight: 600;
            font-size: 14px;
        }

        .example-content {
            padding: 16px;
            line-height: 1.7;
            color: var(--text-color);
        }

        .article-ref {
            background: var(--success-color);
            color: white;
            padding: 2px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            gap: 4px;
            margin: 0 2px;
        }

        .ai-result-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 16px;
            border-top: 1px solid var(--border-color);
            font-size: 14px;
            color: #64748b;
        }

        .ai-provider-tag {
            display: flex;
            align-items: center;
            gap: 6px;
            background: rgba(37, 99, 235, 0.1);
            color: var(--primary-color);
            padding: 6px 12px;
            border-radius: 20px;
            font-weight: 600;
        }

        .ai-timestamp {
            display: flex;
            align-items: center;
            gap: 6px;
        }

        @media (max-width: 768px) {
            .app-container {
                padding: 8px;
            }
            
            .header {
                padding: 16px;
                margin-bottom: 16px;
            }
            
            .header-top {
                flex-direction: column;
                align-items: stretch;
                gap: 12px;
            }
            
            .app-title {
                font-size: 18px;
                text-align: center;
                line-height: 1.4;
            }
            
            .controls {
                justify-content: center;
                flex-wrap: wrap;
            }
            
            .search-input {
                font-size: 16px; /* جلوگیری از zoom در iOS */
                padding: 14px 50px 14px 16px;
            }
            
            .tools-bar {
                padding: 12px;
                flex-direction: column;
                gap: 8px;
                align-items: stretch;
            }
            
            .tool-group {
                justify-content: center;
                flex-wrap: wrap;
            }
            
            .jump-input {
                width: 100px;
                font-size: 16px;
            }
            
            .articles-container {
                padding: 16px;
            }
            
            .article-card {
                margin-bottom: 16px;
            }
            
            .article-header {
                padding: 12px 16px;
                flex-direction: column;
                gap: 8px;
                align-items: stretch;
            }
            
            .article-number {
                font-size: 16px;
                text-align: center;
            }
            
            .article-actions {
                justify-content: center;
                flex-wrap: wrap;
                gap: 6px;
            }
            
            .action-btn {
                font-size: 11px;
                padding: 6px 10px;
                flex: 1;
                min-width: 70px;
            }
            
            .article-content {
                padding: 16px;
            }
            
            .article-text {
                font-size: 15px;
                line-height: 1.7;
            }
            
            .ai-modal {
                padding: 8px;
            }

            .ai-modal-content {
                max-height: 95vh;
                margin: 0;
            }
            
            .ai-modal-header {
                padding: 16px 20px;
            }
            
            .ai-modal-body {
                padding: 16px 20px;
            }

            .ai-context-options {
                flex-direction: column;
                gap: 8px;
            }
            
            .bookmarks-menu {
                position: fixed;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 90vw;
                max-width: 400px;
                max-height: 70vh;
            }
            
            .lawyer-info {
                padding: 16px;
                margin-bottom: 16px;
            }
            
            .lawyer-info > div {
                flex-direction: column;
                gap: 12px;
                text-align: center;
            }
            
            .scroll-to-top {
                bottom: 16px;
                left: 16px;
                width: 45px;
                height: 45px;
                font-size: 16px;
            }
        }
        
        /* بهینه‌سازی برای صفحه‌نمایش‌های کوچک */
        @media (max-width: 480px) {
            .app-title {
                font-size: 16px;
            }
            
            .search-input {
                padding: 12px 45px 12px 14px;
            }
            
            .article-text {
                font-size: 14px;
            }
            
            .action-btn {
                font-size: 10px;
                padding: 5px 8px;
            }
        }
        
        /* بهینه‌سازی برای landscape در موبایل */
        @media (max-width: 768px) and (orientation: landscape) {
            .header {
                padding: 12px 16px;
            }
            
            .app-title {
                font-size: 16px;
            }
            
            .ai-modal-content {
                max-height: 90vh;
            }
            
        }
        /* استایل جدید برای عناوین ساختاری */
        .structural-header {
            background: #eef2ff;
            color: var(--primary-color);
            padding: 12px 18px;
            border-radius: 8px;
            margin: 24px 0 16px;
            font-size: 1.2em;
            font-weight: 600;
            border-right: 4px solid var(--primary-color);
        }
        
        [data-theme="dark"] .structural-header {
            background: #334155;
            color: var(--primary-color);
        }
    </style>
  <style>@view-transition { navigation: auto; }</style>
<link rel="stylesheet" href="/css/style1.css">
 </head>
 <body>
  <div class="app-container">
   <header class="header">
    <div class="header-top">
     <h1 class="app-title" id="app-title"><i class="fas fa-balance-scale"></i> سامانه قوانین جمهوری اسلامی ایران</h1>
     <div class="controls"><button class="theme-toggle" id="theme-toggle"> <i class="fas fa-moon"></i> حالت تاریک </button> <button class="pwa-install" id="pwa-install" style="display: none;"> <i class="fas fa-mobile-alt"></i> نصب اپ </button>
     </div>
    </div>
    <div class="search-container"><input type="text" class="search-input" id="search-input" placeholder="جستجو در مواد قانونی..."> <span class="search-icon"><i class="fas fa-search"></i></span>
    </div>
    <div class="law-selector" id="law-selector"><!-- قوانین اینجا بارگذاری می‌شوند -->
    </div>
   </header>
   <main class="main-content">
    <div class="tools-bar">
     <div class="tool-group"><input type="number" class="jump-input" id="jump-input" placeholder="شماره ماده" min="1"> <button class="tool-btn" id="jump-btn"> <i class="fas fa-search"></i> پرش به ماده </button>
     </div>
     <div class="tool-group bookmarks-dropdown"><button class="tool-btn secondary" id="bookmarks-btn"> <i class="fas fa-star"></i> نشانک‌ها (<span id="bookmarks-count">0</span>) </button>
      <div class="bookmarks-menu" id="bookmarks-menu">
       <div id="bookmarks-list"><!-- نشانک‌ها اینجا نمایش داده می‌شوند -->
       </div>
      </div>
     </div>
    </div><!-- اطلاعات وکیل -->
    <div class="lawyer-info">
     <div style="display: flex; align-items: center; justify-content: center; gap: 16px; flex-wrap: wrap;">
      <div style="display: flex; align-items: center; gap: 8px;"><i class="fas fa-user-tie" style="color: var(--primary-color); font-size: 20px;"></i> <span style="font-weight: 600; color: var(--text-color);">وکیل امیرحسین بای</span>
      </div>
      <div style="display: flex; align-items: center; gap: 8px;"><i class="fas fa-phone" style="color: var(--success-color); font-size: 16px;"></i> <a href="tel:09113797376" style="color: var(--primary-color); text-decoration: none; font-weight: 500;">09113797376</a>
      </div>
      <div style="display: flex; align-items: center; gap: 8px;"><i class="fas fa-globe" style="color: var(--accent-color); font-size: 16px;"></i> <a href="https://bayvakil.ir" target="_blank" rel="noopener noreferrer" style="color: var(--primary-color); text-decoration: none; font-weight: 500;">bayvakil.ir</a>
      </div>
     </div>
     <p style="margin: 12px 0 0 0; font-size: 14px; color: #64748b;">مشاوره حقوقی تخصصی و خدمات وکالت</p>
    </div>
    <section class="articles-container">
     <div id="articles-content">
      <div class="loading">
       لطفاً یکی از قوانین را انتخاب کنید
      </div>
     </div>
    </section>
   </main>
  </div>
  <div class="toast" id="toast"></div><!-- دکمه رفتن به بالا --> <button class="scroll-to-top" id="scroll-to-top"> <i class="fas fa-arrow-up"></i> </button> <!-- AI Analysis Modal -->
  <div class="ai-modal" id="ai-modal" style="display: none;">
   <div class="ai-modal-content">
    <div class="ai-modal-header">
     <h3><i class="fas fa-robot"></i> تحلیل هوش مصنوعی</h3><button class="ai-modal-close" id="ai-modal-close"><i class="fas fa-times"></i></button>
    </div>
    <div class="ai-modal-body">
     <div class="ai-status" id="ai-status"></div>
     <div class="ai-result" id="ai-result"></div>
    </div>
   </div>
  </div>
 <script>
    // =================================================================
    // =========== بخش ۱: تنظیمات اولیه و متغیرهای سراسری ==============
    // =================================================================

    const defaultConfig = {
        app_title: "سامانه قوانین جمهوری اسلامی ایران",
        search_placeholder: "جستجو در مواد قانونی..."
    };

    const laws = [{
        id: 'madani', title: 'قانون مدنی', url: 'laws/madani.xml'
    }, {
        id: 'adm', title: 'آیین دادرسی مدنی', url: 'laws/adm.xml'
    }, {
        id: 'adk', title: 'آیین دادرسی کیفری', url: 'laws/adk.xml'
    }, {
        id: 'tej', title: 'قانون تجارت', url: 'laws/tej.xml'
    }, {
        id: 'jaza', title: 'مجازات اسلامی', url: 'laws/jaza.xml'
    }, {
        id: 'shora', title: 'شوراهای حل اختلاف', url: 'laws/shora.xml'
    }];

    // متغیرهای وضعیت برنامه
    let currentLaw = null;
    let currentArticles = [];       // لیست تخت از تمام مواد برای جستجو
    let filteredArticles = [];      // مواد فیلتر شده توسط جستجو
    let currentLawStructure = [];   // آرایه ای که ساختار کامل قانون (هدرها و مواد) را نگه می دارد
    let bookmarks = JSON.parse(localStorage.getItem('bookmarks') || '[]');
    let notes = JSON.parse(localStorage.getItem('notes') || '{}');

    // عناصر DOM
    const elements = {
        lawSelector: document.getElementById('law-selector'),
        articlesContent: document.getElementById('articles-content'),
        searchInput: document.getElementById('search-input'),
        jumpInput: document.getElementById('jump-input'),
        jumpBtn: document.getElementById('jump-btn'),
        bookmarksBtn: document.getElementById('bookmarks-btn'),
        bookmarksMenu: document.getElementById('bookmarks-menu'),
        bookmarksList: document.getElementById('bookmarks-list'),
        bookmarksCount: document.getElementById('bookmarks-count'),
        themeToggle: document.getElementById('theme-toggle'),
        pwaInstall: document.getElementById('pwa-install'),
        toast: document.getElementById('toast'),
        aiModal: document.getElementById('ai-modal'),
        aiModalClose: document.getElementById('ai-modal-close'),
        aiStatus: document.getElementById('ai-status'),
        aiResult: document.getElementById('ai-result'),
        scrollToTop: document.getElementById('scroll-to-top')
    };

    // =================================================================
    // =========== بخش ۲: راه‌اندازی اولیه و شنود رویدادها ===============
    // =================================================================

    document.addEventListener('DOMContentLoaded', async () => {
        renderLawSelector();
        setupEventListeners();
        loadTheme();
        renderBookmarks();
        if (laws.length > 0) {
            await loadLaw(laws[0]);
        }
    });

    function renderLawSelector() {
        elements.lawSelector.innerHTML = laws.map(law => `
            <div class="law-card" data-law-id="${law.id}">
                <h3>${law.title}</h3>
            </div>
        `).join('');
    }

    function setupEventListeners() {
        elements.lawSelector.addEventListener('click', async (e) => {
            const lawCard = e.target.closest('.law-card');
            if (lawCard) {
                const lawId = lawCard.dataset.lawId;
                const law = laws.find(l => l.id === lawId);
                if (law) await loadLaw(law);
            }
        });

        elements.searchInput.addEventListener('input', (e) => searchArticles(e.target.value));
        elements.jumpBtn.addEventListener('click', () => {
            if (elements.jumpInput.value) jumpToArticle(elements.jumpInput.value.trim());
        });
        elements.jumpInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && elements.jumpInput.value) jumpToArticle(elements.jumpInput.value.trim());
        });
        elements.bookmarksBtn.addEventListener('click', (e) => {
            e.stopPropagation();
            elements.bookmarksMenu.classList.toggle('show');
        });
        document.addEventListener('click', (e) => {
            if (!elements.bookmarksMenu.contains(e.target) && !elements.bookmarksBtn.contains(e.target)) {
                elements.bookmarksMenu.classList.remove('show');
            }
        });
        elements.themeToggle.addEventListener('click', toggleTheme);
        elements.aiModalClose.addEventListener('click', () => elements.aiModal.style.display = 'none');
        elements.aiModal.addEventListener('click', (e) => {
            if (e.target === elements.aiModal) elements.aiModal.style.display = 'none';
        });
        elements.scrollToTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: 'smooth' }));
        window.addEventListener('scroll', () => elements.scrollToTop.classList.toggle('show', window.pageYOffset > 300));
    }


    // =================================================================
    // =========== بخش ۳: منطق اصلی بارگذاری و نمایش قانون ==============
    // =================================================================

    async function loadLaw(law) {
        try {
            showLoading();
            document.querySelectorAll('.law-card').forEach(card => card.classList.remove('active'));
            document.querySelector(`[data-law-id="${law.id}"]`).classList.add('active');
            currentLaw = law;
            elements.searchInput.value = '';

            const response = await fetch(law.url);
            if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
            
            const xmlText = await response.text();
            const parser = new DOMParser();
            const xmlDoc = parser.parseFromString(xmlText, 'text/xml');
            
            const parseError = xmlDoc.querySelector('parsererror');
            if (parseError) throw new Error('XML parsing error: ' + parseError.textContent);

            currentArticles = [];
            currentLawStructure = [];
            for (const node of xmlDoc.documentElement.children) {
                parseNodeRecursive(node, currentLawStructure);
            }

            if (currentArticles.length === 0) throw new Error('هیچ ماده قانونی معتبری در فایل XML یافت نشد.');

            filteredArticles = [...currentArticles];
            renderContent();
            showToast(`قانون ${law.title} بارگذاری شد (${currentArticles.length} ماده)`, 'success');

        } catch (error) {
            console.error('خطا در بارگذاری قانون:', error);
            elements.articlesContent.innerHTML = `<div class="no-results"><h3>خطا در بارگذاری قانون</h3><p>${error.message}</p></div>`;
            showToast('خطا در بارگذاری قانون', 'error');
        }
    }

    function parseNodeRecursive(node, structureArray) {
        const tagName = node.tagName;
        const structuralTags = ['مقدمه', 'لایحه_قانونی', 'جلد', 'کتاب', 'قسمت', 'باب', 'بخش', 'فصل', 'مبحث', 'بند', 'عنوان_کلی'];

        if (tagName === 'ماده') {
            const articleData = { number: node.getAttribute('شماره'), text: node.textContent.trim() };
            if (articleData.number && articleData.text) {
                currentArticles.push(articleData);
                structureArray.push({ type: 'article', data: articleData });
            }
        } else if (structuralTags.includes(tagName) || (node.children.length > 0 && node.getAttribute('عنوان'))) {
            const title = node.getAttribute('عنوان') || '';
            const number = node.getAttribute('شماره') || '';
            const cleanTagName = tagName.replace(/_/g, ' ');
            const headerText = tagName === 'عنوان_کلی' ? title : `${cleanTagName} ${number ? `${number} - ` : ''}${title}`;
            
            structureArray.push({ type: 'header', text: headerText });

            for (const child of node.children) {
                parseNodeRecursive(child, structureArray);
            }
        } else if (node.children.length > 0) {
             for (const child of node.children) {
                parseNodeRecursive(child, structureArray);
            }
        }
    }

    function renderContent() {
        let html = '';
        const filteredNumbers = new Set(filteredArticles.map(a => a.number));

        for (const item of currentLawStructure) {
            if (item.type === 'header') {
                html += `<div class="structural-header">${item.text}</div>`;
            } else if (item.type === 'article' && filteredNumbers.has(item.data.number)) {
                html += renderSingleArticle(item.data.number, item.data.text);
            }
        }
        elements.articlesContent.innerHTML = html || '<div class="no-results">هیچ ماده‌ای با شرایط جستجو یافت نشد.</div>';
    }

    function renderSingleArticle(articleNumber, articleText) {
        const articleKey = `${currentLaw.id}_${articleNumber}`;
        const isBookmarked = bookmarks.includes(articleKey);
        const articleNotes = notes[articleKey] || '';
        const formattedText = articleText.replace(/\n/g, '<br>');

        return `
            <div class="article-card" id="article-${articleNumber}">
                <div class="article-header">
                    <div class="article-number">ماده ${articleNumber}</div>
                    <div class="article-actions">
                        <button class="action-btn bookmark-btn ${isBookmarked ? 'active' : ''}" 
                                onclick="toggleBookmark('${articleKey}', this)">
                            <i class="fas fa-star"></i> نشانک
                        </button>
                        <button class="action-btn" onclick="toggleNotes('${articleKey}')"><i class="fas fa-sticky-note"></i> یادداشت</button>
                        <button class="action-btn" onclick="copyArticle('${articleNumber}')"><i class="fas fa-copy"></i> کپی</button>
                        <button class="action-btn" onclick="analyzeArticle('${articleNumber}')"><i class="fas fa-robot"></i> تحلیل AI</button>
                    </div>
                </div>
                <div class="article-content">
                    <div class="article-text">${highlightSearchTerm(formattedText)}</div>
                    <div class="notes-section" id="notes-${articleKey}" style="display: ${articleNotes ? 'block' : 'none'}">
                        <textarea class="notes-textarea" onchange="saveNote('${articleKey}', this.value)" placeholder="یادداشت خود را اینجا بنویسید...">${articleNotes}</textarea>
                    </div>
                </div>
            </div>
        `;
    }

    // =================================================================
    // =========== بخش ۴: توابع مربوط به قابلیت‌های جانبی ================
    // =================================================================
    
    function searchArticles(query) {
        if (!query.trim()) {
            filteredArticles = [...currentArticles];
        } else {
            filteredArticles = currentArticles.filter(article => 
                article.text.includes(query) || article.number.toString().includes(query)
            );
        }
        renderContent();
    }

    function jumpToArticle(articleNumber) {
        const element = document.getElementById(`article-${articleNumber}`);
        if (element) {
            element.scrollIntoView({ behavior: 'smooth', block: 'center' });
            element.style.transition = 'box-shadow 0.5s ease-in-out';
            element.style.boxShadow = '0 0 20px rgba(37, 99, 235, 0.5)';
            setTimeout(() => { element.style.boxShadow = ''; }, 1500);
        } else {
            showToast(`ماده ${articleNumber} یافت نشد`, 'error');
        }
    }

    function toggleBookmark(articleKey, buttonElement) {
        const index = bookmarks.indexOf(articleKey);
        if (index > -1) {
            bookmarks.splice(index, 1);
            buttonElement.classList.remove('active');
        } else {
            bookmarks.push(articleKey);
            buttonElement.classList.add('active');
        }
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
        renderBookmarks();
    }

    function renderBookmarks() {
        elements.bookmarksCount.textContent = bookmarks.length;
        if (bookmarks.length === 0) {
            elements.bookmarksList.innerHTML = '<div style="padding: 16px; text-align: center;">نشانکی وجود ندارد</div>';
            return;
        }
        elements.bookmarksList.innerHTML = bookmarks.map(bookmark => {
            const [lawId, articleNumber] = bookmark.split('_');
            const law = laws.find(l => l.id === lawId);
            return `<div class="bookmark-item" onclick="loadBookmark('${bookmark}')">
                        <span>${law?.title} - ماده ${articleNumber}</span>
                        <button class="bookmark-remove" onclick="event.stopPropagation(); removeBookmark('${bookmark}')">✕</button>
                    </div>`;
        }).join('');
    }

    async function loadBookmark(bookmark) {
        const [lawId, articleNumber] = bookmark.split('_');
        const law = laws.find(l => l.id === lawId);
        elements.bookmarksMenu.classList.remove('show');
        if (law && currentLaw?.id !== lawId) await loadLaw(law);
        setTimeout(() => jumpToArticle(articleNumber), 100);
    }
    
    function removeBookmark(bookmark) {
        bookmarks = bookmarks.filter(b => b !== bookmark);
        localStorage.setItem('bookmarks', JSON.stringify(bookmarks));
        renderBookmarks();
        renderContent(); // برای به‌روزرسانی دکمه در صفحه اصلی
    }

    function toggleNotes(articleKey) {
        const notesSection = document.getElementById(`notes-${articleKey}`);
        const isHidden = notesSection.style.display === 'none' || !notesSection.style.display;
        notesSection.style.display = isHidden ? 'block' : 'none';
        if(isHidden) notesSection.querySelector('textarea').focus();
    }

    function saveNote(articleKey, noteText) {
        if (noteText.trim()) notes[articleKey] = noteText.trim();
        else delete notes[articleKey];
        localStorage.setItem('notes', JSON.stringify(notes));
        showToast('یادداشت ذخیره شد', 'success');
    }

    function copyArticle(articleNumber) {
        const article = currentArticles.find(a => a.number === articleNumber);
        if (article) {
            navigator.clipboard.writeText(`ماده ${article.number} - ${currentLaw.title}\n\n${article.text}`);
            showToast('متن ماده کپی شد', 'success');
        }
    }

    // =================================================================
    // =========== بخش ۵: سیستم تحلیل AI (ارتباط امن با سرور) ===========
    // =================================================================

    function analyzeArticle(articleNumber) {
        const article = currentArticles.find(a => a.number.toString() === articleNumber.toString());
        if (!article) {
            showToast('ماده یافت نشد', 'error');
            return;
        }
        
        elements.aiModal.style.display = 'flex';
        elements.aiResult.classList.remove('show');
        showAIStatus('در حال ارسال درخواست به سرور...', 'info');

        fetch('https://bayvakil.ir/ghavanin/analyze.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                articleText: article.text,
                articleNumber: article.number,
                lawTitle: currentLaw.title
            })
        })
        .then(response => response.ok ? response.json() : Promise.reject(`خطای شبکه: ${response.statusText}`))
        .then(result => {
            if (result.success && result.data) {
                displayAIResult(result.data);
            } else {
                showAIStatus(result.error || 'خطای نامشخص از سمت سرور', 'error');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showAIStatus('خطا در ارتباط با سرور. لطفا از آپلود بودن فایل analyze.php و اتصال اینترنت خود مطمئن شوید.', 'error');
        });
    }

    function displayAIResult(result) {
        let formattedContent = result.answer
            .replace(/### (.*?)\n/g, '<h5>$1</h5>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/• /g, '<br>• ')
            .replace(/\n/g, '<br>');

        const { accuracyScore, articleNumber, provider, timestamp } = result;
        let accuracyBadge = '', accuracyClass = '';
        if (accuracyScore >= 90) { accuracyClass = 'excellent'; accuracyBadge = `<div class="accuracy-badge excellent">عالی ${accuracyScore}%</div>`; } 
        else if (accuracyScore >= 80) { accuracyClass = 'good'; accuracyBadge = `<div class="accuracy-badge good">خوب ${accuracyScore}%</div>`; } 
        else if (accuracyScore >= 60) { accuracyClass = 'fair'; accuracyBadge = `<div class="accuracy-badge fair">متوسط ${accuracyScore}%</div>`; } 
        else { accuracyClass = 'poor'; accuracyBadge = `<div class="accuracy-badge poor">ضعیف ${accuracyScore}%</div>`; }

        elements.aiResult.innerHTML = `
            <div class="ai-result-header ${accuracyClass}">
                <h4>تحلیل ماده ${articleNumber} ${currentLaw.title} </h4>
                ${accuracyBadge}
            </div>
            <div class="ai-result-content">${formattedContent}</div>
            <div class="ai-result-footer">
                <div class="ai-provider-tag"><i class="fas fa-robot"></i> ${provider}</div>
                <div class="ai-timestamp"><i class="fas fa-clock"></i> ${new Date(timestamp).toLocaleString('fa-IR')}</div>
            </div>`;
        elements.aiResult.classList.add('show');
        elements.aiStatus.classList.remove('show');
    }
    
    // =================================================================
    // =========== بخش ۶: توابع کمکی و عمومی ============================
    // =================================================================

    function showLoading() {
        elements.articlesContent.innerHTML = `<div class="loading"><div class="spinner"></div> در حال بارگذاری قانون...</div>`;
    }

    function showToast(message, type = 'success') {
        elements.toast.textContent = message;
        elements.toast.className = `toast show ${type}`;
        setTimeout(() => elements.toast.classList.remove('show'), 3000);
    }

    function highlightSearchTerm(text) {
        const query = elements.searchInput.value.trim();
        if (!query) return text;
        return text.replace(new RegExp(`(${query})`, 'gi'), '<span class="highlight">$1</span>');
    }

    function showAIStatus(message, type) {
        elements.aiStatus.innerHTML = message;
        elements.aiStatus.className = `ai-status show ${type}`;
    }

    function toggleTheme() {
        const newTheme = document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', newTheme);
        localStorage.setItem('theme', newTheme);
        elements.themeToggle.innerHTML = newTheme === 'dark' ? '<i class="fas fa-sun"></i> حالت روشن' : '<i class="fas fa-moon"></i> حالت تاریک';
    }

    function loadTheme() {
        const savedTheme = localStorage.getItem('theme') || 'light';
        document.documentElement.setAttribute('data-theme', savedTheme);
        elements.themeToggle.innerHTML = savedTheme === 'dark' ? '<i class="fas fa-sun"></i> حالت روشن' : '<i class="fas fa-moon"></i> حالت تاریک';
    }

    // کد PWA بدون تغییر باقی می ماند
    let deferredPrompt;
    window.addEventListener('beforeinstallprompt', (e) => {
        e.preventDefault();
        deferredPrompt = e;
        elements.pwaInstall.style.display = 'flex';
    });
    
</script>
  <script>
        const manifestData = {
            name: "سامانه قوانین جمهوری اسلامی ایران - وکیل بای",
            short_name: "قوانین ایران",
            description: "دسترسی آسان و سریع به قوانین جمهوری اسلامی ایران با تحلیل هوش مصنوعی",
            start_url: "./",
            scope: "./",
            display: "standalone",
            orientation: "portrait-primary",
            background_color: "#f1f5f9",
            theme_color: "#1e40af",
            categories: ["legal", "reference", "education"],
            lang: "fa",
            dir: "rtl",
            icons: [
                {
                    src: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNzIiIGhlaWdodD0iNzIiIHZpZXdCb3g9IjAgMCA3MiA3MiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjcyIiBoZWlnaHQ9IjcyIiByeD0iMTIiIGZpbGw9IiMxZTQwYWYiLz4KPHN2ZyB4PSIxOCIgeT0iMTgiIHdpZHRoPSIzNiIgaGVpZ2h0PSIzNiIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJ3aGl0ZSI+CjxwYXRoIGQ9Ik0xMiAyQzYuNDggMiAyIDYuNDggMiAxMnM0LjQ4IDEwIDEwIDEwIDEwLTQuNDggMTAtMTBTMTcuNTIgMiAxMiAyem0tMiAxNWwtNS01IDEuNDEtMS40MUwxMCAxNC4xN2w3LjU5LTcuNTlMMTkgOGwtOSA5eiIvPgo8L3N2Zz4KPC9zdmc+",
                    sizes: "72x72",
                    type: "image/svg+xml",
                    purpose: "any"
                },
                {
                    src: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOTYiIGhlaWdodD0iOTYiIHZpZXdCb3g9IjAgMCA5NiA5NiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9Ijk2IiBoZWlnaHQ9Ijk2IiByeD0iMTYiIGZpbGw9IiMxZTQwYWYiLz4KPHN2ZyB4PSIyNCIgeT0iMjQiIHdpZHRoPSI0OCIgaGVpZ2h0PSI0OCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJ3aGl0ZSI+CjxwYXRoIGQ9Ik0xMiAyQzYuNDggMiAyIDYuNDggMiAxMnM0LjQ4IDEwIDEwIDEwIDEwLTQuNDggMTAtMTBTMTcuNTIgMiAxMiAyem0tMiAxNWwtNS01IDEuNDEtMS40MUwxMCAxNC4xN2w3LjU5LTcuNTlMMTkgOGwtOSA5eiIvPgo8L3N2Zz4KPC9zdmc+",
                    sizes: "96x96",
                    type: "image/svg+xml",
                    purpose: "any"
                },
                {
                    src: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTQ0IiBoZWlnaHQ9IjE0NCIgdmlld0JveD0iMCAwIDE0NCAxNDQiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxNDQiIGhlaWdodD0iMTQ0IiByeD0iMjAiIGZpbGw9IiMxZTQwYWYiLz4KPHN2ZyB4PSIzNiIgeT0iMzYiIHdpZHRoPSI3MiIgaGVpZ2h0PSI3MiIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJ3aGl0ZSI+CjxwYXRoIGQ9Ik0xMiAyQzYuNDggMiAyIDYuNDggMiAxMnM0LjQ4IDEwIDEwIDEwIDEwLTQuNDggMTAtMTBTMTcuNTIgMiAxMiAyem0tMiAxNWwtNS01IDEuNDEtMS40MUwxMCAxNC4xN2w3LjU5LTcuNTlMMTkgOGwtOSA5eiIvPgo8L3N2Zz4KPC9zdmc+",
                    sizes: "144x144",
                    type: "image/svg+xml",
                    purpose: "any"
                },
                {
                    src: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTkyIiBoZWlnaHQ9IjE5MiIgdmlld0JveD0iMCAwIDE5MiAxOTIiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxOTIiIGhlaWdodD0iMTkyIiByeD0iMjQiIGZpbGw9IiMxZTQwYWYiLz4KPHN2ZyB4PSI0OCIgeT0iNDgiIHdpZHRoPSI5NiIgaGVpZ2h0PSI5NiIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJ3aGl0ZSI+CjxwYXRoIGQ9Ik0xMiAyQzYuNDggMiAyIDYuNDggMiAxMnM0LjQ4IDEwIDEwIDEwIDEwLTQuNDggMTAtMTBTMTcuNTIgMiAxMiAyem0tMiAxNWwtNS01IDEuNDEtMS40MUwxMCAxNC4xN2w3LjU5LTcuNTlMMTkgOGwtOSA5eiIvPgo8L3N2Zz4KPC9zdmc+",
                    sizes: "192x192",
                    type: "image/svg+xml",
                    purpose: "any"
                },
                {
                    src: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTEyIiBoZWlnaHQ9IjUxMiIgdmlld0JveD0iMCAwIDUxMiA1MTIiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSI1MTIiIGhlaWdodD0iNTEyIiByeD0iNjQiIGZpbGw9IiMxZTQwYWYiLz4KPHN2ZyB4PSIxMjgiIHk9IjEyOCIgd2lkdGg9IjI1NiIgaGVpZ2h0PSIyNTYiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0id2hpdGUiPgo8cGF0aCBkPSJNMTIgMkM2LjQ4IDIgMiA2LjQ4IDIgMTJzNC40OCAxMCAxMCAxMCAxMC00LjQ4IDEwLTEwUzE3LjUyIDIgMTIgMnptLTIgMTVsLTUtNSAxLjQxLTEuNDFMMTAgMTQuMTdsNy41OS03LjU5TDE5IDhsLTkgOXoiLz4KPC9zdmc+Cjwvc3ZnPg==",
                    sizes: "512x512",
                    type: "image/svg+xml",
                    purpose: "any maskable"
                }
            ],
            shortcuts: [
                {
                    name: "قانون مدنی",
                    short_name: "مدنی",
                    description: "دسترسی مستقیم به قانون مدنی",
                    url: "./?law=madani",
                    icons: [{ src: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOTYiIGhlaWdodD0iOTYiIHZpZXdCb3g9IjAgMCA5NiA5NiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9Ijk2IiBoZWlnaHQ9Ijk2IiByeD0iMTYiIGZpbGw9IiMxZTQwYWYiLz4KPHN2ZyB4PSIyNCIgeT0iMjQiIHdpZHRoPSI0OCIgaGVpZ2h0PSI0OCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJ3aGl0ZSI+CjxwYXRoIGQ9Ik0xMiAyQzYuNDggMiAyIDYuNDggMiAxMnM0LjQ4IDEwIDEwIDEwIDEwLTQuNDggMTAtMTBTMTcuNTIgMiAxMiAyem0tMiAxNWwtNS01IDEuNDEtMS40MUwxMCAxNC4xN2w3LjU5LTcuNTlMMTkgOGwtOSA5eiIvPgo8L3N2Zz4KPC9zdmc+", sizes: "96x96" }]
                },
                {
                    name: "آیین دادرسی مدنی",
                    short_name: "آ.د.م",
                    description: "دسترسی مستقیم به آیین دادرسی مدنی",
                    url: "./?law=adm",
                    icons: [{ src: "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iOTYiIGhlaWdodD0iOTYiIHZpZXdCb3g9IjAgMCA5NiA5NiIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9Ijk2IiBoZWlnaHQ9Ijk2IiByeD0iMTYiIGZpbGw9IiMxZTQwYWYiLz4KPHN2ZyB4PSIyNCIgeT0iMjQiIHdpZHRoPSI0OCIgaGVpZ2h0PSI0OCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJ3aGl0ZSI+CjxwYXRoIGQ9Ik0xMiAyQzYuNDggMiAyIDYuNDggMiAxMnM0LjQ4IDEwIDEwIDEwIDEwLTQuNDggMTAtMTBTMTcuNTIgMiAxMiAyem0tMiAxNWwtNS01IDEuNDEtMS40MUwxMCAxNC4xN2w3LjU5LTcuNTlMMTkgOGwtOSA5eiIvPgo8L3N2Zz4KPC9zdmc+", sizes: "96x96" }]
                }
            ],
            related_applications: [],
            prefer_related_applications: false
        };

        const manifestBlob = new Blob([JSON.stringify(manifestData)], { type: 'application/json' });
        const manifestURL = URL.createObjectURL(manifestBlob);
        const link = document.createElement('link');
        link.rel = 'manifest';
        link.href = manifestURL;
        document.head.appendChild(link);

        // اضافه کردن meta tags برای PWA
        const metaTags = [
            { name: 'mobile-web-app-capable', content: 'yes' },
            { name: 'apple-mobile-web-app-capable', content: 'yes' },
            { name: 'apple-mobile-web-app-status-bar-style', content: 'default' },
            { name: 'apple-mobile-web-app-title', content: 'قوانین ایران' },
            { name: 'msapplication-TileColor', content: '#1e40af' },
            { name: 'msapplication-tap-highlight', content: 'no' }
        ];

        metaTags.forEach(tag => {
            const meta = document.createElement('meta');
            meta.name = tag.name;
            meta.content = tag.content;
            document.head.appendChild(meta);
        });

        // اضافه کردن apple-touch-icon
        const appleIcon = document.createElement('link');
        appleIcon.rel = 'apple-touch-icon';
        appleIcon.href = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTgwIiBoZWlnaHQ9IjE4MCIgdmlld0JveD0iMCAwIDE4MCAxODAiIGZpbGw9Im5vbmUiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CjxyZWN0IHdpZHRoPSIxODAiIGhlaWdodD0iMTgwIiByeD0iMjQiIGZpbGw9IiMxZTQwYWYiLz4KPHN2ZyB4PSI0NSIgeT0iNDUiIHdpZHRoPSI5MCIgaGVpZ2h0PSI5MCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJ3aGl0ZSI+CjxwYXRoIGQ9Ik0xMiAyQzYuNDggMiAyIDYuNDggMiAxMnM0LjQ4IDEwIDEwIDEwIDEwLTQuNDggMTAtMTBTMTcuNTIgMiAxMiAyem0tMiAxNWwtNS01IDEuNDEtMS40MUwxMCAxNC4xN2w3LjU5LTcuNTlMMTkgOGwtOSA5eiIvPgo8L3N2Zz4KPC9zdmc+";
        document.head.appendChild(appleIcon);
    </script>
</body>
</html>